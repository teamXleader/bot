import os
import json
import asyncio
import base64
import uuid
import json
import random
import re
import ssl
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from threading import Lock, Thread
from google.protobuf.json_format import MessageToJson
from flask import Flask, request, jsonify, render_template

import aiohttp
import pytz
import telebot
from telebot import types
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from flask import Flask

from bs4 import BeautifulSoup
import MajorLoginReq_pb2
import MajorLoginRes_pb2
import GetLoginDataRes_pb2
import DecodeWhisperMsg_pb2
import GenWhisperMsg_pb2
import recieved_chat_pb2
import Team_msg_pb2
import spam_join_pb2
import bot_mode_pb2
import bot_invite_pb2
import random_pb2
import Clan_Startup_pb2
import clan_msg_pb2
import Team_Chat_Startup_pb2
import spam_pb2
import spam_request_pb2
import room_join_pb2
import player_info_request_pb2
import player_info_pb2
import reqClan_pb2
import RemoveFriend_Req_pb2
import ConfirmFriend_Req_pb2
import CancelFriend_Req_pb2
import GetFriend_Res_pb2
import Title_pb2
import krishna_title_pb2
import Emote_pb2
import Bundle_pb2
import start_game_pb2
import lag_pb2
import kick_pb2
import inv_room_pb2
import room_name_pb2
import GetFriendRequestList_Res_pb2
import left_group_pb2
import krishna_bundle_pb2
import krishna_animation_pb2
import flag_pb2
import logging
from krishna_packets import *
import aiohttp
import gzip
import logging
from google.protobuf.json_format import MessageToDict
from protobuf_decoder.protobuf_decoder import Parser

def update_command_stats(command_name):
    """Track command usage statistics"""
    print(f"Command used: {command_name}")
    pass

def fix_num(number_str):
    """Format numbers with [C] in the middle for display"""
    if len(number_str) > 5:
        return f"{number_str[:5]}[C]{number_str[5:]}"
    return number_str

async def GeneRaTePk(packet_hex, packet_type, K, V):
    """Generate final encrypted packet"""
    try:
        encrypted_packet = await encrypt_packet(packet_hex, K, V)
        packet_length = len(encrypted_packet) // 2
        packet_length_hex = await base_to_hex(packet_length)
        
        # Create final packet based on length
        if len(packet_length_hex) == 2:
            final_packet = f"{packet_type}000000{packet_length_hex}{encrypted_packet}"
        elif len(packet_length_hex) == 3:
            final_packet = f"{packet_type}00000{packet_length_hex}{encrypted_packet}"
        elif len(packet_length_hex) == 4:
            final_packet = f"{packet_type}0000{packet_length_hex}{encrypted_packet}"
        elif len(packet_length_hex) == 5:
            final_packet = f"{packet_type}000{packet_length_hex}{encrypted_packet}"
        else:
            final_packet = f"{packet_type}00{packet_length_hex}{encrypted_packet}"
            
        return bytes.fromhex(final_packet)
    except Exception as e:
        logging.error(f"Error in GeneRaTePk: {e}")
        return None

async def CrEaTe_ProTo(fields):
    """Create protobuf from fields dictionary"""
    try:
        # Simple protobuf creation based on field numbers
        result = b""
        for field_num, value in fields.items():
            if isinstance(value, dict):
                # Nested message
                result += bytes([(field_num << 3) | 2])  # length-delimited
                nested_data = await CrEaTe_ProTo(value)
                result += await EnCoDe_VaRiNt(len(nested_data))
                result += nested_data
            elif isinstance(value, int):
                # Varint field
                result += bytes([(field_num << 3) | 0])  # varint
                result += await EnCoDe_VaRiNt(value)
            elif isinstance(value, str):
                # String field
                result += bytes([(field_num << 3) | 2])  # length-delimited
                encoded_str = value.encode('utf-8')
                result += await EnCoDe_VaRiNt(len(encoded_str))
                result += encoded_str
        return result
    except Exception as e:
        logging.error(f"Error in CrEaTe_ProTo: {e}")
        return b""

# ===================== CHANNEL VERIFICATION CONFIG =====================
# Required Channels Configuration
CHANNELS = {
    "Leader Update": "leaderXupdatess",
}

CHANNEL_URLS = {
    "Leader Update": "https://t.me/leaderXupdatess",
}

CHANNEL_VERIFIED_FILE = 'channel_verified.json'
# =====================================================================

# Initialize Telegram bot
# IMPORTANT: Replace this with your actual bot token from @BotFather
bot = telebot.TeleBot("8846546958:AAGq9flfI6iuFLjfe6MXC8L89mmAz2G900w")

app = Flask(__name__)

# <--- FIX: Make writers globally accessible --->
online_writer = None
whisper_writer = None
spam_room = False
ai_mode = False
AUTO_JOIN_ENABLED = True
spammer_uid = None
spam_chat_id = None
spam_uid = None
token = None
# Global API Spam Variables
key = None
iv = None
event_loop = None

API_SECRET_KEY = "KrishnaCoder_Secret_Key"

BOT_START_TIME = time.time()

ADMIN_UIDS = ["1352244123", "4053842311", "767095747", "130873072"]
# <------------------------------------------>


headers = {
    'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 11; ASUS_Z01QD Build/PI)",
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'Content-Type': "application/x-www-form-urlencoded",
    'Expect': "100-continue",
    'X-Unity-Version': "2018.4.11f1",
    'X-GA': "v1 1",
    "ReleaseVersion": "OB54"
}

TOKEN_EXPIRY = 7 * 60 * 60


# --- Helper function for random colors ---
def get_random_color():
    colors = [
        "[FF0000]", "[00FF00]", "[0000FF]", "[FFFF00]", "[FF00FF]", "[00FFFF]",
        "[FFFFFF]", "[FFA500]", "[A52A2A]", "[800080]", "[000000]", "[808080]",
        "[C0C0C0]", "[FFC0CB]", "[FFD700]", "[ADD8E6]", "[90EE90]", "[D2691E]",
        "[DC143C]", "[00CED1]", "[9400D3]", "[F08080]", "[20B2AA]", "[FF1493]",
        "[7CFC00]", "[B22222]", "[FF4500]", "[DAA520]", "[00BFFF]", "[00FF7F]",
        "[4682B4]", "[6495ED]", "[5F9EA0]", "[DDA0DD]", "[E6E6FA]", "[B0C4DE]",
        "[556B2F]", "[8FBC8F]", "[2E8B57]", "[3CB371]", "[6B8E23]", "[808000]",
        "[B8860B]", "[CD5C5C]", "[8B0000]", "[FF6347]", "[FF8C00]", "[BDB76B]",
        "[9932CC]", "[8A2BE2]", "[4B0082]", "[6A5ACD]", "[7B68EE]", "[4169E1]",
        "[1E90FF]", "[191970]", "[00008B]", "[000080]", "[008080]", "[008B8B]",
        "[B0E0E6]", "[AFEEEE]", "[E0FFFF]", "[F5F5DC]", "[FAEBD7]", "[FFE4C4]",
        "[FFE4E1]", "[F0FFF0]", "[F5FFFA]", "[F0FFFF]", "[FFF0F5]", "[FFFACD]",
        "[FDF5E6]", "[FFEFD5]", "[FFEBCD]", "[FFEFD5]", "[FFE4B5]", "[FFDAB9]",
        "[EEE8AA]", "[F0E68C]", "[B0C4DE]", "[ADD8E6]", "[87CEEB]", "[87CEFA]",
        "[4682B4]", "[5F9EA0]", "[6495ED]", "[00CED1]", "[48D1CC]", "[20B2AA]",
        "[40E0D0]", "[7FFFD4]", "[66CDAA]", "[008B8B]", "[008080]", "[2F4F4F]",
        "[556B2F]", "[6B8E23]", "[9ACD32]", "[32CD32]", "[00FF00]", "[7CFC00]",
        "[7FFF00]", "[ADFF2F]", "[006400]", "[228B22]", "[008000]", "[00FF7F]",
        "[3CB371]", "[2E8B57]", "[66CDAA]", "[8FBC8F]", "[20B2AA]"
    ]
    return random.choice(colors)


def get_random_title():
    titles = list(
        set([
            904090026, 904090027, 904990072, 905190079,
            904990069, 904990070, 904990071
        ]))
    return random.choice(titles)


def get_random_emotes():
    emotes = [
        909000063, 909000068, 909000075, 909000081, 909000085, 909000090,
        909000098, 909000145, 909033001, 909035007, 909037011, 909038010,
        909038012, 909039011, 909040010, 909041005, 909042008, 909045001,
        909049010
    ]
    return random.choice(emotes)

def get_random_sticker():
    """
    Randomly select one sticker from available packs
    """

    sticker_packs = [
        # NORMAL STICKERS (1200000001-1 to 24)
        ("1200000001", 1, 24),

        # KELLY EMOJIS (1200000002-1 to 15)
        ("1200000002", 1, 15),

        # MAD CHICKEN (1200000004-1 to 13)
        ("1200000004", 1, 13),
    ]

    pack_id, start, end = random.choice(sticker_packs)
    sticker_no = random.randint(start, end)

    return f"[1={pack_id}-{sticker_no}]"

def load_emotes():
    with open("emotes.json", "r", encoding="utf-8") as f:
        data = json.load(f)["EMOTES"]

    numbers = data.get("numbers", {})
    names = data.get("names", {})
    return numbers, names


# <--- FIX: The avatar IDs were strings but needed to be integers for the protobuf messages. --->
def get_random_avatar():
    avatars = [
        902050001, 902000060, 902000061, 902000065, 902000073, 902000074,
        902000075, 902000076, 902000082, 902000083, 902000084, 902000087,
        902000090, 902000091, 902000112, 902000104, 902000190, 902000191,
        902000207, 902048021, 902047018, 902042011
    ]
    return random.choice(avatars)


# <-------------------------------------------------------------------------------------------->



# ========== CHANNEL VERIFICATION HELPER FUNCTIONS ==========

def load_channel_verified():
    """Load verified users from JSON file"""
    if not os.path.exists(CHANNEL_VERIFIED_FILE):
        return {}
    try:
        with open(CHANNEL_VERIFIED_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def save_channel_verified(user_id):
    """Save verified user to JSON file"""
    users = load_channel_verified()
    users[str(user_id)] = True
    with open(CHANNEL_VERIFIED_FILE, 'w') as f:
        json.dump(users, f, indent=4)


def is_channel_verified(user_id):
    """Check if user has verified channel membership"""
    users = load_channel_verified()
    return users.get(str(user_id), False)


def check_user_in_channel(user_id, channel_username):
    """Check if user is member of a specific channel"""
    try:
        member = bot.get_chat_member(f"@{channel_username}", user_id)
        return member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        print(f"Error checking channel {channel_username}: {e}")
        return False


def check_all_channel_memberships(user_id):
    """Check all required channels for a user"""
    results = {}
    for name, username in CHANNELS.items():
        results[name] = check_user_in_channel(user_id, username)
    return results


def create_channel_verification_keyboard(missing_channels):
    """Create inline keyboard with join buttons for missing channels"""
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    for name in missing_channels:
        url = CHANNEL_URLS.get(name, f"https://t.me/{CHANNELS[name]}")
        button = types.InlineKeyboardButton(
            text=f"📢 Join {name}",
            url=url
        )
        markup.add(button)
    
    # Add verification button
    verify_button = types.InlineKeyboardButton(
        text="✅ I've Joined All Channels",
        callback_data="verify_channels"
    )
    markup.add(verify_button)
    
    return markup


@bot.callback_query_handler(func=lambda call: call.data == "verify_channels")
def handle_channel_verification_callback(call):
    """Handle callback when user clicks 'I've Joined All' button"""
    user_id = call.from_user.id
    username = call.from_user.username or call.from_user.first_name
    
    membership_status = check_all_channel_memberships(user_id)
    all_joined = all(membership_status.values())
    
    if all_joined:
        save_channel_verified(user_id)
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="<b>✅ CHANNEL VERIFICATION COMPLETE!</b>\n\n"
                 "<b>YOU HAVE JOINED ALL REQUIRED CHANNELS</b>\n"
                 "<b>YOU CAN NOW USE ALL BOT COMMANDS</b>\n\n"
                 "<b>USE /start TO SEE AVAILABLE COMMANDS</b>",
            parse_mode="HTML"
        )
        print(f"✅ User {username} ({user_id}) verified successfully")
    else:
        # Still missing some channels
        missing = [name for name, joined in membership_status.items() if not joined]
        missing_text = "\n".join([f"❌ {name}" for name in missing])
        
        markup = create_channel_verification_keyboard(missing)
        
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=f"<b>⚠️ YOU HAVEN'T JOINED ALL CHANNELS</b>\n\n"
                 f"<b>MISSING CHANNELS:</b>\n{missing_text}\n\n"
                 f"<b>PLEASE JOIN ALL CHANNELS FIRST</b>\n"
                 f"<b>THEN CLICK 'I'VE JOINED ALL'</b>",
            parse_mode="HTML",
            reply_markup=markup
        )
        print(f"❌ User {username} ({user_id}) still missing: {', '.join(missing)}")


def verify_user_channels(message):
    """Main verification function to check and prompt user"""
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check if already verified
    if is_channel_verified(user_id):
        return True
    
    # Check current membership status
    membership_status = check_all_channel_memberships(user_id)
    all_joined = all(membership_status.values())
    
    if all_joined:
        save_channel_verified(user_id)
        bot.reply_to(
            message,
            "<b>✅ CHANNEL VERIFICATION COMPLETE!</b>\n\n"
            "<b>YOU HAVE JOINED ALL REQUIRED CHANNELS</b>\n"
            "<b>YOU CAN NOW USE ALL BOT COMMANDS</b>",
            parse_mode="HTML"
        )
        return True
    
    # User hasn't joined all channels
    missing = [name for name, joined in membership_status.items() if not joined]
    missing_text = "\n".join([f"❌ {name}" for name in missing])
    
    markup = create_channel_verification_keyboard(missing)
    
    bot.reply_to(
        message,
        f"<b>🔒 CHANNEL VERIFICATION REQUIRED</b>\n\n"
        f"<b>TO USE THIS BOT, YOU MUST JOIN ALL CHANNELS:</b>\n\n"
        f"{missing_text}\n\n"
        f"<b>AFTER JOINING, CLICK THE BUTTON BELOW:</b>",
        parse_mode="HTML",
        reply_markup=markup
    )
    print(f"🔒 User {username} ({user_id}) needs verification. Missing: {', '.join(missing)}")
    return False

# ============================================================


def rrrrrrrrrrrrrr(number):
    if isinstance(number, str) and '***' in number:
        return number.replace('***', '106')
    return number

async def encrypted_proto(encoded_hex):
    key = b'Yg&tc%DEuh6%Zc^8'
    iv = b'6oyZDr22E3ychjM%'
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_message = pad(encoded_hex, AES.block_size)
    encrypted_payload = cipher.encrypt(padded_message)
    return encrypted_payload

async def encrypt_message(plaintext):
    key = b'Yg&tc%DEuh6%Zc^8'
    iv = b'6oyZDr22E3ychjM%'
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_message = pad(plaintext, AES.block_size)
    encrypted_message = cipher.encrypt(padded_message)
    return binascii.hexlify(encrypted_message).decode('utf-8')    
           
async def create_protobuf_message(user_id):
    message = spam_request_pb2.SpamRequestMessage()
    uid = int(user_id)
    message.uid = 16519667180
    message.random = uid
    message.field3 = 22
    return message.SerializeToString()
    
async def spam_func(add_uid):
    protobuf_message = create_protobuf_message(add_uid)
    encrypted_uid = encrypt_message(protobuf_message)
    response = await send_requests(encrypted_uid)
    return response 

async def RemoveFriendProto(rem_uid):
    message = RemoveFriend_Req_pb2.RemoveFriend()
    message.AuthorUid = 16519667180
    message.TargetUid = int(rem_uid)
    encode = message.SerializeToString()
    return await encrypt_message(encode)

async def CancelFriendProto(cancel_uid):
    message = CancelFriend_Req_pb2.CancelFriend()
    message.TargetUid = int(cancel_uid)
    message.AuthorUid = 16519667180
    encode = message.SerializeToString()
    return await encrypt_message(encode)

async def ConfirmFriendProto(Confirm_uid):
    message = ConfirmFriend_Req_pb2.ConfirmFriend()
    message.TargetUid = int(Confirm_uid)
    message.AuthorUid = 16519667180
    encode = message.SerializeToString()
    return await encrypt_message(encode)
            
def format_timestamp(timestamp):
    return datetime.fromtimestamp(timestamp).strftime('%I:%M %p %d/%m/%y')
    
async def info_protobuf_message(user_id):
    message = player_info_request_pb2.info_request()
    uid = int(user_id)
    message.uid = uid
    message.region = "IND"
    return message.SerializeToString()

async def clan_protobuf_msg(clan_id):
    msg = reqClan_pb2.MyMessage()
    clanid = int(clan_id)
    msg.field_1 = clanid    
    encode = msg.SerializeToString()
    return await encrypt_message(encode)


async def get_random_user_agent():
    versions = [
        '4.0.18P6', '4.0.19P7', '4.0.20P1', '4.1.0P3', '4.1.5P2', '4.2.1P8',
        '4.2.3P1', '5.0.1B2', '5.0.2P4', '5.1.0P1', '5.2.0B1', '5.2.5P3',
        '5.3.0B1', '5.3.2P2', '5.4.0P1', '5.4.3B2', '5.5.0P1', '5.5.2P3'
    ]
    models = [
        'SM-A125F',
        'SM-A225F',
        'SM-A325M',
        'SM-A515F',
        'SM-A725F',
        'SM-M215F',
        'SM-M325FV',
        'Redmi 9A',
        'Redmi 9C',
        'POCO M3',
        'POCO M4 Pro',
        'RMX2185',
        'RMX3085',
        'moto g(9) play',
        'CPH2239',
        'V2027',
        'OnePlus Nord',
        'ASUS_Z01QD',
    ]
    android_versions = ['9', '10', '11', '12', '13', '14']
    languages = ['en-US', 'es-MX', 'pt-BR', 'id-ID', 'ru-RU', 'hi-IN']
    countries = ['USA', 'MEX', 'BRA', 'IDN', 'RUS', 'IND']
    version = random.choice(versions)
    model = random.choice(models)
    android = random.choice(android_versions)
    lang = random.choice(languages)
    country = random.choice(countries)
    return f"GarenaMSDK/{version}({model};Android {android};{lang};{country};)"


async def get_access_token(uid , password):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    headers = {
        "Host": "100067.connect.garena.com",
        "User-Agent": (await get_random_user_agent()),
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close"}
    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"}
    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, data=data) as response:
            if response.status != 200: return await response.read()
            data = await response.json()
            open_id = data.get("open_id")
            access_token = data.get("access_token")
            return (open_id, access_token) if open_id and access_token else (None, None)
            
async def MajorLoginProto_Encode(open_id, access_token):
    major_login = MajorLoginReq_pb2.MajorLogin()
    major_login.event_time = "2026-07-09 12:44:05"
    major_login.game_name = "free fire"
    major_login.platform_id = 1
    major_login.client_version = "2.127.3"
    major_login.system_software = "Android OS 13 / API-33 (TP1A.220905.001/R.206769c-2)"
    major_login.system_hardware = "Handheld"
    major_login.telecom_operator = "45403"
    major_login.network_type = "WIFI"
    major_login.screen_width = 1280
    major_login.screen_height = 720
    major_login.screen_dpi = "320"
    major_login.processor_details = "ARM64 FP ASIMD AES | 2352 | 8"
    major_login.memory = 128
    major_login.gpu_renderer = "Mali-G610"
    major_login.gpu_version = "OpenGL ES 3.2 v1.g18p0-01eac0.2d5e200a1514bdef1a4909db66e37e28"
    major_login.unique_device_id = "Google|7a9732a4-2549-4edc-840e-d61263d128f5"
    major_login.client_ip = "162.128.224.168"
    major_login.language = "en"
    major_login.open_id = open_id
    major_login.open_id_type = "4"
    major_login.device_type = "Handheld"
    major_login.device_model = "OPPO CPH2217"
    major_login.region = "IND"
    major_login.access_token = access_token
    major_login.platform_sdk_id = 1
    major_login.network_operator_a = "45403"
    major_login.network_type_a = "WIFI"
    major_login.client_using_version = "1ac4b80ecf0478a44203bf8fac6120f5"
    major_login.external_storage_total = 20660
    major_login.external_storage_available = 17445
    major_login.internal_storage_total = 2663
    major_login.internal_storage_available = 1500
    major_login.game_disk_storage_available = 17573
    major_login.game_disk_storage_total = 20660
    major_login.external_sdcard_avail_storage = 17573
    major_login.external_sdcard_total_storage = 20660
    major_login.login_by = 3
    major_login.library_path = "/data/app/~~xHaSHUdUBlxvhJaRWh018A==/com.dts.freefireth-4OBn7-sLMoPuswIfmgixhA==/lib/arm64"
    major_login.reg_avatar = 1
    major_login.library_token = "4c322aeb56444feaa151d1ea91a8f7f2|/data/app/~~xHaSHUdUBlxvhJaRWh018A==/com.dts.freefireth-4OBn7-sLMoPuswIfmgixhA==/base.apk"
    major_login.channel_type = 6
    major_login.cpu_type = 2
    major_login.cpu_architecture = "64"
    major_login.client_version_code = "2019120816"
    major_login.unknown_int85 = 3
    major_login.graphics_api = "OpenGLES2"
    major_login.supported_astc_bitset = 16383
    major_login.login_open_id_type = 4
    major_login.analytics_detail = b"FwQVTgUPX1UaUllDDwcWCRBpWA0FUgsvA1snWlBaO1kFYg=="
    major_login.loading_time = 25777
    major_login.release_channel = "3rd_party"
    major_login.extra_info = "KqsHTz+zAigQ0BOzKhQHN8ae/IefLXcroDjaj4QY+OF71nTuiQh+myDUqCZFPJQ5gyC9LfEeKoon9d461764VIGguRHcIyKfExGAh4bvxFZRgp2X"
    major_login.extra_json = '{"cur_rate":null,"support_etc2":false}'
    major_login.android_engine_init_flag = 110009
    major_login.if_push = 1
    major_login.is_vpn = 1
    major_login.origin_platform_type = "4"
    major_login.primary_platform_type = "4"
    major_login.unknown_bytes102 = b"E1JMTwcJXjA2"
    string = major_login.SerializeToString()
    return await encrypted_proto(string)


async def MajorLogin(payload):
    url = f"https://loginbp.ggpolarbear.com/MajorLogin"
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    async with aiohttp.ClientSession() as session:
        async with session.post(url,
                                data=payload,
                                headers=headers,
                                ssl=ssl_context) as response:
            if response.status == 200:
                return await response.read()
            return None


async def GetLoginData(base_url, payload, token):
    url = f"{base_url}/GetLoginData"
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    headers['Authorization'] = f"Bearer {token}"
    async with aiohttp.ClientSession() as session:
        async with session.post(url,
                                data=payload,
                                headers=headers,
                                ssl=ssl_context) as response:
            if response.status == 200:
                return await response.read()
            return None


async def talk_with_ai(question):
    try:
        url = f"http://185.216.176.215:5031/api/ask?prompt={question}"

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as res:
                if res.status == 200:
                    data = await res.json()

                    if data.get("success"):
                        return data.get("response", "No response from AI")
                    else:
                        return "[FF0000]AI returned unsuccessful response"

                return f"[FF0000]Error {res.status}: API request failed"

    except Exception as e:
        return f"[FF0000]AI Error: {str(e)}"


async def MajorLogin_Decode(MajorLoginResponse):
    proto = MajorLoginRes_pb2.MajorLoginRes()
    proto.ParseFromString(MajorLoginResponse)
    return proto


async def GetLoginData_Decode(GetLoginDataResponse):
    proto = GetLoginDataRes_pb2.GetLoginData()
    proto.ParseFromString(GetLoginDataResponse)
    return proto


import asyncio


async def decode_team_packet(hex_packet, retries=3, delay=0.5):
    for attempt in range(1, retries + 1):
        try:
            packet = bytes.fromhex(hex_packet)
            proto = recieved_chat_pb2.recieved_chat()
            proto.ParseFromString(packet)
            return proto
        except Exception as e:
            print(f"[decode_team_packet Error] Attempt {attempt}: {e}")
            if attempt < retries:
                await asyncio.sleep(delay)
            else:
                return None


async def DecodeWhisperMessage(hex_packet, retries=3, delay=0.5):
    for attempt in range(1, retries + 1):
        try:
            packet = bytes.fromhex(hex_packet)
            proto = DecodeWhisperMsg_pb2.DecodeWhisper()
            proto.ParseFromString(packet)
            return proto
        except Exception as e:
            print(f"[DecodeWhisperMessage Error] Attempt {attempt}: {e}")
            if attempt < retries:
                await asyncio.sleep(delay)
            else:
                return None


async def EnCoDe_VaRiNt(value):
    """Encode integer as varint"""
    try:
        result = b""
        while value > 0x7F:
            result += bytes([(value & 0x7F) | 0x80])
            value >>= 7
        result += bytes([value])
        return result
    except Exception as e:
        logging.error(f"Error in EnCoDe_VaRiNt: {e}")
        return b""


async def base_to_hex(timestamp):
    timestamp_result = hex(timestamp)
    result = str(timestamp_result)[2:]
    if len(result) == 1:
        result = "0" + result
    return result


async def parse_results(parsed_results):
    result_dict = {}
    for result in parsed_results:
        field_data = {}
        field_data["wire_type"] = result.wire_type
        if result.wire_type == "varint":
            field_data["data"] = result.data
        if result.wire_type == "string":
            field_data["data"] = result.data
        if result.wire_type == "bytes":
            field_data["data"] = result.data
        elif result.wire_type == "length_delimited":
            field_data["data"] = await parse_results(result.data.results)
        result_dict[result.field] = field_data
    return result_dict


async def split_text_by_words(text, max_length=200):

    def insert_c_in_number(word):
        if word.isdigit():
            mid = len(word) // 2
            return word[:mid] + "[C]" + word[mid:]
        return word

    words = text.split()
    words = [insert_c_in_number(word) for word in words]

    chunks = []
    current = ""

    for word in words:
        if len(current) + len(word) + (1 if current else 0) <= max_length:
            current += (" " if current else "") + word
        else:
            chunks.append(current)
            current = word

    if current:
        chunks.append(current)

    return chunks


async def get_available_room(input_text):
    try:
        parsed_results = Parser().parse(input_text)
        parsed_results_objects = parsed_results
        parsed_results_dict = await parse_results(parsed_results_objects)
        json_data = json.dumps(parsed_results_dict)
        return json_data
    except Exception as e:
        print(f"error {e}")
        return None


async def team_chat_startup(player_uid, team_session, key, iv):
    proto = Team_Chat_Startup_pb2.team_chat_startup()
    proto.field1 = 3
    proto.details.uid = player_uid
    proto.details.language = "en"
    proto.details.team_packet = str(team_session)

    packet = proto.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "1201000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "120100000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "12010000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "1201000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check clan startup function.")
    if whisper_writer:  # <--- FIX: Check if writer is available
        whisper_writer.write(bytes.fromhex(final_packet))
        await whisper_writer.drain()


async def encrypt_packet(packet, key, iv):
    bytes_packet = bytes.fromhex(packet)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    cipher_text = cipher.encrypt(pad(bytes_packet, AES.block_size))
    return cipher_text.hex()

async def Krishna(client_id, K, V, region):
    TEXT = f"""
{get_random_color()}ＰＯＷＥＲＥＤ   ＢＹ   ＫＲＩＳＨＮＡ
{get_random_color()}━━━━━━━━━━━━━━━━━━━━━━
{get_random_color()} ＦＯＬＬＯＷ    ＭＥ   ＩＮ   ＩＮＳＴＡＧＲＡＭ: {get_random_color()}@krishna.coder
{get_random_color()}━━━━━━━━━━━━━━━━━━━━━━
{get_random_color()}ＩＦ   ＹＯＵ   ＮＯＴ   ＦＯＬＬＯＷ   ＭＥ   Ｉ   ＷＩＬＬ   ＢＡＮ   ＹＯＵＲ   ＡＣＣＯＵＮＴ!!
    """        
    fields = {
        1: 5,
        2: {
            1: int(client_id),
            2: 1,
            3: int(client_id),
            4: TEXT
        }
    }
    if region.lower() == "ind":
        packet = '0515'
    elif region.lower() == "me":
        packet = "0519"
    else:
        packet = "0515"
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex() , packet , K , V)

async def Krishna1(client_id, K, V, region):
    TEXT = f"""
{get_random_color()}ＰＯＷＥＲＥＤ   ＢＹ   ＫＲＩＳＨＮＡ
{get_random_color()}━━━━━━━━━━━━━━━━━━━━━━
{get_random_color()} ＦＯＬＬＯＷ    ＭＥ   ＩＮ   ＩＮＳＴＡＧＲＡＭ: {get_random_color()}@krishna.coder
{get_random_color()}━━━━━━━━━━━━━━━━━━━━━━
{get_random_color()}ＩＦ   ＹＯＵ   ＮＯＴ   ＦＯＬＬＯＷ   ＭＥ   Ｉ   ＷＩＬＬ   ＢＡＮ   ＹＯＵＲ   ＡＣＣＯＵＮＴ!!
    """        
    fields = {
        1: int(client_id),
        2: 5,
        4: 50,
        5: {
            1: int(client_id),
            2: TEXT,
            3: 1
        }
    }
    if region.lower() == "ind":
        packet = '0515'
    elif region.lower() == "me":
        packet = "0519"
    else:
        packet = "0515"
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex() , packet , K , V)

async def tc(key, iv):
    fields = {
        1: 31,
        2: {
            1: 16519667180
        }
    }

    proto_hex = (await CrEaTe_ProTo(fields)).hex()
    return await GeneRaTePk(
        proto_hex,
        "0515",
        key,
        iv
    )

async def Room(room, K, V):
    room_name = room_name_pb2.Room()

    room_name.field_1 = 2

    room_name.field_2.field_1 = 1
    room_name.field_2.field_2 = 15
    room_name.field_2.field_3 = 3
    room_name.field_2.field_4 = str(room)
    room_name.field_2.field_6 = 8
    room_name.field_2.field_7 = 30
    room_name.field_2.field_8 = 1
    room_name.field_2.field_9 = 1
    room_name.field_2.field_11 = 1
    room_name.field_2.field_12 = 2
    room_name.field_2.field_14 = 36981056

    idc1 = room_name.field_2.field_15.add()
    idc1.field_1 = "IDC1"
    idc1.field_2 = 3000
    idc1.field_3 = "IND"

    idc2 = room_name.field_2.field_15.add()
    idc2.field_1 = "IDC2"
    idc2.field_2 = 3000
    idc2.field_3 = "IND"

    proto_hex = room_name.SerializeToString().hex()

    return await GeneRaTePk(
        proto_hex,
        packet_type="0e0b",
        K=K,
        V=V
    )

async def send_sticker(target_uid, chat_id, key, iv, nickname="ᏦʀᎥsʜɴᴀㅤBᴏᴛ"):
    try:
        sticker_value = get_random_sticker()

        sticker = krishna_title_pb2.GenTeamTitle()
        sticker.type = 1

        data = sticker.data
        data.uid = int(target_uid)
        data.chat_id = int(chat_id)
        data.title = f'{{"StickerStr":"{sticker_value}","type":"Sticker"}}'
        data.timestamp = int(datetime.now().timestamp())
        data.language = "en"

        details = data.field9
        details.Nickname = f"[C][B][FF0000]{nickname}"
        details.avatar_id = get_random_avatar()
        details.rank = 330
        details.badge = 827001007
        details.Clan_Name = "TEAM-KRISHNA"
        details.field10 = 1
        details.global_rank_pos = 1
        details.badge_info.value = 2
        details.prime_info.prime_uid = 1158053040
        details.prime_info.prime_level = 8
        details.prime_info.prime_hex = (
            "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002"
            "\u0003\r\u000e\u0012\u0001\u0005\u0006"
        )

        options = data.field13
        options.url_type = 2
        options.curl_platform = 1

        data.empty_field.SetInParent()

        proto_hex = sticker.SerializeToString().hex()

        final_packet = await GeneRaTePk(
            proto_hex,
            packet_type="1215",
            K=key,
            V=iv
        )

        return final_packet

    except Exception as e:
        print(f"Sticker Packet Error: {e}")
        return None
        
async def FlagTransfer(players_uid, key, iv):
    root = flag_pb2.flag_transfer()
    root.field_1 = 57
    root.field_2.field_1 = 16519667180
    root.field_2.field_2 = int(players_uid)
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check Krish1 function.")

    if online_writer:
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()

async def Krishna_Bundle(bundle_id, key, iv):
    root = krishna_bundle_pb2.bundle_krishna()
    root.field_1 = 88
    root.field_2.field_1.field_1 = int(bundle_id)
    root.field_2.field_1.field_2 = 1
    root.field_2.field_2 = 2
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check Krish1 function.")

    if online_writer:
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()

async def Krishna_Animation(bundle_id, key, iv):
    root = krishna_animation_pb2.animation_krishna()
    root.field_1 = 88
    root.field_2.field_1.field_1 = int(bundle_id)
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check Krish1 function.")

    if online_writer:
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()
                
async def bundlepacket(animation_id, key, iv):
    fields = {
        1: 88,
        2: {
            1: {
                1: int(animation_id)
            }
        }
    }

    proto_hex = (await CrEaTe_ProTo(fields)).hex()

    packet = await GeneRaTePk(
        proto_hex,
        '0515',
        key,
        iv
    )

    if not packet:
        raise ValueError("bundlepacket(): GeneRaTePk returned None")

    return packet

async def bundle_packet(bundle_id, key, iv):
    bundle = Bundle_pb2.BundleMessage()

    bundle.field1 = 88

    bundle.field2.field1.bundle_id = int(bundle_id)
    bundle.field2.field1.status = 1

    bundle.field2.field2 = 2

    packet_hex = bundle.SerializeToString().hex()

    encrypted_packet = await encrypt_packet(packet_hex, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "0515000" + packet_length_hex + encrypted_packet
    else:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet

    return bytes.fromhex(final_packet)

async def bundle_packet2(bundle_id, key, iv):
    bundle = Bundle_pb2.BundleMessage()

    bundle.field1 = 88

    bundle.field2.field1.bundle_id = int(bundle_id)
    bundle.field2.field1.status = 2

    bundle.field2.field2 = 2

    packet_hex = bundle.SerializeToString().hex()

    encrypted_packet = await encrypt_packet(packet_hex, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "0515000" + packet_length_hex + encrypted_packet
    else:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet

    return bytes.fromhex(final_packet)

async def GetFriend():   
    url = f"{base_url}/GetFriend"
    body = bytes.fromhex("59 8f ca f0 78 39 30 8f f2 87 ac a3 ae 0a 06 17")
    global token
    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=body, headers=headers, ssl=False) as resp:
                resp.raise_for_status()
                byte = await resp.read()
                
                decode = GetFriend_Res_pb2.GetFriend()
                decode.ParseFromString(byte)
                
                json_data = MessageToJson(decode)
                return json_data
    except aiohttp.ClientError as req_err:
        logging.error(f"HTTP Request failed: {req_err}")
    except Exception as e:
        logging.error(f"Error parsing response: {e}")

    return {"PlayerList": []}

async def GetFriendRequestList():
    url = f"{base_url}/GetFriendRequestList"
    body = bytes.fromhex("1A725B2C56EC52BA7D09623454C0A003")

    global token

    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=body, headers=headers) as resp:
                resp.raise_for_status()
                byte_data = await resp.read()

                # ✅ Handle gzip if compressed
                try:
                    byte_data = gzip.decompress(byte_data)
                except:
                    pass

                decode = GetFriendRequestList_Res_pb2.GetFriendRequest()
                decode.ParseFromString(byte_data)

                data_dict = MessageToDict(decode, preserving_proto_field_name=True)

                if "data" in data_dict and "accounts" in data_dict["data"]:
                    return data_dict["data"]["accounts"]

                return []

    except Exception as e:
        logging.error(f"GetFriendRequestList Error: {e}")
        return []

def equipe_emote():
    global token
    url = f"{base_url}/ChooseEmote"
    

    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    data = bytes.fromhex("CA F6 83 22 2A 25 C7 BE FE B5 1F 59 54 4D B3 13")

    r = requests.post(url, headers=headers, data=data)

def get_freefire_update():
    url = "https://www.freefiremania.com.br/free-fire-new-update.html"

    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
        }

        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, 'html.parser')

        all_text = soup.get_text()
        all_text = ' '.join(all_text.split())

        update_pattern = r'The next Free Fire update happens on (.+?) \((GMT[^)]+)\), remaining (.+?)\.'
        match = re.search(update_pattern, all_text, re.IGNORECASE)

        if not match:
            update_pattern = r'update happens on (.+?) \((GMT[^)]+)\), remaining (.+?)\.'
            match = re.search(update_pattern, all_text, re.IGNORECASE)

        if not match:
            return {
                "success": False,
                "error": "Update information pattern not found on the page"
            }

        date_str = match.group(1).strip()
        timezone = match.group(2).strip()
        countdown = match.group(3).strip()

        versions = re.findall(r'OB\d+', all_text)

        unique_versions = []
        for v in versions:
            if v not in unique_versions:
                unique_versions.append(v)

        return {
            "success": True,
            "update_data": f"{date_str} ({timezone})",
            "countdown": countdown,
            "from_version": unique_versions[0] if len(unique_versions) > 0 else "",
            "to_version": unique_versions[1] if len(unique_versions) > 1 else "",
            "all_versions_found": unique_versions,
            "update_msg": f"The next Free Fire update happens on {date_str} ({timezone}), remaining {countdown}."
        }

    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "error": f"Network error: {str(e)}"
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"Unexpected error: {str(e)}"
        }
        
async def send_join_request(clan_id):
    encrypted_uid = await clan_protobuf_msg(clan_id)
    edata = bytes.fromhex(encrypted_uid)
    
    global token
    url = f"{base_url}/RequestJoinClan"
    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Content-Type': "application/octet-stream",
        'Authorization': f"Bearer {token}",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    response = requests.post(url, data=edata, headers=headers)

    if response.status_code == 200:
        return "Successfully send clan join spam "
    else:
        return "Failed to send clan join spam "
    
async def leave_clan_request(clan_id):
    encrypted_uid = await clan_protobuf_msg(clan_id)
    edata = bytes.fromhex(encrypted_uid)
    
    global token
    url = f"{base_url}/QuitClan"
    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Content-Type': "application/octet-stream",
        'Authorization': f"Bearer {token}",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    response = requests.post(url, data=edata, headers=headers)

    if response.status_code == 200:
        return "Successfully leave clan "
    else:
        return "Failed to leave clan "

async def send_request(encrypted_uid):
    edata = bytes.fromhex(encrypted_uid)
    global token
    url = f"{base_url}/RequestAddingFriend"

    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    response = requests.post(url, data=edata, headers=headers)
    text = response.text.strip()

    if text == "BR_FRIEND_DUPLICATE":
        return "This UID is already in your friend list."

    elif text == "BR_FRIEND_INTIMACY_MORE_THAN_ONE_REQUEST":
        return "Friend request sent successfully!"

    elif text == "BR_FRIEND_MAX_COUNT":
        return "Your friend list is full."

    elif text == "BR_FRIEND_MAX_REQUEST":
        return "The player's request list is full."

    elif text == "BR_FRIEND_NOT_SAME_REGION":
        return "The UID belongs to another region."

    else:
        return text

import aiohttp

async def RemoveFriend(rem_uid):
    encrypted_uid = await RemoveFriendProto(rem_uid)
    edata = bytes.fromhex(encrypted_uid)

    global token
    url = f"{base_url}/RemoveFriend"

    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=edata, headers=headers) as response:
            if response.status == 200:
                return "The provided UID has been deleted successfully."
            else:
                return "Failed to delete the provided UID. Please try again."

async def ConfirmFriend(Confirm_uid):
    encrypted_uid = await ConfirmFriendProto(Confirm_uid)
    edata = bytes.fromhex(encrypted_uid)
    
    global token
    url = f"{base_url}/ConfirmFriendRequest"
    
    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    response = requests.post(url, data=edata, headers=headers)

    if response.status_code == 200:
        return "Your provided UID's friend request has been accepted."
    else:
        return "Failed to accept the friend request. Please try again."
        
async def CancelFriend(cancel_uid):
    encrypted_uid = await CancelFriendProto(cancel_uid)
    edata = bytes.fromhex(encrypted_uid)
    
    global token
    url = f"{base_url}/DeclineFriendRequest"
    
    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    response = requests.post(url, data=edata, headers=headers)

    if response.status_code == 200:
        return "The provided UID has been removed from the pending friend request list."
    else:
        return "Failed to remove the pending friend request. Please try again."

def get_player_info(Id):
    url = "https://bdgamesbazar.com/api/auth/player_id_login"

    headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-MM,en-US;q=0.9,en;q=0.8",
        "Content-Type": "application/json",
        "Origin": "https://bdgamesbazar.com",
        "Referer": "https://bdgamesbazar.com/?channel=221070&item=30310",
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "mark.via.gp",
        "Cookie": "source=mb; region=BD;"
    }

    payload = {
        "app_id": 100067,
        "login_id": str(Id),
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)

        if response.status_code != 200:
            return {"error": f"HTTP {response.status_code}"}

        return response.json()

    except requests.exceptions.Timeout:
        return {"error": "Request Timeout"}
    except requests.exceptions.ConnectionError:
        return {"error": "Connection Error"}
    except Exception as e:
        return {"error": str(e)}
                
async def info_request(encrypted_uid):
    edata = bytes.fromhex(encrypted_uid)
    url = f"{base_url}/GetPlayerPersonalShow"
    global token

    headers = {
        'User-Agent': Uaa(),
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB54"
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=edata, headers=headers, ssl=False) as resp:
            raw = await resp.read()

            decode = player_info_pb2.Info()
            decode.ParseFromString(raw)
            return MessageToJson(decode)


async def emote_send(target_uid, emote_id, key, iv):
    try:
        msg = Emote_pb2.DanseMessage()
        msg.field1 = 21
        inner = msg.field2

        inner.field1 = 16519667180
        inner.field2 = 909000001
        dance = inner.field5

        dance.client_id = int(target_uid)
        dance.dance_id = int(emote_id)

        packet = msg.SerializeToString().hex()
        encrypted_packet = await encrypt_packet(packet, key, iv)
        packet_length = len(encrypted_packet) // 2
        packet_length_hex = await base_to_hex(packet_length)

        if len(packet_length_hex) == 2:
            final_packet = "0515000000" + packet_length_hex + encrypted_packet
        elif len(packet_length_hex) == 3:
            final_packet = "051500000" + packet_length_hex + encrypted_packet
        elif len(packet_length_hex) == 4:
            final_packet = "05150000" + packet_length_hex + encrypted_packet
        elif len(packet_length_hex) == 5:
            final_packet = "05150000" + packet_length_hex + encrypted_packet
        else:
            print(
                "❌ something went wrong, please check create_group function.")

        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()

    except Exception as e:
        print(f"❌ Error while sending emote packet: {e}")

async def invroom(K, V, uid):
    invroom_msg = inv_room_pb2.InvRoom()

    invroom_msg.type = 22
    invroom_msg.data.uid = int(uid)

    proto_bytes = invroom_msg.SerializeToString()
    proto_hex = proto_bytes.hex()

    return await GeneRaTePk(proto_hex, "0E15", K, V)

async def new_lag(K, V):
    root = lag_pb2.Lag()

    root.field_1 = 15
    root.field_2.SetInParent()
    root.field_2.field_1 = 16519667180
    root.field_2.field_2 = 1

    proto_hex = root.SerializeToString().hex()
    packet_type = "0515"

    return await GeneRaTePk(proto_hex, packet_type, K, V)

async def Kick(PlayerId, key, iv):
    kick = kick_pb2.Kick()

    kick.field_1 = 35
    kick.field_2.field_1 = int(PlayerId)

    proto_hex = kick.SerializeToString().hex()

    return await GeneRaTePk(proto_hex, "0519", key, iv)

async def create_clan_startup(clan_id, clan_compiled_data, key, iv):
    proto = Clan_Startup_pb2.ClanPacket()
    proto.Clan_Pos = 3
    proto.Data.Clan_ID = int(clan_id)
    proto.Data.Clan_Type = 1
    proto.Data.Clan_Compiled_Data = clan_compiled_data
    packet = proto.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)
    if len(packet_length_hex) == 2:
        final_packet = "1201000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "120100000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "12010000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "1201000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check clan startup function.")
    if whisper_writer:  # <--- FIX: Check if writer is available
        whisper_writer.write(bytes.fromhex(final_packet))
        await whisper_writer.drain()


async def create_group(key, iv):
    packet = "080112bc04120101180120032a02656e420d0a044944433110661a03494e444801520601090a121920580168017288040a403038303230303032433733464233454430323031303030303030303030303030303030303030303030303030303030303137424236333544303930303030303010151a8f0375505d5413070448565556000b5009070405500303560a08030354550007550f02570d03550906521702064e76544145491e0418021e11020b4d1a42667e58544776725757486575441f5a584a065b46426a5a65650e14034f7e5254047e005a7b7c555c0d5562637975670a7f765b0102537906091702044e72747947457d0d6267456859587b596073435b7205046048447d080b170c4f584a6b007e4709740661625c545b0e7458405f5e4e427f486652420c13070c484b597a717a5a5065785d4343535d7c7a6450675a787e05736418010c12034a475b71717a566360437170675a6b1c740748796065425e017e4f5d0e1a034d09660358571843475c774b5f524d47670459005a4870780e795e7a0a110a457e5e5a00776157597069094266014f716d7246754a60506b747404091005024f7e765774035967464d687c724703075d4e76616f7a184a7f057a6f0917064b5f797d05434250031b0555717b0d00611f59027e60077b4a0a5c7c0d1500480143420b5a65746803636e41556a511269087e4f5f7f675c0440600c22047c5c5754300b3a1a16024a424202050607021316677178637469785d51745a565a5a4208312e3130392e3136480650029801c902aa01024f52"
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)
    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check create_group function.")
    if online_writer:  # <--- FIX: Check if writer is available
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()

async def join_teamcode(room_id, key, iv):
    room_id_hex = ''.join(format(ord(c), 'x') for c in room_id)
    packet = f"080412b305220601090a1219202a07{room_id_hex}300640014ae8040a80013038304639324231383633453135424630323031303130303030303030303034303031363030303130303131303030323944373931333236303930303030353934313732323931343030303030303030303030303030303030303030303030303030303030303030303030303030666630303030303030306639396130326538108f011abf0377505d571709004d0b060b070b5706045c53050f065004010902060c09065a530506010851070a081209064e075c5005020808530d0604090b05050d0901535d030204005407000c5653590511000b4d5e570e02627b6771616a5560614f5e437f7e5b7f580966575b04010514034d7d5e5b465078697446027a7707506c6a5852526771057f5260504f0d1209044e695f0161074e46565a5a6144530174067a43694b76077f4a5f1d6d05130944664456564351667454766b464b7074065a764065475f04664652010f1709084d0a4046477d4806661749485406430612795b724e7a567450565b010c1107445e5e72780708765b460c5e52024c5f7e5349497c056e5d6972457f0c1a034e60757840695275435f651d615e081e090e75457e7464027f5656750a1152565f545d5f1f435d44515e57575d444c595e56565e505b555340594c5708740b57705c5b5853670957656a03007c04754c627359407c5e04120b4861037b004f6b744001487d506949796e61406a7c44067d415b0f5c0f120c4d54024c6a6971445f767d4873076e5f48716f537f695a7365755d520514064d515403717b72034a027d736b6053607e7553687a61647d7a686c610d22047c5b5655300b3a0816647b776b721c144208312e3130382e3134480350025a0c0a044944433110731a0242445a0c0a044944433210661a0242445a0c0a044944433310241a0242446a02656e8201024f52"
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "0519000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051900000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05190000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05190000" + packet_length_hex + encrypted_packet
    else:
        print("Damm Something went wrong, please check join teamcode function")
    if online_writer:  # <--- FIX: Check if writer is available
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()
        
async def send_title_msg(chat_id, key, iv):
    root = krishna_title_pb2.GenTeamTitle()
    root.type = 1
    nested_object = root.data
    nested_object.uid = 16519667180
    nested_object.chat_id = chat_id
    nested_object.title = f"{{\"TitleID\":{get_random_title()},\"type\":\"Title\"}}"
    nested_object.timestamp = int(datetime.now().timestamp())
    nested_object.language = "en"
    nested_details = nested_object.field9
    nested_details.Nickname = "Krishna Coder"
    nested_details.avatar_id = get_random_avatar()
    nested_details.rank = 330
    nested_details.badge = 827001007
    nested_details.Clan_Name = "YGуЕдсОм-ъокъо▓ън╖ъовън▓ъокуЕд"
    nested_details.field10 = 1
    nested_details.global_rank_pos = 1
    nested_details.badge_info.value = 2
    nested_details.prime_info.prime_uid = 1158053040
    nested_details.prime_info.prime_level = 8
    nested_details.prime_info.prime_hex = "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
    nested_options = nested_object.field13
    nested_options.url_type = 2
    nested_options.curl_platform = 1
    nested_object.empty_field.SetInParent()
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    hex_length = await base_to_hex(packet_length)
    packet_prefix = "121500" + "0" * (6 - len(hex_length))
    final_packet = packet_prefix + hex_length + encrypted_packet
    return bytes.fromhex(final_packet)

async def start_autooo(key, iv):
    root = start_game_pb2.start_game()

    root.field_1 = 9
    root.field_2.SetInParent()
    root.field_2.field_1 = 16519667180

    proto_hex = root.SerializeToString().hex()
    packet_type = "0515"

    return await GeneRaTePk(proto_hex, packet_type, key, iv)

async def skwad(uid, key, iv):
    packet = spam_pb2.GameSkwadPacket()
    packet.field1 = 33
    details = packet.field2
    details.user_id = int(uid)
    details.country_code = "IND"
    details.status1 = 1
    details.status2 = 1
    details.numbers = bytes([1, 7, 9, 10, 11, 18, 25, 26, 32])
    details.empty1 = "TG:[C][B][FF0000] KrishnaCoder"
    details.rank = 330
    details.field8 = 1000
    details.region_code = "IND"
    details.uuid = bytes([
        49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
        97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49,
        50, 48, 102, 53
    ])
    details.field12 = 1
    details.repeated_uid = int(uid)
    nested14 = details.field14
    nested14.field1 = 2203434355
    nested14.field2 = 8
    nested14.field3 = "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
    details.field16 = 1
    details.field17 = 1
    details.field18 = 312
    details.field19 = 46
    details.field23 = bytes([16, 1, 24, 1])
    details.avatar = get_random_avatar()
    details.field26.SetInParent()
    details.field28.SetInParent()
    nested27 = details.field27
    nested27.field1 = 11
    nested27.field2 = 12999994075
    nested27.field3 = 9999
    nested31 = details.field31
    nested31.field1 = 1
    values_32 = [1048576, 131072, 262144, 32768, 16384, 8192, 4096, 64]
    random_value = random.choice(values_32)
    nested31.field2 = random_value
    details.field32 = random_value
    nested34 = details.field34
    nested34.field1 = int(uid)
    nested34.field2 = 8
    nested34.field3 = bytes([15, 6, 21, 8, 10, 11, 19, 12, 17, 4, 14, 20, 7, 2, 1, 5, 16, 3, 13, 18])
    packet.lang = "en"
    nested13 = packet.field13
    nested13.field2 = 1
    nested13.field3 = 1
    serialized = packet.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(serialized, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)

    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("❌ Packet length formatting failed.")
        return

    online_writer.write(bytes.fromhex(final_packet))
    await online_writer.drain()


async def modify_team_player(team, key, iv):
    bot_mode = bot_mode_pb2.BotMode()
    bot_mode.key1 = 17
    bot_mode.key2.uid = 16519667180
    bot_mode.key2.key2 = 1
    bot_mode.key2.key3 = int(team)
    bot_mode.key2.key4 = 73
    bot_mode.key2.byte = base64.b64decode("Gg==")
    bot_mode.key2.key8 = 5
    bot_mode.key2.key13 = 227
    packet = bot_mode.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)
    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check create_group function.")
    if online_writer:  # <--- FIX: Check if writer is available
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()


async def invite_target(uid, key, iv):
    invite = bot_invite_pb2.invite_uid()
    invite.num = 2
    invite.Func.uid = int(uid)
    invite.Func.region = "IND"
    invite.Func.number = 1
    packet = invite.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)
    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check create_group function.")
    if online_writer:  # <--- FIX: Check if writer is available
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()

async def left_group(key, iv):
    root = left_group_pb2.LeftGroup()
    root.field_1 = 7
    root.field_2.field_1 = 16519667180
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    packet_length_hex = await base_to_hex(packet_length)
    if len(packet_length_hex) == 2:
        final_packet = "0515000000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 3:
        final_packet = "051500000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 4:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    elif len(packet_length_hex) == 5:
        final_packet = "05150000" + packet_length_hex + encrypted_packet
    else:
        print("something went wrong, please check create_group function.")
    if online_writer:  # <--- FIX: Check if writer is available
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()


async def join_room(uid, room_id, key, iv):
    root = spam_join_pb2.spam_join()
    root.field_1 = 78
    root.field_2.field_1 = int(room_id)
    root.field_2.name = "Krishna Coder"
    root.field_2.field_3.field_2 = 1
    root.field_2.field_3.field_3 = 1
    root.field_2.field_4 = 330
    root.field_2.field_5 = 1570
    root.field_2.field_6 = 311
    root.field_2.field_10 = get_random_avatar()
    root.field_2.field_11 = int(uid)
    root.field_2.field_12 = 1
    root.field_2.field_15.field_1 = 1
    values_15_2 = [1048576, 131072, 262144, 32768, 16384, 8192, 4096, 64]
    random_value_15_2 = random.choice(values_15_2)
    root.field_2.field_15.field_2 = random_value_15_2
    root.field_2.field_16 = random_value_15_2
    root.field_2.field_18.field_1 = 2203434355
    root.field_2.field_18.field_2 = 8
    root.field_2.field_18.field_3 = "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
    packet = root.SerializeToString().hex()
    packet_encrypt = await encrypt_packet(packet, key, iv)
    base_len = await base_to_hex(int(len(packet_encrypt) // 2))
    if len(base_len) == 2:
        header = "0e15000000"
    elif len(base_len) == 3:
        header = "0e1500000"
    elif len(base_len) == 4:
        header = "0e150000"
    elif len(base_len) == 5:
        header = "0e15000"
    final_packet = header + base_len + packet_encrypt
    online_writer.write(bytes.fromhex(final_packet))
    await online_writer.drain()

async def RoomJoin(room_id, password, key, iv):

    root = room_join_pb2.join_room()

    # Main field
    root.field_1 = 3

    # -------------------------
    #      NESTED OBJECT
    # -------------------------
    nested_object = root.field_2
    nested_object.field_1 = int(room_id)
    nested_object.field_2 = str(password)

    # ---- field_8 ----
    nested_8 = nested_object.field_8
    nested_8.field_1 = "IDC3"
    nested_8.field_2 = 149
    nested_8.field_3 = "IND"

    # ---- other fields ----
    nested_object.field_9  = "\u0001\u0003\u0004\u0007\t\n\u000b\u0012\u000e\u0016\u0019 \u001d"
    nested_object.field_10 = 1
    nested_object.field_12.SetInParent()
    nested_object.field_13 = 1
    nested_object.field_14 = 1
    nested_object.field_16 = "en"

    # ---- field_22 ----
    nested_22 = nested_object.field_22
    nested_22.field_1 = 21

    # -------------------------
    #     Serialize Packet
    # -------------------------
    packet_hex = root.SerializeToString().hex()

    # Encrypt
    encrypted_packet = await encrypt_packet(packet_hex, key, iv)
    packet_length   = len(encrypted_packet) // 2
    packet_len_hex  = await base_to_hex(packet_length)

    # -------------------------
    #   HEADER FORMATTER
    # -------------------------
    if len(packet_len_hex) == 2:
        header = "0e15000000"
    elif len(packet_len_hex) == 3:
        header = "0e1500000"
    elif len(packet_len_hex) == 4:
        header = "0e150000"
    elif len(packet_len_hex) == 5:
        header = "0e15000"

    final_packet = header + packet_len_hex + encrypted_packet

    # Send packet
    online_writer.write(bytes.fromhex(final_packet))
    await online_writer.drain()

async def KrishnaLeaveRoom(uid, key, iv):
    try:
        # Create main protobuf root
        root = room_join_pb2.join_room()

        # Main type or action field
        root.field_1 = 6

        # NESTED OBJECT (room leave details)
        nested_object = root.field_2
        nested_object.field_1 = int(uid)   # UID of player leaving the room

        # Some optional safety fields (common in your app.py packets)
        nested_object.field_8.field_1 = "IDC3"
        nested_object.field_8.field_2 = 149
        nested_object.field_8.field_3 = "IND"

        nested_object.field_9 = "\u0001\u0003\u0004\u0007\t\n\u000b\u0012\u000e\u0016\u0019 \u001d"
        nested_object.field_10 = 1
        nested_object.field_13 = 1
        nested_object.field_14 = 1
        nested_object.field_16 = "en"
        nested_object.field_22.field_1 = 21

        # Serialize to bytes → hex
        packet_hex = root.SerializeToString().hex()

        # Encrypt the packet
        encrypted_packet = await encrypt_packet(packet_hex, key, iv)
        packet_length = len(encrypted_packet) // 2
        packet_len_hex = await base_to_hex(packet_length)

        # Header formation (same as RoomJoin)
        if len(packet_len_hex) == 2:
            header = "0e15000000"
        elif len(packet_len_hex) == 3:
            header = "0e1500000"
        elif len(packet_len_hex) == 4:
            header = "0e150000"
        elif len(packet_len_hex) == 5:
            header = "0e15000"

        final_packet = header + packet_len_hex + encrypted_packet

        return bytes.fromhex(final_packet)

    except Exception as e:
        print(f"Error in KrishnaLeaveRoom: {e}")
        return None


async def send_clan_msg(msg, chat_id, key, iv):
    root = clan_msg_pb2.clan_msg()
    root.type = 1
    nested_object = root.data
    nested_object.uid = 16519667180
    nested_object.chat_id = chat_id
    nested_object.chat_type = 1
    nested_object.msg = msg
    nested_object.timestamp = int(datetime.now().timestamp())
    nested_object.language = "en"
    nested_object.empty_field.SetInParent()
    nested_details = nested_object.field9
    nested_details.Player_Name = "Krishna Coder"
    nested_details.avatar_id = get_random_avatar()
    nested_details.banner_id = 901000173
    nested_details.rank = 330
    nested_details.badge = 827001007
    nested_details.Clan_Name = "★I᷈N᷈D᷈I᷈A᷈★"
    nested_details.field10 = 1
    nested_details.rank_point = 1
    nested_badge = nested_details.field13
    nested_badge.value = 2
    nested_prime = nested_details.field14
    nested_prime.prime_uid = 1158053040
    nested_prime.prime_level = 8
    nested_prime.prime_hex = "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
    nested_options = nested_object.field13
    nested_options.url = "https://graph.facebook.com/v9.0/147045590125499/picture?width=160&height=160"
    nested_options.url_type = 1
    nested_options.url_platform = 1
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    hex_length = await base_to_hex(packet_length)
    if len(hex_length) == 2:
        final_packet = "1215000000" + hex_length + encrypted_packet
    elif len(hex_length) == 3:
        final_packet = "121500000" + hex_length + encrypted_packet
    elif len(hex_length) == 4:
        final_packet = "12150000" + hex_length + encrypted_packet
    elif len(hex_length) == 5:
        final_packet = "1215000" + hex_length + encrypted_packet
    return bytes.fromhex(final_packet)


# <--- CORRECTED FUNCTION as requested--->



async def send_team_msg(msg, chat_id, key, iv):
    root = Title_pb2.GenTeamTitle()
    root.type = 1
    nested_object = root.data
    nested_object.msg = msg
    nested_object.chat_id = chat_id
    nested_object.timestamp = int(datetime.now().timestamp())
    nested_object.chat_type = 6
    nested_object.language = "en"
    nested_details = nested_object.field9
    nested_details.Nickname = "Krishna Coder"
    nested_details.avatar_id = get_random_avatar()
    nested_details.rank = 330
    nested_details.badge = 827001007
    nested_details.Clan_Name = "YGㅤᎬ-ꮪꮲꭷꮢꭲꮪㅤ"
    nested_details.field10 = 1
    nested_details.global_rank_pos = 1
    nested_details.badge_info.value = 2
    nested_details.prime_info.prime_uid = 1158053040
    nested_details.prime_info.prime_level = 8
    nested_details.prime_info.prime_hex = "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
    nested_options = nested_object.field13
    nested_options.url_type = 2
    nested_options.curl_platform = 1
    nested_object.empty_field.SetInParent()
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    hex_length = await base_to_hex(packet_length)
    packet_prefix = "121500" + "0" * (6 - len(hex_length))
    final_packet = packet_prefix + hex_length + encrypted_packet
    return bytes.fromhex(final_packet)


async def send_msg(msg, chat_id, key, iv):
    root = GenWhisperMsg_pb2.GenWhisper()
    root.type = 1
    nested_object = root.data
    nested_object.uid = 16519667180
    nested_object.chat_id = chat_id
    nested_object.chat_type = 2
    nested_object.msg = msg
    nested_object.timestamp = int(datetime.now().timestamp())
    nested_details = nested_object.field9
    nested_details.Nickname = "Krishna Coder"
    nested_details.avatar_id = get_random_avatar()
    nested_details.banner_id = 901000173
    nested_details.rank = 330
    nested_details.badge = 827001007
    nested_details.Clan_Name = "★I᷈N᷈D᷈I᷈A᷈★"
    nested_details.field10 = 1
    nested_details.global_rank_pos = 1
    nested_badge = nested_details.field13
    nested_badge.value = 2  # Example value
    nested_prime = nested_details.field14
    nested_prime.prime_uid = 1158053040
    nested_prime.prime_level = 8
    nested_prime.prime_hex = "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
    nested_options = nested_object.field13
    nested_object.language = "en"
    nested_options = nested_object.field13
    nested_options.url = "https://graph.facebook.com/v9.0/147045590125499/picture?width=160&height=160"
    nested_options.url_type = 2
    nested_options.url_platform = 1
    root.data.Celebrity = 1919408565318037500
    root.data.empty_field.SetInParent()
    packet = root.SerializeToString().hex()
    encrypted_packet = await encrypt_packet(packet, key, iv)
    packet_length = len(encrypted_packet) // 2
    hex_length = await base_to_hex(packet_length)

    if len(hex_length) == 2:
        final_packet = "1215000000" + hex_length + encrypted_packet
    elif len(hex_length) == 3:
        final_packet = "121500000" + hex_length + encrypted_packet
    elif len(hex_length) == 4:
        final_packet = "12150000" + hex_length + encrypted_packet
    elif len(hex_length) == 5:
        final_packet = "1215000" + hex_length + encrypted_packet

    return bytes.fromhex(final_packet)


async def get_encrypted_startup(AccountUID, token, timestamp, key, iv):
    uid_hex = hex(AccountUID)[2:]
    uid_length = len(uid_hex)
    encrypted_timestamp = await base_to_hex(timestamp)
    encrypted_account_token = token.encode().hex()
    encrypted_packet = await encrypt_packet(encrypted_account_token, key, iv)
    encrypted_packet_length = hex(len(encrypted_packet) // 2)[2:]

    if uid_length == 7:
        headers = '000000000'
    elif uid_length == 8:
        headers = '00000000'
    elif uid_length == 9:
        headers = '0000000'
    elif uid_length == 10:
        headers = '000000'
    elif uid_length == 11:
        headers = '00000'
    else:
        print('Unexpected length, Please Try again')
        headers = '0000000'  # Default fallback

    packet = f"0115{headers}{uid_hex}{encrypted_timestamp}00000{encrypted_packet_length}{encrypted_packet}"
    return packet


async def Encrypt(number):
    number = int(number)
    encoded_bytes = []

    while True:
        byte = number & 0x7F
        number >>= 7
        if number:
            byte |= 0x80

        encoded_bytes.append(byte)
        if not number:
            break
    return bytes(encoded_bytes).hex()


async def uid_status(uid, key, iv):
    uid_text = {await Encrypt(uid)}
    uid_hex = next(iter(uid_text))
    packet = f"080112e8010ae301afadaea327bfbd809829a8fe89db07eda4c5f818f8a485850eefb3a39e06{uid_hex}ecb79fd623e4b3c0f506c6bdc48007d4efbc7ce688be8709c99ef7bc02e0a8bcd607d6ebe8e406dcc9a6ae07bfdab0e90a8792c28d08b58486f528cfeff0c61b95fcee8b088f96da8903effce2b726b684fbe10abfe984db28bbfebca528febd8dba28ecb98cb00baeb08de90583f28a9317a5ced6ab01d3de8c71d3a1b1be01ede292e907e5ecd0b903b2cafeae04c098fae5048cfcc0cd18d798b5f401cd9cbb61e8dce3c00299b895de1184e9c9ee11c28ed0d803f8b7ffec02a482babd011001"

    encrypted_packet = await encrypt_packet(packet, key, iv)
    header_length = len(encrypted_packet) // 2

    header_length_hex = await base_to_hex(header_length)

    if len(header_length_hex) == 2:
        final_packet = "0f15000000" + header_length_hex + encrypted_packet
    elif len(header_length_hex) == 3:
        final_packet = "0f1500000" + header_length_hex + encrypted_packet
    elif len(header_length_hex) == 4:
        final_packet = "0f150000" + header_length_hex + encrypted_packet
    elif len(header_length_hex) == 5:
        final_packet = "0f150000" + header_length_hex + encrypted_packet
    else:
        raise ValueError("error 505")

    if online_writer:  # <--- FIX: Check if writer is available
        online_writer.write(bytes.fromhex(final_packet))
        await online_writer.drain()


from threading import Lock
import sqlite3
from datetime import datetime
import time


async def handle_tcp_online_connection(ip,
                                       port,
                                       key,
                                       iv,
                                       encrypted_startup,
                                       reconnect_delay=0):
    global online_writer, spam_room, whisper_writer, spammer_uid, spam_chat_id, spam_uid

    # ADD THESE VARIABLES
    insquad = None
    joining_team = False

    while True:
        try:
            reader, writer = await asyncio.open_connection(ip, int(port))
            online_writer = writer

            bytes_payload = bytes.fromhex(encrypted_startup)
            online_writer.write(bytes_payload)
            await online_writer.drain()

            while True:
                data = await reader.read(9999)
                if not data:
                    break
                if data.hex().startswith("0f00"):
                    try:
                        json_result = await get_available_room(data.hex()[10:])
                        if json_result:
                            parsed_data = json.loads(json_result)

                           
                            if ("5" in parsed_data and
                                "data" in parsed_data["5"] and
                                "1" in parsed_data["5"]["data"] and
                                "data" in parsed_data["5"]["data"]["1"] and
                                "3" in parsed_data["5"]["data"]["1"]["data"] and
                                "data" in parsed_data["5"]["data"]["1"]["data"]["3"] and
                                parsed_data["5"]["data"]["1"]["data"]["3"]["data"] == 1 and
                                "11" in parsed_data["5"]["data"]["1"]["data"] and
                                "data" in parsed_data["5"]["data"]["1"]["data"]["11"] and
                                parsed_data["5"]["data"]["1"]["data"]["11"]["data"] == 1):

                                print(" Condition met: Player is in specific status (3=1 and 11=1)")

                                # UID EXTRACT Krishna
                                if "1" in parsed_data["5"]["data"]["1"]["data"] and "data" in parsed_data["5"]["data"]["1"]["data"]["1"]:
                                    uid = parsed_data["5"]["data"]["1"]["data"]["1"]["data"]
                                    print(f"Player UID: {uid}")

                             

                    except Exception as e:
                        print(f"Error processing status data: {e}")

                  
                    if spam_room:
                        try:
                            if json_result:
                                parsed_data = json.loads(json_result)
                                if ("5" in parsed_data and "data" in parsed_data["5"]
                                        and "1" in parsed_data["5"]["data"]
                                        and "data" in parsed_data["5"]["data"]["1"]
                                        and "15" in parsed_data["5"]["data"]["1"]["data"]
                                        and "data" in parsed_data["5"]["data"]["1"]["data"]["15"]):

                                    room_id = parsed_data["5"]["data"]["1"]["data"]["15"]["data"]
                                    uid = parsed_data["5"]["data"]["1"]["data"]["1"]["data"]
                                    spam_room = False
                                    message = (
                                        f"Spamming on\n\n"
                                        f"Room ID: {str(room_id)[:5]}[C]{str(room_id)[5:]}\n"
                                        f"UID: {str(uid)[:5]}[C]{str(uid)[5:]}"
                                    )

                                    if spam_chat_id == 1:
                                        msg_packet = await send_team_msg(message, spam_uid, key, iv)
                                    elif spam_chat_id == 2:
                                        msg_packet = await send_clan_msg(message, spam_uid, key, iv)
                                    else:
                                        msg_packet = await send_msg(message, spam_uid, key, iv)

                                    if whisper_writer:
                                        whisper_writer.write(msg_packet)
                                        await whisper_writer.drain()

                                    start_time = time.time()
                                    while time.time() - start_time < 60:
                                        await join_room(uid, room_id, key, iv)
                                        await asyncio.sleep(0.3)

                                else:
                                    message = "Player not in room"

                                    if spam_chat_id == 1:
                                        msg_packet = await send_team_msg(message, spam_uid, key, iv)
                                    elif spam_chat_id == 2:
                                        msg_packet = await send_clan_msg(message, spam_uid, key, iv)
                                    else:
                                        msg_packet = await send_msg(message, spam_uid, key, iv)

                                    if whisper_writer:
                                        whisper_writer.write(msg_packet)
                                        await whisper_writer.drain()

                                    spam_room = False

                        except Exception as e:
                            print(f"Error processing room data: {e}")
                            spam_room = False


                if AUTO_JOIN_ENABLED and data.hex().startswith("0500") and insquad is None and not joining_team:
                    try:
                        packet_str = await DeCode_PackEt(data.hex()[10:])
                        packet = json.loads(packet_str)

                        if not isinstance(packet, dict):
                            raise ValueError("invalid packet")

                        if '5' not in packet:
                            raise ValueError("not invite packet")

                        if 'data' not in packet['5']:
                            raise ValueError("invalid invite data")

                        invite_uid = packet['5']['data']['2']['data']['1']['data']
                        squad_owner = packet['5']['data']['1']['data']
                        squad_code = packet['5']['data']['8']['data']
                        
                        refuse_packet = await DEVRefuse(squad_owner, invite_uid, key, iv)
                        if online_writer:
                            online_writer.write(refuse_packet)
                            await online_writer.drain()
                        
                        await skwad(invite_uid, key, iv)
                        
                        insquad = False
                        joining_team = True
                        await asyncio.sleep(0.1)
                        
                    except Exception:
                        pass
                

                if AUTO_JOIN_ENABLED and insquad == False and joining_team:
                    try:
                        await asyncio.sleep(0.5)

                        join_packet = await DEVAccepted(squad_owner, squad_code, key, iv)
                        if online_writer:
                            online_writer.write(join_packet)
                            await online_writer.drain()
                        
                        print(f"Auto-joined squad {squad_code} from owner {squad_owner}")

                        # ===== SAFE EMOTE (NON-BLOCKING) =====
                        async def _send_emote():
                            try:
                                await asyncio.sleep(0.80)
                                bundles = {
                                "midnight-ace": 914048001,
                                "aurora": 914047002,
                                "naruto": 914047001,
                                "paradox": 914044001,
                                "frostfire": 914042001,
                                "rampage": 914000002,
                                "wolf": 914000003,
                                "devil": 914038001,
                                "scorpio": 914039001,
                                "dreamspace": 914051001,
                                "eclipse": 914053001,
                                "itachi": 914050001,
                                }                            
                                bundle_name, bundle_id = random.choice(list(bundles.items()))
                                fixed_emote = 909050009
                                await emote_send(invite_uid, fixed_emote, key, iv)
                                await Krishna_Animation(bundle_id, key, iv)
                                await asyncio.sleep(2.9)
                                await Krishna_Bundle(bundle_id, key, iv)
                                await asyncio.sleep(0.2)
                                await emote_send(AccountUID, fixed_emote, key, iv)
                            except Exception:
                                pass

                        asyncio.create_task(_send_emote())
                        # ====================================

                        insquad = None
                        joining_team = False
                        
                    except Exception:
                        pass

                elif data.hex().startswith("0500000"):
                    try:
                        response = await decode_team_packet(data.hex()[10:])
                        if response.packet_type == 6:
                            player_uid = response.details.player_uid
                            team_session = response.details.team_session

                            print(f"Team Packet Type 6 Received:")
                            print(f"Player UID: {player_uid}")
                            print(f"Team Session: {team_session}")

                            team_id = f"team_{int(time.time())}_{player_uid}"

                            await store_team_session_permanent(
                                team_id, team_session, player_uid)

                            await team_chat_startup(player_uid, team_session,
                                                    key, iv)

                    except Exception as e:
                        print(f"Error processing team packet: {e}")

            online_writer.close()
            await online_writer.wait_closed()
            online_writer = None

        except Exception as e:
            print(f"Error with {ip}:{port} - {e}")
            online_writer = None

        await asyncio.sleep(reconnect_delay)


async def store_team_session_permanent(team_id, team_session, creator_uid):
    try:
        conn = sqlite3.connect('permanent_teams.db', check_same_thread=False)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS permanent_team_sessions (
                team_id TEXT PRIMARY KEY,
                team_session TEXT NOT NULL,
                creator_uid INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                member_count INTEGER DEFAULT 1,
                total_messages INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                metadata TEXT
            )
        ''')

        cursor.execute(
            '''
            INSERT OR REPLACE INTO permanent_team_sessions 
            (team_id, team_session, creator_uid, last_active, is_active)
            VALUES (?, ?, ?, ?, ?)
        ''', (team_id, team_session, creator_uid, datetime.now(), True))

        conn.commit()
        conn.close()

        print(f"Team session stored permanently: {team_id}")
        return True

    except Exception as e:
        print(f"Error storing team session: {e}")
        # Drop and recreate table if schema mismatch
        if "no column" in str(e):
            await recreate_team_sessions_table()
            return await store_team_session_permanent(team_id, team_session,
                                                      creator_uid)
        return False


async def recreate_team_sessions_table():
    """Recreate the table with correct schema"""
    try:
        conn = sqlite3.connect('permanent_teams.db', check_same_thread=False)
        cursor = conn.cursor()

        cursor.execute('DROP TABLE IF EXISTS permanent_team_sessions')

        cursor.execute('''
            CREATE TABLE permanent_team_sessions (
                team_id TEXT PRIMARY KEY,
                team_session TEXT NOT NULL,
                creator_uid INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                member_count INTEGER DEFAULT 1,
                total_messages INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                metadata TEXT
            )
        ''')

        conn.commit()
        conn.close()
        print("Team sessions table recreated with correct schema")
        return True
    except Exception as e:
        print(f"Error recreating table: {e}")
        return False


async def get_permanent_team_session(team_id):
    try:
        conn = sqlite3.connect('permanent_teams.db', check_same_thread=False)
        cursor = conn.cursor()

        cursor.execute(
            '''
            SELECT team_session, creator_uid, last_active, is_active 
            FROM permanent_team_sessions WHERE team_id = ?
        ''', (team_id, ))

        result = cursor.fetchone()
        conn.close()

        if result:
            return {
                'team_session': result[0],
                'creator_uid': result[1],
                'last_active': result[2],
                'is_active': result[3]
            }
        return None

    except Exception as e:
        print(f"Error retrieving team session: {e}")
        return None


async def update_team_activity(team_id, message_count=0):
    try:
        conn = sqlite3.connect('permanent_teams.db', check_same_thread=False)
        cursor = conn.cursor()

        if message_count > 0:
            cursor.execute(
                '''
                UPDATE permanent_team_sessions 
                SET last_active = ?, total_messages = total_messages + ?, 
                    member_count = member_count + 1
                WHERE team_id = ?
            ''', (datetime.now(), message_count, team_id))
        else:
            cursor.execute(
                '''
                UPDATE permanent_team_sessions 
                SET last_active = ?
                WHERE team_id = ?
            ''', (datetime.now(), team_id))

        conn.commit()
        conn.close()
        return True

    except Exception as e:
        print(f"Error updating team activity: {e}")
        return False


# Fix for DecodeWhisperMessage error
async def DecodeWhisperMessage(hex_packet, retries=3, delay=0.5):
    for attempt in range(1, retries + 1):
        try:
            if not hex_packet or len(hex_packet) < 10:
                return None

            packet = bytes.fromhex(hex_packet)
            proto = DecodeWhisperMsg_pb2.DecodeWhisper()
            proto.ParseFromString(packet)
            return proto
        except Exception as e:
            print(f"[DecodeWhisperMessage Error] Attempt {attempt}: {e}")
            if attempt < retries:
                await asyncio.sleep(delay)
            else:
                return None


# Simple TeamChatData class
class TeamChatData:

    def __init__(self,
                 team_id,
                 team_session,
                 chat_id,
                 members=None,
                 messages=None,
                 created_at=None,
                 last_activity=None):
        self.team_id = team_id
        self.team_session = team_session
        self.chat_id = chat_id
        self.members = members if members else set()
        self.messages = messages if messages else []
        self.created_at = created_at if created_at else time.time()
        self.last_activity = last_activity if last_activity else time.time()


class PermanentTeamManager:

    def __init__(self):
        self.teams = {}
        self.user_teams = {}
        self.lock = Lock()
        self.permanent_db = "permanent_teams.db"
        self.init_permanent_database()

    def init_permanent_database(self):
        conn = sqlite3.connect(self.permanent_db, check_same_thread=False)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS permanent_team_sessions (
                team_id TEXT PRIMARY KEY,
                team_session TEXT NOT NULL,
                chat_id INTEGER,
                creator_uid INTEGER,
                created_at REAL,
                last_activity REAL,
                total_messages INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                session_data TEXT
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS team_messages_archive (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                team_id TEXT,
                timestamp REAL,
                uid INTEGER,
                user_name TEXT,
                message TEXT,
                chat_type INTEGER
            )
        ''')

        conn.commit()
        conn.close()

        self.load_permanent_teams()

    def load_permanent_teams(self):
        conn = sqlite3.connect(self.permanent_db, check_same_thread=False)
        cursor = conn.cursor()

        cursor.execute(
            'SELECT * FROM permanent_team_sessions WHERE is_active = 1')
        rows = cursor.fetchall()

        for row in rows:
            team_id, team_session, chat_id, creator_uid, created_at, last_activity, total_messages, is_active, session_data = row

            team_data = TeamChatData(team_id=team_id,
                                     team_session=team_session,
                                     chat_id=chat_id or 0,
                                     created_at=created_at or time.time(),
                                     last_activity=last_activity
                                     or time.time())

            self.teams[team_id] = team_data
            if creator_uid:
                self.user_teams[creator_uid] = team_id

        print(f"Loaded {len(self.teams)} permanent teams from database")
        conn.close()

    def add_team(self, team_id, team_session, chat_id, creator_uid):
        with self.lock:
            if team_id not in self.teams:
                team_data = TeamChatData(team_id, team_session, chat_id)
                team_data.members.add(creator_uid)
                self.teams[team_id] = team_data
                self.user_teams[creator_uid] = team_id

    def add_member(self, team_id, user_uid):
        with self.lock:
            if team_id in self.teams:
                self.teams[team_id].members.add(user_uid)
                self.user_teams[user_uid] = team_id

    def add_message(self, team_id, message_data):
        with self.lock:
            if team_id in self.teams:
                self.teams[team_id].messages.append(message_data)


permanent_team_manager = PermanentTeamManager()


async def handle_team_message(uid, user_name, message, chat_id, chat_type):
    if chat_type == 0:
        team_id = f"team_{chat_id}"

        if team_id not in permanent_team_manager.teams:
            permanent_team_manager.add_team(team_id, "auto_generated", chat_id,
                                            uid)
        else:
            permanent_team_manager.add_member(team_id, uid)

        message_data = {
            'timestamp': time.time(),
            'uid': uid,
            'user_name': user_name,
            'message': message,
            'chat_type': chat_type
        }
        permanent_team_manager.add_message(team_id, message_data)

        await update_team_activity(team_id, 1)

        print(f"Team message stored - Team: {team_id}, User: {user_name}")


import asyncio
import aiohttp
import re
import time


async def handle_tcp_connection(ip,
                                port,
                                encrypted_startup,
                                key_param,
                                iv_param,
                                Decode_GetLoginData,
                                ready_event,
                                reconnect_delay=0.5):
    global spam_room, whisper_writer, spammer_uid, spam_chat_id, spam_uid, online_writer, key, iv
    key = key_param
    iv = iv_param

    def get_random_emotes():
        emotes = [
            909000063, 909000068, 909000075, 909000081, 909000085, 909000090,
            909000098, 909051003, 909033001, 909035007, 909037011, 909038010,
            909038012, 909039011, 909040010, 909041005, 909042008, 909045001,
            909049010
        ]
        return random.choice(emotes)

    async def send_response(message, uid, chat_id, chat_type):
        if chat_type == 0:
            msg_packet = await send_team_msg(message, uid, key, iv)
        elif chat_type == 1:
            msg_packet = await send_clan_msg(message, chat_id, key, iv)
        else:
            msg_packet = await send_msg(message, uid, key, iv)
        if whisper_writer:
            whisper_writer.write(msg_packet)
            await whisper_writer.drain()

    async def send_title(chat_id, chat_type):
        if chat_type == 0:
            msg_packet = await send_title_msg(chat_id, key, iv)
            if whisper_writer:
                whisper_writer.write(msg_packet)
                await whisper_writer.drain()

    async def send_chunk(text, uid, chat_id, chat_type, delay=0.1):
        chunks = [text[i:i + 200] for i in range(0, len(text), 200)]
        for chunk in chunks:
            await send_response(chunk, uid, chat_id, chat_type)
            await asyncio.sleep(delay)

    while True:
        session = None
        try:
            reader, writer = await asyncio.open_connection(ip, int(port))
            whisper_writer = writer

            bytes_payload = bytes.fromhex(encrypted_startup)
            whisper_writer.write(bytes_payload)
            await whisper_writer.drain()
            ready_event.set()

            if Decode_GetLoginData.Clan_ID:
                clan_id = Decode_GetLoginData.Clan_ID
                clan_compiled_data = Decode_GetLoginData.Clan_Compiled_Data
                await create_clan_startup(clan_id, clan_compiled_data, key, iv)

            sent_title_teams = set()
            session = aiohttp.ClientSession()

            while True:
                data = await reader.read(9999)
                if not data:
                    break

                if data.hex().startswith("120000"):
                    response = await DecodeWhisperMessage(data.hex()[10:])
                    if response is None:
                        print("Failed to decode whisper message")
                        continue
                    if not hasattr(response, 'Data') or not hasattr(
                            response.Data, 'msg'):
                        print("Response missing expected attributes")
                        continue

                    received_msg = response.Data.msg.lower()
                    uid = response.Data.uid
                    user_name = getattr(response.Data.Details, "Nickname",
                                        "Unknown")
                    chat_id = response.Data.Chat_ID
                    chat_type = response.Data.chat_type

                    if chat_type == 0:
                        team_id = f"team_{chat_id}"
                        is_new_team = team_id not in permanent_team_manager.teams
                        if is_new_team:
                            permanent_team_manager.add_team(
                                team_id, "unknown_session", chat_id, uid)
                            await send_title(chat_id, chat_type)
                            sent_title_teams.add(team_id)
                            print(
                                f"New team session detected - Auto-sent title to team: {team_id}"
                            )
                        else:
                            permanent_team_manager.add_member(team_id, uid)
                        message_data = {
                            'timestamp': time.time(),
                            'uid': uid,
                            'user_name': user_name,
                            'message': response.Data.msg,
                            'chat_type': chat_type
                        }
                        permanent_team_manager.add_message(
                            team_id, message_data)
                        print(
                            f"Team message stored - Team: {team_id}, User: {user_name}, Message: {response.Data.msg}"
                        )

                    if received_msg == "hi":
                        await send_title(chat_id, chat_type)
                        await send_response(f"Hello {user_name}!", uid,
                                            chat_id, chat_type)

                    elif received_msg == "/krishna":
                        await send_title(chat_id, chat_type)
                        krishnaa = (
                                   "                   [B][C][FFFFFF]FREE F[C][B][FFD700]I[B][C][FFFFFF]RE\n\n"
                                   f"[FFFFFF]Hey [FFFF00]{user_name}\n"
                                   "[FFFFFF]Welcome to ᏦʀᎥsʜɴᴀㅤBᴏᴛ\n"
                                    "[B][C][FF0000]╔══════════╗\n"
                                    "[B][C][FFFFFF]✨ If anyone wants to buy TCP bot  \n"
                                    "[B][C][FFFFFF]       ⚡ Or purchase access ❤️  \n"
                                    "[B][C][FFFFFF]               Just contact me...  \n"
                                    "[B][C][FF0000]╠══════════╣\n"
                                    "[B][C][00FF00]⚡ OWNER : [FFFFFF]LEADER KRISHNA\n"
                                    "[B][C][00FF00]⚡ INSTAGRAM : [FFFFFF]@krishnà.cøder\n"
                                    "[B][C][00FF00]✨ TELEGRAM : [FFFFFF]@KrishnáCoder\n"
                                    "[B][C][FF0000]╚══════════╝\n"
                                    "[B][C][00FF00]✨ Developer —͟͞͞ </> KRISHNA ⚡"
                        )        
                        await send_response(krishnaa, uid, chat_id,
                                            chat_type)
                        await asyncio.sleep(0.1)                        
                        coder = f"""                        
[b][c]╭─╮
︱◯֯︱ɪɴѕᴛᴀ┊@krishná.cøder
[ff00ff]╰─╯"""
                        await send_response(coder, uid, chat_id,
                                            chat_type)

                    elif received_msg == "/help":
                        await send_title(chat_id, chat_type)
                        await asyncio.sleep(0.1)
                        welcome = (
                            f"[C][B][FFD700]Hey {user_name} Welcome to {AccountName}!\n\n"
                            "[C][B][FFFFFF]Type commands to interact with me.\n"
                            "[C][B][00FF00]Below are all available commands:")
                        await send_response(welcome, uid, chat_id, chat_type)
                        await asyncio.sleep(0.1)

                        group_commands = (
                            "[C][B][FFD700]🔹 GROUP CREATION 🔹\n\n"
                            "[C][FFFFFF]/2 [00FF00]- Create 2 Player Group\n"
                            "[C][FFFFFF]/3 [00FF00]- Create 3 Player Group\n"
                            "[C][FFFFFF]/4 [00FF00]- Create 4 Player Group\n"
                            "[C][FFFFFF]/5 [00FF00]- Create 5 Player Group\n"
                            "[C][FFFFFF]/6 [00FF00]- Create 6 Player Group\n"
                            "[C][FFFFFF]/team [00FF00]- Create Lag Team Player Group\n"
                            "[C][FFFFFF]/tc [teamcode] [00FF00]- Join Team by Code\n"
                            "[C][FFFFFF]/exit [00FF00]- Leave Current Group\n"
                            "[C][FFFFFF]/join_room [room_id] [password] [00FF00]- Join Room\n"
                            "[C][FFFFFF]/exit_room [room_id] [00FF00]- Leave Current Room"
                        )
                        await send_response(group_commands, uid, chat_id,
                                            chat_type)
                        await asyncio.sleep(0.1)

                        group_commands2 = (
                            "[C][B][FFD700]🔹 GROUP & ROOM COMMAND 🔹\n\n"
                            "[C][FFFFFF]/inv [uid] [00FF00]- Invite Friends\n"
                            "[C][FFFFFF]/teamcode [00FF00]- Generate Teamcode\n"
                            "[C][FFFFFF]/transfer [uid] [00FF00]- Transfer Team Flag\n"
                            "[C][FFFFFF]/kick [uid] [00FF00]- Kick Player In Team\n"
                            "[C][FFFFFF]/createroom [00FF00]- Create Custom Room\n"
                            "[C][FFFFFF]/invroom [uid] [00FF00]- Invite Player to Room\n"
                            "[C][FFFFFF]/roomlag [room_id] [password] [00FF00]- Lag Room"
                        )
                        await send_response(group_commands2, uid, chat_id,
                                            chat_type)
                        await asyncio.sleep(0.1)

                        spam_commands = (
                            "[C][B][FFD700]🔹 SPAM & INTERACTION 🔹\n\n"
                            "[C][FFFFFF]/room [uid] [00FF00]- Spam Room Invites\n"
                            "[C][FFFFFF]/spam_inv [uid] [00FF00]- Spam Team Invites\n"
                            "[C][FFFFFF]/sm [uid] [00FF00]- Spam Join Requests\n"
                            "[C][FFFFFF]/lag [team-code] [00FF00]- Lag Team Server\n"
                            "[C][FFFFFF]/squadlag [00FF00]- Squad Lag Spam\n"
                            "[C][FFFFFF]/ms [text] [00FF00]- Send Typing Message\n"
                            "[C][FFFFFF]/reject [uid] [00FF00]- Reject Bot Invitation\n"
                            "[C][FFFFFF]/ghost [team-code] [00FF00]- Ghost join Group\n"
                            "[C][FFFFFF]/grouplag [00FF00]- Team Lag Spam\n"
                            "[C][FFFFFF]/start [team-code] [00FF00]- Force Start a Team"
                        )
                        await send_response(spam_commands, uid, chat_id,
                                            chat_type)
                        await asyncio.sleep(0.1)

                        spam_commands2 = (
                            "[C][B][FFD700]🔹 ADMIN COMMAND 🔹\n\n"
                            "[C][FFFFFF]/add [uid] [00FF00]- Send Bot Friend Request\n"
                            "[C][FFFFFF]/remove [uid] [00FF00]- Remove Bot Friend List\n"
                            "[C][FFFFFF]/confirm [uid] [00FF00]- Confirm Player Friend Request\n"
                            "[C][FFFFFF]/cancel [uid] [00FF00]- Cancel Player Friend Request\n"
                            "[C][FFFFFF]/clan [cland_id] [00FF00]- Send Guild Join Request\n"
                            "[C][FFFFFF]/leave_clan [cland_id] [00FF00]- Leave Guild\n"
                            "[C][FFFFFF]/uptime [00FF00]- Check System Status\n"
                            "[C][FFFFFF]/ping [00FF00]- Check Bot Speed\n"
                            "[C][FFFFFF]/restart [00FF00]- Restart Bot"
                        )
                        await send_response(spam_commands2, uid, chat_id,
                                            chat_type)
                        await asyncio.sleep(0.1)

                        info_commands = (
                            "[C][B][FFD700]🔹 PLAYER & BOT INFORMATION 🔹\n\n"
                            "[C][FFFFFF]/info [uid] [00FF00]- Get Player Details\n"
                            "[C][FFFFFF]/region [uid] [00FF00]- Check Account Region\n"
                            "[C][FFFFFF]/check [uid] [00FF00]- Check Ban Status\n"
                            "[C][FFFFFF]/allowed [00FF00]- Check Bot Friend List\n"
                            "[C][FFFFFF]/requestlist [00FF00]- Check Bot Pending Request List\n" 
                            "[C][FFFFFF]/gameupdate [00FF00]- Check Game Update"
                        )
                        await send_response(info_commands, uid, chat_id,
                                            chat_type)
                        await asyncio.sleep(0.1)

                        emote_commands = (
                            "[C][B][FFD700]🔹 EMOTE COMMANDS 🔹\n\n"
                            "[C][FFFFFF]/dance [uid1] [uid2] ... [emoteid] [repeat] [00FF00]- Send dance to players\n"
                            "[C][FFFFFF]/evo [uid1] [uid2] ... [repeat] [00FF00]- Send random evolution dance\n"
                            "[C][FFFFFF]/rmevo [uid1] [uid2] ... [repeat] [00FF00]- Send random evolution dance\n"
                            "[C][FFFFFF]/df [uid1] [uid2] ... [emoteid] [00FF00]- Send loop dance to players"
                        )
                        await send_response(emote_commands, uid, chat_id,
                                            chat_type)
                        await asyncio.sleep(0.1)

                        utility_commands = (
                            "[C][B][FFD700]🔹 UTILITY COMMANDS 🔹\n\n"
                            "[C][FFFFFF]ai on/off [00FF00]- Ask AI Anything\n"
                            "[C][FFFFFF]/bundle [name] [00FF00]- Send bundle to bot\n"
                            "[C][FFFFFF]/help [00FF00]- Show This Menu Again\n"
                            "[C][FFFFFF]/krishna [00FF00]- Show Owner Details"
                        )
                        await send_response(utility_commands, uid, chat_id,
                                            chat_type)

                    elif received_msg.startswith("/dance "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()

                        # Check if last part is a repeat count (1-2 digits)
                        repeat_count = 1
                        if len(parts) >= 3:
                            # Check if last parameter is a number (1-2 digits)
                            if parts[-1].isdigit() and 1 <= len(
                                    parts[-1]) <= 2:
                                repeat_count = int(parts[-1])
                                # Remove the repeat count from parts
                                parts = parts[:-1]

                            if len(
                                    parts
                            ) >= 3:  # Still need at least uids and emote_id
                                try:
                                    emote_id = int(parts[-1])
                                    target_uids = [
                                        int(uid_str) for uid_str in parts[1:-1]
                                    ]

                                    total_sent = 0
                                    for _ in range(repeat_count):
                                        # Send to all UIDs simultaneously using asyncio.gather
                                        tasks = []
                                        for target_uid in target_uids:
                                            tasks.append(
                                                emote_send(
                                                    target_uid, emote_id, key,
                                                    iv))
                                            total_sent += 1

                                        # Send all emotes at once
                                        await asyncio.gather(*tasks)
                                        await asyncio.sleep(0.1)

                                    if repeat_count > 1:
                                        message = f"[C][B][00FF00]Dance command sent {repeat_count} times to {len(target_uids)} players ({total_sent} total emotes)."
                                    else:
                                        message = f"[C][B][00FF00]Dance command sent to {len(target_uids)} players successfully."

                                    # Send response message
                                    await send_response(
                                        message, uid, chat_id, chat_type)

                                except ValueError:
                                    message = "[C][B][FF0000]Invalid format. Use /dance [uid1] [uid2] ... [emoteid] [repeat]"
                                    await send_response(
                                        message, uid, chat_id, chat_type)
                            else:
                                message = "[C][B][FF0000]Invalid format. Use /dance [uid1] [uid2] ... [emoteid] [repeat]"
                                await send_response(message, uid, chat_id,
                                                    chat_type)
                        else:
                            message = "[C][B][FF0000]Invalid format. Use /dance [uid1] [uid2] ... [emoteid] [repeat]"
                            await send_response(message, uid, chat_id,
                                                chat_type)

                    elif received_msg.startswith("/evo "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()

                        # Check if last part is a repeat count (1-2 digits)
                        repeat_count = 1
                        if len(parts) >= 2:
                            # Check if last parameter is a number (1-2 digits)
                            if parts[-1].isdigit() and 1 <= len(
                                    parts[-1]) <= 2:
                                repeat_count = int(parts[-1])
                                # Remove the repeat count from parts
                                parts = parts[:-1]

                            if len(parts) >= 2:  # Still need at least one uid
                                try:
                                    target_uids = [
                                        int(uid_str) for uid_str in parts[1:]
                                    ]

                                    total_sent = 0
                                    for _ in range(repeat_count):
                                        random_emote = get_random_emotes()
                                        # Send to all UIDs simultaneously using asyncio.gather
                                        tasks = []
                                        for target_uid in target_uids:
                                            tasks.append(
                                                emote_send(
                                                    target_uid, random_emote,
                                                    key, iv))
                                            total_sent += 1

                                        # Send all emotes at once
                                        await asyncio.gather(*tasks)
                                        await asyncio.sleep(7.5)

                                    if repeat_count > 1:
                                        message = f"[C][B][00FF00]Evolution dance sent {repeat_count} times to {len(target_uids)} players ({total_sent} total emotes)."
                                    else:
                                        message = f"[C][B][00FF00]Evolution dance sent to {len(target_uids)} players successfully."

                                    # Send response message
                                    await send_response(
                                        message, uid, chat_id, chat_type)

                                except ValueError:
                                    message = "[C][B][FF0000]Invalid format. Use /evo [uid1] [uid2] ... [repeat]"
                                    await send_response(
                                        message, uid, chat_id, chat_type)
                            else:
                                message = "[C][B][FF0000]Invalid format. Use /evo [uid1] [uid2] ... [repeat]"
                                await send_response(message, uid, chat_id,
                                                    chat_type)
                        else:
                            message = "[C][B][FF0000]Invalid format. Use /evo [uid1] [uid2] ... [repeat]"
                            await send_response(message, uid, chat_id,
                                                chat_type)

                    elif received_msg.startswith("/rmevo "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()

                        # Check if last part is a repeat count (1-2 digits)
                        repeat_count = 1
                        if len(parts) >= 2:
                            # Check if last parameter is a number (1-2 digits)
                            if parts[-1].isdigit() and 1 <= len(
                                    parts[-1]) <= 2:
                                repeat_count = int(parts[-1])
                                # Remove the repeat count from parts
                                parts = parts[:-1]

                            if len(parts) >= 2:  # Still need at least one uid
                                try:
                                    target_uids = [
                                        int(uid_str) for uid_str in parts[1:]
                                    ]

                                    total_sent = 0
                                    for _ in range(repeat_count):
                                        tasks = []
                                        for target_uid in target_uids:
                                            # 🔥 HAR UID KE LIYE ALAG EMOTE
                                            random_emote = get_random_emotes()
                                            tasks.append(
                                                emote_send(
                                                    target_uid, random_emote,
                                                    key, iv))
                                            total_sent += 1

                                        # Send all emotes at once
                                        await asyncio.gather(*tasks)
                                        await asyncio.sleep(7.5)

                                    if repeat_count > 1:
                                        message = (
                                            f"[C][B][00FF00]Evolution dance "
                                            f"(multi-emote) sent {repeat_count} times "
                                            f"to {len(target_uids)} players "
                                            f"({total_sent} total emotes)."
                                        )
                                    else:
                                        message = (
                                            f"[C][B][00FF00]Evolution dance "
                                            f"(different emote for each UID) "
                                            f"sent successfully."
                                        )

                                    # Send response message
                                    await send_response(
                                        message, uid, chat_id, chat_type)

                                except ValueError:
                                    message = "[C][B][FF0000]Invalid format. Use /rmevo [uid1] [uid2] ... [repeat]"
                                    await send_response(
                                        message, uid, chat_id, chat_type)
                            else:
                                message = "[C][B][FF0000]Invalid format. Use /rmevo [uid1] [uid2] ... [repeat]"
                                await send_response(message, uid, chat_id,
                                                    chat_type)
                        else:
                            message = "[C][B][FF0000]Invalid format. Use /rmevo [uid1] [uid2] ... [repeat]"
                            await send_response(message, uid, chat_id,
                                                chat_type)

                    elif received_msg.startswith("/df "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()

                        # Check format - needs at least 1 UID + emoteID
                        if len(parts) >= 3:
                            try:
                                # last param always emote id
                                emote_id = int(parts[-1])

                                # same as /dance UID style
                                target_uids = [
                                    int(uid_str) for uid_str in parts[1:-1]
                                ]

                                total_sent = 0

                                # Loop for fast spam
                                for _ in range(200):
                                    tasks = []
                                    for target_uid in target_uids:
                                        tasks.append(
                                            emote_send(
                                                target_uid, emote_id, key, iv
                                            )
                                        )
                                        total_sent += 1

                                    await asyncio.gather(*tasks)
                                    await asyncio.sleep(0.08)

                                message = f"[C][B][00FF00]Loop Dance command sent to {len(target_uids)} players successfully."
                                await send_response(message, uid, chat_id, chat_type)

                            except ValueError:
                                message = "[C][B][FF0000]Invalid format. Use /df [uid1] [uid2] ... [emoteid]"
                                await send_response(message, uid, chat_id, chat_type)
                        else:
                            message = "[C][B][FF0000]Invalid format. Use /df [uid1] [uid2] ... [emoteid]"
                            await send_response(message, uid, chat_id, chat_type)

                    elif received_msg.lstrip().startswith("any"):
                        await send_title(chat_id, chat_type)

                        handled = True  # 🔥 VERY IMPORTANT

                        raw = received_msg
                        leading_spaces = len(raw) - len(raw.lstrip(" "))
                        space_prefix = " " * leading_spaces

                        parts = raw.lstrip().split(maxsplit=1)

                        # argument nahi diya
                        if len(parts) < 2:
                            await send_response(
                                space_prefix + "[C][B][FF0000]EMOTE NOT FOUND!",
                                uid, chat_id, chat_type
                            )
                        else:
                            arg = parts[1].strip().lower()
                            target_uid = uid

                            try:
                                with open("emotes.json", "r", encoding="utf-8") as f:
                                    data = json.load(f)["EMOTES"]

                                numbers = data.get("numbers", {})
                                names = data.get("names", {})

                                found = False

                                # NAME MODE
                                if arg in names:
                                    emote_id = int(names[arg])
                                    show_val = arg.upper()
                                    found = True

                                # NUMBER MODE
                                elif arg.isdigit() and arg in numbers:
                                    emote_id = int(numbers[arg])
                                    show_val = arg
                                    found = True

                                if not found:
                                    await send_response(
                                        space_prefix + "[C][B][FF0000]EMOTE NOT FOUND!",
                                        uid, chat_id, chat_type
                                    )
                                else:
                                    await emote_send(target_uid, emote_id, key, iv)

                                    await send_response(
                                        space_prefix +
                                        f"[B][C][00FF00]RANDOME EMOTE {show_val} ACTIVATED!",
                                        uid, chat_id, chat_type
                                    )

                            except Exception as e:
                                await send_response(
                                    space_prefix + f"[C][B][FF0000]ERROR: {e}",
                                    uid, chat_id, chat_type
                                )

                    elif received_msg.startswith("/sm"):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            target_uid = parts[1]
                            await send_response(
                                "[C][B][FFFFFF]Joining Request Spam Started",
                                uid, chat_id, chat_type)
                            if online_writer:
                                try:
                                    await start_spam_invite(int(target_uid))
                                    final_message = "[C][B][00FF00]Join Request Spam\n [FF0000]Successful"
                                except Exception as e:
                                    final_message = f"[C][B][FF0000]Error during spam: {str(e)}"
                            else:
                                final_message = "[C][B][FF0000]Error: Bot is not connected to the server."
                            await send_response(final_message, uid, chat_id,
                                                chat_type)
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /sm [uid]",
                                uid, chat_id, chat_type)

                    elif received_msg == "/team":
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "Please Accept My Invitation to Join Group.", uid,
                            chat_id, chat_type)
                        await left_group(key, iv)
                        await execute_team_spam(uid)
                        await send_response("Request complete", uid, chat_id,
                                            chat_type)
                        await left_group(key, iv)

                    elif received_msg.startswith("/lag"):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            team_code = parts[1]
                            await send_response(
                                "[C][B][FFFFFF]Lag Spam Started", uid, chat_id,
                                chat_type)
                            if online_writer:
                                try:
                                    await perform_lag_attack(
                                        team_code, key, iv)
                                    final_message = "[C][B][00FF00]Lag Spam\n [FF0000]Successful"
                                except Exception as e:
                                    final_message = f"[C][B][FF0000]Error during spam: {str(e)}"
                            else:
                                final_message = "[C][B][FF0000]Error: Bot is not connected to the server."
                            await send_response(final_message, uid, chat_id,
                                                chat_type)
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /lag [code]",
                                uid, chat_id, chat_type)

                    elif received_msg.startswith("/spam_inv"):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            target_uid = parts[1]
                            await send_response(
                                "[C][B][FFFFFF]Invite Request Spam Started",
                                uid, chat_id, chat_type)
                            if online_writer:
                                try:
                                    await handle_group_spam_invite(
                                        int(target_uid))
                                    final_message = "[C][B][00FF00]Invite Request Spam\n [FF0000]Successful"
                                except Exception as e:
                                    final_message = f"[C][B][FF0000]Error during spam: {str(e)}"
                            else:
                                final_message = "[C][B][FF0000]Error: Bot is not connected to the server."
                            await send_response(final_message, uid, chat_id,
                                                chat_type)
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /spam_inv [uid]",
                                uid, chat_id, chat_type)

                    elif received_msg.startswith("/ms "):
                        await send_title(chat_id, chat_type)
                        raw_message = response.Data.msg[4:].strip()
                        if raw_message:
                            cleaned_message = re.sub(r'[^\x20-\x7E]', '',
                                                     raw_message).replace(
                                                         "(J,", "")
                            cleaned_message = " ".join(cleaned_message.split())
                            for i in range(1, len(cleaned_message) + 1):
                                partial_message = cleaned_message[:i]
                                colored = f"[C][B]{get_random_color()}{partial_message}"
                                await send_response(colored, uid, chat_id,
                                                    chat_type)
                                await asyncio.sleep(0.07)
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /ms [message]",
                                uid, chat_id, chat_type)


                    elif received_msg.startswith("/gameupdate"):
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "[C][B][FFFFFF]Fetching latest Free Fire update info...",
                            uid, chat_id, chat_type
                        )
                        try:
                            update_data = get_freefire_update()
                            if update_data.get("success"):
                                message = (
                                    f"[FFFFFF] Update Date: {update_data.get('update_data', 'N/A')}\n"
                                    f" Countdown: {update_data.get('countdown', 'N/A')}\n"
                                    f"  From Version: {update_data.get('from_version', 'N/A')}\n"
                                    f"  To Version: {update_data.get('to_version', 'N/A')}\n"
                                    f" All Versions: {', '.join(update_data.get('all_versions_found', []))}"
                                )
                            else:
                                message = f"[C][B][FF0000]{update_data.get('error', 'Failed to fetch update info.')}"
                        except Exception as e:
                            message = f"[C][B][FF0000]Error: {str(e)}"
                        await send_response(message, uid, chat_id, chat_type)
            
                                                            
                    elif received_msg.startswith("/check "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            target_uid = parts[1]
                            await send_response(
                                "[C][FFFFFF]Checking ban status...", uid,
                                chat_id, chat_type)
                            try:
                                url = f"http://168.119.49.69:2002/bancheck?uid={target_uid}"
                                async with session.get(url) as resp:
                                    if resp.status == 200:
                                        data = await resp.json()
                                        message = (
                                            f"[FFFFFF] Name: {data.get('name', 'N/A')}\n"
                                            f" UID: {str(data.get('accountId', 'N/A'))[:5]}[C]{str(data.get('accountId', 'N/A'))[5:]}\n"
                                            f" Region: {data.get('region', 'N/A')}\n"
                                            f" Level: {data.get('level', 'N/A')}\n"
                                            f" Likes: {data.get('likes', 'N/A')}\n"
                                            f" Status: {data.get('ban_status', 'N/A')}"
                                        )
                                    else:
                                        message = "[C][FF0000]Failed to check ban status."
                            except Exception as e:
                                message = f"[C][B][FF0000]Error: {e}"
                            await send_response(message, uid, chat_id,
                                                chat_type)
                        else:
                            await send_response(
                                "[C][B][FF0000]Usage: /check [uid]", uid,
                                chat_id, chat_type)
                    
                    elif received_msg.startswith("/region "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            target_uid = parts[1]
                            await send_response(
                                "[C][FFFFFF]Checking region...", uid,
                                chat_id, chat_type)
                            try:
                                url = f"http://185.216.176.215:5003/krishna/region-check?uid={target_uid}"
                                async with session.get(url) as resp:
                                    if resp.status == 200:
                                        data = await resp.json()
                                        message = (
                                            f"[FFFFFF] Name: {data.get('nickname', 'N/A')}\n"
                                            f" Region: {data.get('region', 'N/A')}\n"
                                            f" UID: {str(data.get('uid', 'N/A'))[:5]}[C]{str(data.get('uid', 'N/A'))[5:]}"
                                        )
                                    else:
                                        message = "[C][FF0000]Failed to check region."
                            except Exception as e:
                                message = f"[C][B][FF0000]Error: {e}"
                            await send_response(message, uid, chat_id,
                                                chat_type)
                        else:
                            await send_response(
                                "[C][B][FF0000]Usage: /region [uid]", uid,
                                chat_id, chat_type)


                    elif received_msg.startswith(
                            "/room") or received_msg.startswith("/spam_room"):
                        await send_title(chat_id, chat_type)
                        parts = response.Data.msg.strip().split(maxsplit=1)
                        if len(parts) == 2 and parts[1].isdigit():
                            target_uid = parts[1]
                            await send_response("Please Wait", uid, chat_id,
                                                chat_type)
                            global spam_room, spammer_uid, spam_chat_id, spam_uid
                            if chat_type == 0:
                                spam_chat_id = 1
                                spam_uid = uid
                            elif chat_type == 1:
                                spam_uid = chat_id
                                spam_chat_id = 2
                            else:
                                spam_uid = uid
                                spam_chat_id = 3
                            await uid_status(int(target_uid), key, iv)
                            spam_room = True
                            spammer_uid = uid
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /room [uid]",
                                uid, chat_id, chat_type)

                    elif received_msg.startswith("/like "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            target_uid = parts[1]
                            await send_response(
                                "[C][B][FFFFFF]Sending like, please wait...",
                                uid, chat_id, chat_type)
                            try:
                                url = f"https://krnkike5-eight.vercel.app/like?uid={target_uid}&region=ind&key=7year"
                                async with session.get(url) as resp:
                                    if resp.status == 200:
                                        data = await resp.json()
                                        likes_given = data.get(
                                            'LikesGivenByAPI', 0)
                                        if likes_given > 0:
                                            message = (
                                                f"[C][B]-┌ [FFD700]Like Sent Successfully:\n"
                                                f"[FFFFFF]-├─ Name: {data.get('PlayerNickname', 'N/A')}\n"
                                                f"- ├─ UID: {str(data.get('UID', 'N/A'))[:5]}[C]{str(data.get('UID', 'N/A'))[5:]}\n"
                                                f"- ├─ Likes Before: {data.get('LikesbeforeCommand', 'N/A')}\n"
                                                f"- ├─ Likes Given: {data.get('LikesGivenByAPI', 'N/A')}\n"
                                                f"- └─ Likes After: {data.get('LikesafterCommand', 'N/A')}"
                                            )
                                        else:
                                            message = f"[C][B][FFA500]Max likes already sent to {data.get('PlayerNickname', 'this player')} for today. Try again tomorrow."
                                    else:
                                        message = "[C][B][FF0000]Failed to send like (API error)."
                            except Exception as e:
                                message = f"[C][B][FF0000]Error: {e}"
                            await send_response(message, uid, chat_id,
                                                chat_type)
                        else:
                            await send_response(
                                "[C][B][FF0000]Usage: /like [uid]", uid,
                                chat_id, chat_type)

                    elif received_msg == "/2":
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "Please Accept My Invitation to Join Group.", uid,
                            chat_id, chat_type)
                        await left_group(key, iv)
                        await asyncio.sleep(0.2)
                        await create_group(key, iv)
                        await asyncio.sleep(0.2)
                        await modify_team_player("1", key, iv)
                        await asyncio.sleep(0.05)
                        await invite_target(uid, key, iv)
                        await asyncio.sleep(5)
                        await left_group(key, iv)

                    elif received_msg == "/3":
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "Please Accept My Invitation to Join Group.", uid,
                            chat_id, chat_type)
                        await left_group(key, iv)
                        await asyncio.sleep(0.2)
                        await create_group(key, iv)
                        await asyncio.sleep(0.2)
                        await modify_team_player("2", key, iv)
                        await asyncio.sleep(0.05)
                        await invite_target(uid, key, iv)
                        await asyncio.sleep(5)
                        await left_group(key, iv)

                    elif received_msg == "/4":
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "Please Accept My Invitation to Join Group.", uid,
                            chat_id, chat_type)
                        await create_group(key, iv)
                        await asyncio.sleep(0.2)
                        await modify_team_player("3", key, iv)
                        await asyncio.sleep(0.05)
                        await invite_target(uid, key, iv)
                        await asyncio.sleep(5)
                        await left_group(key, iv)

                    elif received_msg == "/5":
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "Please Accept My Invitation to Join Group.", uid,
                            chat_id, chat_type)
                        await left_group(key, iv)
                        await asyncio.sleep(0.2)                        
                        await create_group(key, iv)
                        await asyncio.sleep(0.2)
                        await modify_team_player("4", key, iv)
                        await asyncio.sleep(0.05)
                        await invite_target(uid, key, iv)
                        await asyncio.sleep(5)
                        await left_group(key, iv)

                    elif received_msg == "/6":
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "Please Accept My Invitation to Join Group.", uid,
                            chat_id, chat_type)
                        await left_group(key, iv)
                        await asyncio.sleep(0.2)
                        await create_group(key, iv)
                        await asyncio.sleep(0.2)
                        await modify_team_player("5", key, iv)
                        await asyncio.sleep(0.05)
                        await invite_target(uid, key, iv)
                        await asyncio.sleep(5)
                        await left_group(key, iv)

                    elif received_msg.startswith("/tc "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            team_code = parts[1]
                            bundles = {
                                "midnight-ace": 914048001,
                                "aurora": 914047002,
                                "naruto": 914047001,
                                "paradox": 914044001,
                                "frostfire": 914042001,
                                "rampage": 914000002,
                                "wolf": 914000003,
                                "devil": 914038001,
                                "scorpio": 914039001,
                                "dreamspace": 914051001,
                                "eclipse": 914053001,
                                "itachi": 914050001,
                            }                            
                            bundle_name, bundle_id = random.choice(list(bundles.items()))
                            await send_response(
                                "Request received. Joining team...", uid,
                                chat_id, chat_type)
                            await join_teamcode(team_code, key, iv)
                            await asyncio.sleep(0.4)

                            # FIXED EMOTE ID = 1
                            fixed_emote = 909050009
                            await emote_send(uid, fixed_emote, key, iv),
                            await Krishna_Animation(bundle_id, key, iv)
                            await asyncio.sleep(2.9)
                            await Krishna_Bundle(bundle_id, key, iv)
                            await asyncio.sleep(0.2)
                            await emote_send(AccountUID, fixed_emote, key, iv)
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /tc [team_code]",
                                uid, chat_id, chat_type)

                    elif received_msg == "/exit":
                        await send_title(chat_id, chat_type)
                        await send_response("Leaving group...", uid, chat_id,
                                            chat_type)
                        await left_group(key, iv)

                    elif received_msg.startswith("/teamcode"):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()

                        if len(parts) == 1:
                            await send_response(
                                "Team code generated successfully.",
                                uid, chat_id, chat_type
                            )

                            packet = await tc(key, iv)
                            online_writer.write(packet)
                            await online_writer.drain()
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /tc",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.startswith("/invroom "):
                        await send_title(chat_id, chat_type)
                        parts = received_msg.strip().split()

                        if len(parts) == 2 and parts[1].isdigit():
                            target_uid = parts[1]

                            await send_response(
                                "Room Invitation sent successfully.",
                                uid, chat_id, chat_type
                            )

                            packet = await invroom(key, iv, target_uid)
                            online_writer.write(packet)
                            await online_writer.drain()
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /invroom <uid>",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.startswith('/createroom'):
                        await send_title(chat_id, chat_type)
                        try:
                            parts = received_msg.split(maxsplit=1)

                            if len(parts) >= 2:
                                room_text = parts[1]
                            else:
                                room_text = "Krishna Coder"

                            # Add red color code
                            room_text = f"[FF0000]{room_text}"

                            # Send room packet
                            await left_group(key, iv)
                            await asyncio.sleep(0.2)
                            room_packet = await Room(room_text, key, iv)

                            if online_writer and room_packet:
                                online_writer.write(room_packet)
                                await online_writer.drain()

                            # Single success message
                            success_msg = "Room create successfully"
                            await send_response(success_msg, uid, chat_id, chat_type)

                        except Exception as e:
                            print(f"Error in /createroom command: {e}")

                    elif received_msg.startswith('/reject'):
                        await send_title(chat_id, chat_type)
                        try:
                            parts = received_msg.split()
                            if len(parts) >= 2 and parts[1].isdigit():
                                client_id = int(parts[1])
                                
                                # Send processing message
                                processing_msg = f"Krishna Coder Reject Spam: {fix_num(str(client_id))}"
                                await send_response(processing_msg, uid, chat_id, chat_type)
                                
                                # Send reject spam packets
                                for i in range(30):
                                    try:
                                        Krishna_packet = await dev(client_id, key, iv, "ind")
                                        Krishna1_packet = await dev(client_id, key, iv, "ind")

                                        if online_writer and Krishna_packet:
                                            online_writer.write(Krishna_packet)
                                            await online_writer.drain()

                                        if online_writer and Krishna1_packet:
                                            online_writer.write(Krishna1_packet)
                                            await online_writer.drain()

                                        await asyncio.sleep(0.2)

                                        # Update progress every 30 packets
                                        if (i + 1) % 30 == 0:
                                            progress_msg = f"Progress: {i+1}/30 batches\nPackets sent: {(i+1)*2}"
                                            await send_response(progress_msg, uid, chat_id, chat_type)

                                    except Exception as e:
                                        print(f"Error sending Krishna Coder packets: {e}")
                                        continue
                                
                                # Completion message
                                complete_msg = f"Krishna Codér Reject Spam Complete!\nTarget: {fix_num(str(client_id))}\nPackets: 300 total"
                                await send_response(complete_msg, uid, chat_id, chat_type)

                            else:
                                error_msg = f"[FF0000]Usage: /reject [UID]\nExample: /reject 1234567890"
                                await send_response(error_msg, uid, chat_id, chat_type)

                        except Exception as e:
                            print(f"Error in /reject command: {e}")
                            error_msg = f"[FF0000]Reject command error: {str(e)}"
                            await send_response(error_msg, uid, chat_id, chat_type)

                    elif received_msg.startswith('/sticker'):
                        try:
                            # Send only ONE sticker silently
                            packet = await send_sticker(
                                target_uid=uid,
                                chat_id=chat_id,
                                key=key,
                                iv=iv,
                                nickname="ᏦʀᎥsʜɴᴀㅤBᴏᴛ"
                            )

                            if whisper_writer and packet:
                                whisper_writer.write(packet)
                                await whisper_writer.drain()

                        except Exception as e:
                            print(f"Error in /sticker command: {e}")

                    elif received_msg.startswith("/bundle"):
                        await send_title(chat_id, chat_type)
                        try:
                            bundle_list = [
                                ("midnight-ace", 914048001),
                                ("aurora", 914047002),
                                ("naruto", 914047001),
                                ("naruto2", 914047001),
                                ("paradox", 914044001),
                                ("frostfire", 914042001),
                                ("rampage", 914000002),
                                ("wolf", 914000003),
                                ("devil", 914038001),
                                ("scorpio", 914039001),
                                ("dreamspace", 914051001),
                                ("dreamspace2", 914051001),
                                ("eclipse", 914053001),
                                ("itachi", 914050001)
                            ]

                            bundles_by_name = {name: bid for name, bid in bundle_list}
                            bundles_by_number = {
                                str(i + 1): (name, bid)
                                for i, (name, bid) in enumerate(bundle_list)
                            }

                            bundle_list_msg = (
                                "AVAILABLE BUNDLES\n"
                                "--------------------------\n"
                                "1  MIDNIGHT-ACE\n"
                                "2  AURORA\n"
                                "3  NARUTO\n"
                                "4  NARUTO2\n"
                                "5  PARADOX\n"
                                "6  FROSTFIRE\n"
                                "7  RAMPAGE\n"
                                "8  WOLF\n"
                                "9  DEVIL\n"
                                "10 SCORPIO\n"
                                "11 DREAMSPACE\n"
                                "12 DREAMSPACE2\n"
                                "13 ECLIPSE\n"
                                "14 ITACHI"
                            )

                            parts = received_msg.strip().split(maxsplit=1)

                            bundle_id = None
                            bundle_name = None

                            if len(parts) == 2:
                                arg = parts[1].lower()

                                if arg in bundles_by_name:
                                    bundle_name = arg
                                    bundle_id = bundles_by_name[arg]

                                elif arg.isdigit() and arg in bundles_by_number:
                                    bundle_name, bundle_id = bundles_by_number[arg]

                            if bundle_id:
                                await send_response(
                                    "[C][B][00FF00]Request received. Changing bundle...",
                                    uid, chat_id, chat_type
                                )

                                if online_writer:
                                    try:
                                        packet1 = await bundlepacket(
                                            bundle_id,
                                            key, iv
                                        )
                                        online_writer.write(packet1)
                                        await online_writer.drain()
                                    except Exception as e:
                                        print("WRITE ERROR 1:", e)

                                    await asyncio.sleep(3.3)

                                    try:
                                        if bundle_name in ["dreamspace2", "naruto2"]:
                                            packet2 = await bundle_packet2(
                                                bundle_id,
                                                key, iv
                                            )
                                        else:
                                            packet2 = await bundle_packet(
                                                bundle_id,
                                                key, iv
                                            )
                                        online_writer.write(packet2)
                                        await online_writer.drain()
                                    except Exception as e:
                                        print("WRITE ERROR 2:", e)

                                await send_response(
                                    "[C][B][00FF00]Bundle changed successfully",
                                    uid, chat_id, chat_type
                                )

                            else:
                                await send_response(
                                    bundle_list_msg,
                                    uid, chat_id, chat_type
                                )

                        except Exception as e:
                            print(f"Error in /bundle command: {e}")
                            await send_response(
                                "[C][B][FF0000]Bundle command error",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.startswith("/transfer "):
                        await send_title(chat_id, chat_type)
                        await asyncio.sleep(0.1)
                        parts = received_msg.strip().split()
                        if len(parts) == 2 and parts[1].isdigit():
                            players_uid = parts[1]
                            await send_response(
                                "Request received.Team Flag Transfer...", uid,
                                chat_id, chat_type)
                            await FlagTransfer(players_uid, key, iv)
                        else:
                            await send_response(
                                "[C][B][FF0000]Invalid format. Use /transfer [uid]",
                                uid, chat_id, chat_type)
                                
                    elif received_msg.startswith('/kick'):
                        await send_title(chat_id, chat_type)
                        try:
                            parts = received_msg.split()

                            if len(parts) >= 2:
                                uids = [p for p in parts[1:] if p.isdigit()]

                                if not uids:
                                    await send_response(
                                        "[C][B][FF0000]Usage: /kick <UID1> <UID2> ...",
                                        uid, chat_id, chat_type
                                    )
                                    return

                                for target_uid in uids:
                                    try:
                                        gkick_packet = await Kick(int(target_uid), key, iv)

                                        if online_writer and gkick_packet:
                                            online_writer.write(gkick_packet)
                                            await online_writer.drain()

                                        await asyncio.sleep(0.15)

                                    except Exception as e:
                                        print(f"kick error for {target_uid}: {e}")
                                        continue

                                await send_response(
                                    "Player kick successfully",
                                    uid, chat_id, chat_type
                                )

                            else:
                                await send_response(
                                    "[C][B][FF0000]Usage: /kick <UID1> <UID2> ...",
                                    uid, chat_id, chat_type
                                )

                        except Exception as e:
                            print(f"Error in /kick command: {e}")
                            await send_response(
                                "[FF0000]Kick error",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.startswith("/autojoin"):
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][B][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await asyncio.sleep(0.1)
                            parts = received_msg.strip().split()
                            if len(parts) < 2:
                                await send_response(
                                    "[C][B][FF0000]Usage: /autojoin [on/off]",
                                    uid, chat_id, chat_type
                                )
                            else:
                                state = parts[1].lower()
                                try:
                                    global AUTO_JOIN_ENABLED
                                    if state == "on":
                                        AUTO_JOIN_ENABLED = True
                                        await send_response(
                                            "[C][B][00FF00]Auto-Join Enabled.",
                                            uid, chat_id, chat_type
                                        )
                                    elif state == "off":
                                        AUTO_JOIN_ENABLED = False
                                        await send_response(
                                            "[C][B][FF0000]Auto-Join Disabled.",
                                            uid, chat_id, chat_type
                                        )
                                    else:
                                        await send_response(
                                            "[C][B][FF0000]Usage: /autojoin [on/off]",
                                            uid, chat_id, chat_type
                                        )
                                except Exception as e:
                                    msg = f"[C][B][FF0000]Error: {str(e)[:80]}"
                                    await send_response(msg, uid, chat_id, chat_type)

                    elif received_msg.lower() == "/restart":
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][B][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await send_response(
                                "[C][B][FF0000]♻️ Restarting bot...",
                                uid, chat_id, chat_type
                            )

                            await asyncio.sleep(1)

                            python = sys.executable
                            os.execl(python, python, *sys.argv)

                    elif received_msg.lower() == "/uptime":
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][B][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            uptime = int(time.time() - BOT_START_TIME)

                            days = uptime // 86400
                            hours = (uptime % 86400) // 3600
                            minutes = (uptime % 3600) // 60
                            seconds = uptime % 60

                            # Asia/Kolkata (IST) – fixed offset, server independent
                            ist = timezone(timedelta(hours=5, minutes=30))
                            now = datetime.now(ist)

                            current_date = now.strftime("%d %B %Y")
                            current_time = now.strftime("%I:%M:%S %p")

                            await send_response(
                                "SYSTEM UPTIME STATUS\n"
                                "------------------------------\n"
                                f"Running Time : {days} days, {hours} hours, "
                                f"{minutes} minutes, {seconds} seconds\n\n"
                                f"Current Date : {current_date}\n"
                                f"Current Time : {current_time} (Asia/Kolkata)",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.lower() == "/ping":
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][B][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            start_time = time.time()

                            await send_response(
                                "Checking bot speed...",
                                uid, chat_id, chat_type
                            )

                            latency = int((time.time() - start_time) * 1000)

                            await send_response(
                                f"Response Speed: {latency} ms",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.startswith("/grouplag"):
                        await send_title(chat_id, chat_type)

                        await send_response(
                            "[C][FFFFFF]Team Lag Spam Started",
                            uid,
                            chat_id,
                            chat_type
                        )

                        try:
                            start_time = time.time()

                            while time.time() - start_time < 10:
                                packet = await new_lag(key, iv)

                                if online_writer:
                                    online_writer.write(packet)
                                    await online_writer.drain()

                                await asyncio.sleep(0.003)

                            await send_response(
                                "[C][B][00FF00]Team Lag Spam Successful",
                                uid,
                                chat_id,
                                chat_type
                            )

                        except Exception as e:
                            print("grouplag error:", e)

                    elif received_msg.startswith("/squadlag"):
                        await send_title(chat_id, chat_type)

                        await send_response(
                            "[C][FFFFFF]Squad Lag Spam Started",
                            uid,
                            chat_id,
                            chat_type
                        )

                        try:
                            start_time = time.time()

                            while time.time() - start_time < 10:
                                packet = await new_lag(key, iv)

                                if online_writer:
                                    online_writer.write(packet)
                                    await online_writer.drain()

                                await asyncio.sleep(0.03)

                            await send_response(
                                "[C][B][00FF00]Squad Lag Spam Successful",
                                uid,
                                chat_id,
                                chat_type
                            )

                        except Exception as e:
                            print("squadlag error:", e)

                    elif received_msg.startswith("/inv"):
                        await send_title(chat_id, chat_type)

                        try:
                            parts = received_msg.strip().split()
                            target_uid = int(parts[1])
                        except:
                            return

                        try:
                            await create_group(key, iv)
                            await asyncio.sleep(0.3)

                            await modify_team_player("4", key, iv)
                            await asyncio.sleep(0.3)

                            # FIRST: command dene wala user
                            await invite_target(uid, key, iv)
                            await asyncio.sleep(0.3)

                            # SECOND: target UID (ab group fully ready hota hai)
                            await invite_target(target_uid, key, iv)

                            await send_response(
                                "Please Accept My Invitation to Join Group.",
                                uid,
                                chat_id,
                                chat_type
                            )

                            await asyncio.sleep(5)
                            await left_group(key, iv)

                        except Exception as e:
                            print("inv error:", e)

                    elif received_msg.startswith('/start '):
                        await send_title(chat_id, chat_type)
                        update_command_stats("start")

                        try:
                            parts = received_msg.strip().split()

                            if len(parts) < 2:
                                await send_response(
                                    "Please provide a team code.",
                                    uid, chat_id, chat_type
                                )
                                return

                            team_code = parts[1]

                            # -------------------------------
                            # MESSAGE 1 — JOINING LOBBY
                            # -------------------------------
                            await send_response(
                                "Preparing lobby for game start...",
                                uid, chat_id, chat_type
                            )

                            # 1️⃣ JOIN TEAM
                            await join_teamcode(team_code, key, iv)

                            # wait for lobby to load
                            await asyncio.sleep(0.0)

                            # Prepare start packet
                            start_packet = await start_autooo(key, iv)

                            # -------------------------------
                            # 2️⃣ START SPAM — 10 SECONDS
                            # -------------------------------
                            loop_start = asyncio.get_event_loop().time()
                            loop_end = loop_start + 10   # 10 seconds spam

                            while asyncio.get_event_loop().time() < loop_end:
                                if online_writer:
                                    online_writer.write(start_packet)
                                    await online_writer.drain()
                                await asyncio.sleep(0.5)

                            # -------------------------------
                            # 3️⃣ LEAVE GROUP
                            # -------------------------------
                            await left_group(key, iv)

                            # -------------------------------
                            # MESSAGE 2 — COMPLETED
                            # -------------------------------
                            await send_response(
                                "Game start triggered successfully.",
                                uid, chat_id, chat_type
                            )

                        except Exception as e:
                            err = f"/start error: {str(e)}"
                            await send_response(err, uid, chat_id, chat_type)

                    elif received_msg.startswith('/join_room '):
                        await send_title(chat_id, chat_type)
                        update_command_stats("join_room")
                        try:
                            parts = received_msg.strip().split()
                            if len(parts) == 3:
                                room_id = parts[1]
                                password = parts[2]

                                if room_id.isdigit():
                                    
                                    # Send processing message (same spacing style)
                                    processing_msg = f"Joining Room: {fix_num(str(room_id))}"
                                    await send_response(processing_msg, uid, chat_id, chat_type)

                                    # Run join task in background
                                    asyncio.create_task(RoomJoin(int(room_id), password, key, iv))

                                    # Success message (same spacing)
                                    success_msg = f"Successfully Joined Room!\nRoom ID: {fix_num(str(room_id))}"
                                    await send_response(success_msg, uid, chat_id, chat_type)

                                else:
                                    error_msg = "[FF0000]Invalid Room ID. Must be digits only."
                                    await send_response(error_msg, uid, chat_id, chat_type)

                            else:
                                error_msg = "[FF0000]Usage: /join_room [ROOM_ID] [PASSWORD]"
                                await send_response(error_msg, uid, chat_id, chat_type)

                        except Exception as e:
                            print(f"Error in /join_room command: {e}")
                            error_msg = f"[FF0000]join_room command error: {str(e)}"
                            await send_response(error_msg, uid, chat_id, chat_type)

                    elif received_msg.startswith('/exit_room'):
                        await send_title(chat_id, chat_type)
                        update_command_stats("exit_room")
                        try:
                            # Create leave packet
                            leave_packet = await KrishnaLeaveRoom(int(uid), key, iv)

                            # Send to server
                            if online_writer and leave_packet:
                                online_writer.write(leave_packet)
                                await online_writer.drain()

                            # Only ONE clean success message (NO UID)
                            success_msg = f"Successfully Left The Room!"
                            await send_response(success_msg, uid, chat_id, chat_type)

                        except Exception as e:
                            print(f"Error in /exit_room command: {e}")
                            error_msg = f"[FF0000]leave_room command error: {str(e)}"
                            await send_response(error_msg, uid, chat_id, chat_type)

                    elif received_msg.startswith('/rmlag '):
                        await send_title(chat_id, chat_type)
                        update_command_stats("roomlag")
                        try:
                            parts = received_msg.strip().split()

                            if len(parts) < 3:
                                msg = f"[B][C]{get_random_color()}Usage: /rmlag <room_id> <password>"
                                await send_response(msg, uid, chat_id, chat_type)
                                return

                            room_id = parts[1]
                            password = parts[2]

                            start_msg = (
                                f"ROOMLAG STARTED\n"
                                f"DURATION: 10 SECONDS\n"
                                f"ROOM ID: {fix_num(str(room_id))}"
                            )
                            await send_response(start_msg, uid, chat_id, chat_type)

                            async def fastroom_run():
                                try:
                                    start_time = time.time()

                                    while time.time() - start_time < 10:

                                        try:
                                            join_pkt = await RoomJoin(int(room_id), password, key, iv)
                                            if online_writer and join_pkt:
                                                online_writer.write(join_pkt)
                                                await online_writer.drain()
                                        except:
                                            pass

                                        try:
                                            leave_pkt = await KrishnaLeaveRoom(int(uid), key, iv)
                                            if online_writer and leave_pkt:
                                                online_writer.write(leave_pkt)
                                                await online_writer.drain()
                                        except:
                                            pass

                                        await asyncio.sleep(0.10)

                                    try:
                                        final_leave = await KrishnaLeaveRoom(int(uid), key, iv)
                                        if online_writer and final_leave:
                                            online_writer.write(final_leave)
                                            await online_writer.drain()
                                    except:
                                        pass

                                    finish_msg = (
                                        f"[00FF00][B]       \n"
                                        f"ROOMLAG Completed!\n"
                                        f"Room ID: {fix_num(str(room_id))}\n"
                                        f"[00FF00]       "
                                    )
                                    await send_response(finish_msg, uid, chat_id, chat_type)

                                except Exception as e:
                                    print("ROOMLAG ERROR:", e)

                            asyncio.create_task(fastroom_run())

                        except Exception as e:
                            print("ROOMLAG error:", e)
                            err = f"[FF0000]ROOMLAG Error: {str(e)}"
                            await send_response(err, uid, chat_id, chat_type)

                    elif received_msg.startswith("/ghost "):
                        await send_title(chat_id, chat_type)

                        parts = received_msg.strip().split()
                        if len(parts) < 2:
                            await send_response(
                                "[C][B][FF0000]Invalid Team Code\n"
                                "[FFFFFF]Usage: /ghost 1234567",
                                uid, chat_id, chat_type
                            )
                            return

                        team_code = parts[1].strip()

                        if not team_code.isdigit() or not (6 <= len(team_code) <= 7):
                            await send_response(
                                "[C][B][FF0000]Invalid Code\n"
                                "[FFFFFF]Code must be 6–7 digits.",
                                uid, chat_id, chat_type
                            )
                            return

                        await send_response(
                            f"Connecting to Ghost Server...\n"
                            f"Team Code: {team_code}",
                            uid, chat_id, chat_type
                        )

                        try:
                            url = "http://dev-ghost-api.up.railway.app/execute_command_all"
                            params = {"command": f"/bngx={team_code}"}

                            async with session.get(url, params=params) as resp:
                                if resp.status == 200:
                                    await send_response(
                                        f"Ghost Added Successfully\n"
                                        f"Team: {team_code}",
                                        uid, chat_id, chat_type
                                    )
                                else:
                                    await send_response(
                                        f"[C][B][FF0000]API Failed\n"
                                        f"[FFFFFF]Status: {resp.status}",
                                        uid, chat_id, chat_type
                                    )

                        except Exception as e:
                            await send_response(
                                f"[C][B][FF0000]Error Occurred\n"
                                f"[FFFFFF]{str(e)}",
                                uid, chat_id, chat_type
                            )

                    elif received_msg == "/title":
                        await send_title(chat_id, chat_type)

                    elif received_msg.startswith("/gali"):
                        await send_title(chat_id, chat_type)

                        if str(uid) in ADMIN_UIDS:
                            try:
                                parts = received_msg.strip().split(maxsplit=1)
                                
                                if len(parts) < 2:
                                    await send_response(
                                        "[B][C][FF0000] ERROR! Usage:\n"
                                        "/gali <name>\n"
                                        "Example: /gali hater",
                                        uid, chat_id, chat_type
                                    )
                                    return

                                name = parts[1].strip()

                                # Blocked Names Protection
                                BLOCKED_NAMES = ["arbaz", "ARBAZ", "Arbaz", "Krishna", "KrishnaCoder"]
                                
                                if name.lower() in [n.lower() for n in BLOCKED_NAMES]:
                                    await send_response(
                                        f"[B][C][FF0000]⚠️ WARNING!\n"
                                        f"[FFFFFF]You cannot target '{name}'!\n"
                                        f"[FF0000]Bot owner protected! ⛔",
                                        uid, chat_id, chat_type
                                    )
                                    return

                                galii = [
                                    "{Name} TƐRI SƐXY BHEN KI CHXT ME ME L0DA DAAL KAR RAAT BHAR JOR JOR SE CH0DUNGA",
                                    "{Name} MADHERXHOD TƐRI MÁÁ KI KALI G4ND MƐ LÀND MARU",
                                    "{Name} TƐRI BHƐN KI TIGHT CHXT KO 5G KI SPEED SE CHÒD DU",
                                    "{Name} TƐRI BEHEN KI CHXT ME L4ND MARU",
                                    "{Name} TƐRI MÁÁ KI CHXT 360 BAR",
                                    "{Name} TƐRI BƐHƐN KI CHXT 720 BAR",
                                    "{Name} BEHEN KE L0DE",
                                    "{Name} MADARCHXD",
                                    "{Name} BETE TƐRA BAAP HUN ME",
                                    "{Name} G4NDU APNE BAAP KO H8 DEGA",
                                    "{Name} KI MÀÀ KI CHXT PER NIGHT 4000",
                                    "{Name} KI BƐHƐN KI CHXT PER NIGHT 8000",
                                    "{Name} R4NDI KE BACHHƐ APNE BAP KO H8 DEGA",
                                    "INDIA KA NO-1 G4NDU {Name}",
                                    "{Name} CHAPAL CH0R",
                                    "{Name} TƐRI MÀÀ KO GB ROAD PE BETHA KE CHXDUNGA",
                                    "{Name} BETA JHULA JHUL APNE BAAP KO MAT BHUL"
                                ]

                                await send_response(
                                    f"[B][C][00FF00] {name.upper()} Tu ràndi ki paidàish fate condóm se nikla huwa baccha",
                                    uid, chat_id, chat_type
                                )

                                for msg in galii:
                                    colored_message = f"[B][C]{get_random_color()} {msg.replace('{Name}', name.upper())}"
                                    await send_response(colored_message, uid, chat_id, chat_type)
                                    await asyncio.sleep(1.7)

                            except Exception as e:
                                await send_response(
                                    f"[C][B][FF0000]Error: {str(e)[:80]}",
                                    uid, chat_id, chat_type
                                )

                        else:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.startswith("/allowed"):
                        await send_title(chat_id, chat_type)

                        if str(uid) in ADMIN_UIDS:
                            await send_response(
                                "[C][FFFFFF]Fetching Allowed Friend List...",
                                uid, chat_id, chat_type
                            )

                            try:
                                friend_response = await GetFriend()
                                data = json.loads(friend_response)

                                for player in data.get("PlayerList", []):
                                    player_uid = player.get("PlayerUid", "")
                                    if not player_uid:
                                        continue

                                    index = 4
                                    player_uid1 = int(player_uid[:index])
                                    player_uid2 = int(player_uid[index:])
                                    player_name = player.get("PlayerName", "")
                                    player_level = player.get("PlayerLevel", "")

                                    player_data = (
                                        f"PlayerName: {player_name}\n"
                                        f"PlayerUid: {player_uid1}[C]{player_uid2}\n"
                                        f"PlayerLevel: {player_level}"
                                    )

                                    await send_response(
                                        f"[C][FFDAB9]{player_data}",
                                        uid, chat_id, chat_type
                                    )



                            except Exception as e:
                                await send_response(
                                    f"[C][B][FF0000]Error: {str(e)[:80]}",
                                    uid, chat_id, chat_type
                                )

                        else:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                                                              
                    elif received_msg.startswith("/requestlist"):
                        await send_title(chat_id, chat_type)

                        if str(uid) in ADMIN_UIDS:
                            await send_response(
                                "[C][FFFFFF]Fetching Friend Request List...",
                                uid, chat_id, chat_type
                            )

                            try:
                                request_list = await GetFriendRequestList()
                                if not request_list:
                                    await send_response(
                                        f"[C][FF0000]No Friend Requests Found!",
                                        uid, chat_id, chat_type
                                    )
                                    return
                                for player in request_list:
                                    player_uid = player.get("accountUid", "")
                                    if not player_uid:
                                        continue

                                    index = 4
                                    player_uid1 = int(player_uid[:index])
                                    player_uid2 = int(player_uid[index:])
                                    player_name = player.get("nickname", "")

                                    player_data = (
                                        f"PlayerName: {player_name}\n"
                                        f"PlayerUid: {player_uid1}[C]{player_uid2}"
                                    )

                                    await send_response(
                                        f"[C][FFDAB9]{player_data}",
                                        uid, chat_id, chat_type
                                    )

                            except Exception as e:
                                await send_response(
                                    f"[C][B][FF0000]Error: {str(e)[:80]}",
                                    uid, chat_id, chat_type
                                )

                        else:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )

                    elif received_msg.startswith("/add"):
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await asyncio.sleep(0.1)
                            parts = received_msg.strip().split()
                            if len(parts) < 2:
                                await send_response(
                                    "[C][FF0000]Usage: /add [uid]",
                                    uid, chat_id, chat_type
                                )
                            else:
                                add_uid = parts[1]
                                await send_response(
                                    f"[C][FFFFFF]Sending friend request...",
                                    uid, chat_id, chat_type
                                )
                                add = f"[C][B][FF0000]Failed to send request. Try again."
                                try:
                                    protobuf_message = await create_protobuf_message(add_uid)
                                    encrypted_uid = await encrypt_message(protobuf_message)
                                    responsefriend = await send_request(encrypted_uid)
                                    add = f"[C][B][00FF00]Friend request sent successfully."
                                except Exception as e:
                                    add = f"[C][B][FF0000]Error: {str(e)[:80]}"
                                await send_response(add, uid, chat_id, chat_type)

                    elif received_msg.startswith("/clan"):
                        await send_title(chat_id, chat_type)

                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await asyncio.sleep(0.1)
                            parts = received_msg.strip().split()
                            if len(parts) < 2:
                                await send_response(
                                    "[C][FF0000]Usage: /clan [clan_id]",
                                    uid, chat_id, chat_type
                                )
                            else:
                                clan_id = parts[1]
                                if not clan_id.isdigit():
                                    await send_response(
                                        "[C][FF0000]Clan ID must be numeric.",
                                        uid, chat_id, chat_type
                                    )
                                else:
                                    await send_response(
                                        f"[C][FFFFFF]Please wait sending guild join spam...",
                                        uid, chat_id, chat_type
                                    )                        
                                    clann = f"[C][FF0000]Failed to send guild join spam request. Try again."
                                    try:
                                        for i in range(100):
                                            encrypted_hex = await clan_protobuf_msg(clan_id)
                                            response = await send_join_request(clan_id)
                                            await asyncio.sleep(0.00003)
                                        clann = f"[C][00FF00]Successfully send clan join"
                                    except Exception as e:  
                                        clann = f"[C][B][FF0000]Error: {str(e)[:80]}"
                                    await send_response(clann, uid, chat_id, chat_type)  

                    elif received_msg.startswith("/leave_clan"):
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await asyncio.sleep(0.1)
                            parts = received_msg.strip().split()
                            if len(parts) < 2:
                                await send_response(
                                    "[C][B][FF0000]Usage: /leave_clan [clan_id]",
                                    uid, chat_id, chat_type
                                )
                            else:
                                clan_id = parts[1]
                                await send_response(
                                    f"[C][FFFFFF] Please wait leaving guild....",
                                    uid, chat_id, chat_type
                                )                        
                                clan = f"[C][B][FF0000]Failed to leave guild. Try again."
                                try:
                                    encrypted_hex = await clan_protobuf_msg(clan_id)
                                    response = await leave_clan_request(clan_id)
                                    clan = f"[C][B][00FF00]{response}"
                                except Exception as e:  
                                    clan = f"[C][B][FF0000]Error: {str(e)[:80]}"
                                await send_response(clan, uid, chat_id, chat_type) 
                                                
                    elif received_msg.startswith("/remove"):
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await asyncio.sleep(0.1)
                            parts = received_msg.strip().split()
                            if len(parts) < 2:
                                await send_response(
                                    "[C][FF0000]Usage: /remove [uid]",
                                    uid, chat_id, chat_type
                                )
                            else:
                                rem_uid = parts[1]
                                await send_response(
                                    f"[C][FFFFFF] Please wait Removing friend...",
                                    uid, chat_id, chat_type
                                )                        
                                remove = f"[C][FF0000]Failed to remove friend. Try again."
                                try:
                                    encrypted_hex = await RemoveFriendProto(rem_uid)
                                    responsed = await RemoveFriend(rem_uid)
                                    remove = f"[C][00FF00]{responsed}"
                                except Exception as e:  
                                    remove = f"[C][B][FF0000]Error: {str(e)[:80]}"
                                await send_response(remove, uid, chat_id, chat_type)

                    elif received_msg.startswith("/confirm"):
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await asyncio.sleep(0.1)
                            parts = received_msg.strip().split()
                            if len(parts) < 2:
                                await send_response(
                                    "[C][FF0000]Usage: /confirm [uid]",
                                    uid, chat_id, chat_type
                                )
                            else:
                                confirm_uid = parts[1]
                                await send_response(
                                    f"[C][FFFFFF] Please wait confirming friend request...",
                                    uid, chat_id, chat_type
                                )                        
                                Confirm = f"[C][FF0000]Failed to Confirm friend request. Try again."
                                try:
                                    encrypted_hex = await ConfirmFriendProto(confirm_uid)
                                    responsed = await ConfirmFriend(confirm_uid)
                                    Confirm = f"[C][00FF00]{responsed}"
                                except Exception as e:  
                                    Confirm = f"[C][B][FF0000]Error: {str(e)[:80]}"
                                await send_response(Confirm, uid, chat_id, chat_type)
                                                                
                    elif received_msg.startswith("/cancel"):
                        await send_title(chat_id, chat_type)
                        if str(uid) not in ADMIN_UIDS:
                            await send_response(
                                "[C][FF0000]You are not authorized to use this command!",
                                uid, chat_id, chat_type
                            )
                        else:
                            await asyncio.sleep(0.1)
                            parts = received_msg.strip().split()
                            if len(parts) < 2:
                                await send_response(
                                    "[C][FF0000]Usage: /cancel [uid]",
                                    uid, chat_id, chat_type
                                )
                            else:
                                cancel_uid = parts[1]
                                await send_response(
                                    f"[C][FFFFFF] Please wait Cancelling friend request...",
                                    uid, chat_id, chat_type
                                )                        
                                cancel = f"[C][FF0000]Failed to cancel friend request. Try again."
                                try:
                                    encrypted_hex = await CancelFriendProto(cancel_uid)
                                    responsed = await CancelFriend(cancel_uid)
                                    cancel = f"[C][B][00FF00]{responsed}"
                                except Exception as e:  
                                    cancel = f"[C][B][FF0000]Error: {str(e)[:80]}"
                                await send_response(cancel, uid, chat_id, chat_type)

                    elif received_msg.startswith("/info"):
                        await send_title(chat_id, chat_type)
                        await asyncio.sleep(0.1)
                        parts = received_msg.strip().split()
                        if len(parts) != 2:
                            await send_response(
                                "[C][FF0000]Usage: /info [uid]",
                                uid, chat_id, chat_type
                            )
                            return
                        add_uid = parts[1]
                        await send_response(
                            f"[C][FFFFFF] Fetching player info...",
                            uid, chat_id, chat_type
                        )                        
                        try:
                            protobuf_message = await info_protobuf_message(add_uid)
                            encrypted_uid = await encrypt_message(protobuf_message)
                            response_json = await info_request(encrypted_uid)
                            data = json.loads(response_json)
                            account_info = data["AccountInfo"]
                            credit_score = data["creditScoreInfo"]["creditScore"]
                            last_login_time = format_timestamp(account_info['AccountLastLogin'])
                            create_time = format_timestamp(account_info['AccountCreateTime'])
                            player_info = (
                                f"Player Info:\n"
                                f"- Name: {account_info['AccountName']}\n"
                                f"- Region: {account_info['AccountRegion']}\n"
                                f"- Level: {account_info['AccountLevel']}\n"
                                f"- Likes: {account_info['AccountLikes']}\n"
                                f"- Honor Score: {credit_score}\n\n"
                                f"- Last Login: {last_login_time}\n"
                                f"- Created At: {create_time}"
                            )
                            await send_response(
                                f"[C][FFDAB9]{player_info}",
                                uid, chat_id, chat_type
                            )
                        
                        except Exception as e:
                            msg = f"[C][B][FF0000]Error: {str(e)[:80]}"
                        await send_response(msg, uid, chat_id, chat_type)

                    elif response.Data.msg == "/ai":
                        await send_title(chat_id, chat_type)
                        await send_response(
                            "[C][B][FF0000]AI Usage:\n"
                            "[C][B][FF0000]/ai on  → ENABLE AI\n"
                            "[C][B][FF0000]/ai off → DISABLE AI",
                            uid, chat_id, chat_type
                        )

                    elif response.Data.msg.startswith("/ai "):
                        await send_title(chat_id, chat_type)

                        option = response.Data.msg[4:].strip().lower()

                        global ai_mode
                        if option == "on":
                            if ai_mode:
                                await send_response(
                                    "[C][B][FF0000]AI ALREADY ON",
                                    uid, chat_id, chat_type
                                )
                            else:
                                ai_mode = True
                                await send_response(
                                    "[C][B][00FF00]AI MODE ENABLED",
                                    uid, chat_id, chat_type
                                )

                        elif option == "off":
                            if not ai_mode:
                                await send_response(
                                    "[C][B][FF0000]AI ALREADY OFF",
                                    uid, chat_id, chat_type
                                )
                            else:
                                ai_mode = False
                                await send_response(
                                    "[C][B][FF0000]AI Usage:\n"
                                    "[C][B][FF0000]/ai on  → ENABLE AI\n"
                                    "[C][B][FF0000]/ai off → DISABLE AI",
                                    uid, chat_id, chat_type
                                )

                        else:
                            await send_response(
                                "[C][B][FF0000]AI Usage:\n"
                                "[C][B][FF0000]/ai on  → ENABLE AI\n"
                                "[C][B][FF0000]/ai off → DISABLE AI",
                                uid, chat_id, chat_type
                            )

                    elif ai_mode and not response.Data.msg.startswith("/"):
                        user_input = response.Data.msg.strip()

                        if user_input:
                            ai_response = await talk_with_ai(user_input)
                            parts = await split_text_by_words(ai_response)

                            for message in parts:
                                await asyncio.sleep(0.5)
                                await send_response(
                                    message,
                                    uid,
                                    chat_id,
                                    chat_type
                                )
            try:
                whisper_writer.close()
                await whisper_writer.wait_closed()
            except Exception:
                pass
            whisper_writer = None

        except Exception as e:
            print(f"Error with {ip}:{port} - {e}")
            whisper_writer = None

        finally:
            if session and not session.closed:
                await session.close()

        await asyncio.sleep(reconnect_delay)


async def main(uid, password):
    open_id, access_token = await get_access_token(uid, password)
    global token
    global base_url
    global AccountUID
    global AccountName
    token = access_token
    if not open_id or not access_token:
        print("Invalid Account")
        return None
    payload = await MajorLoginProto_Encode(open_id, access_token)
    MajorLoginResponse = await MajorLogin(payload)
    if not MajorLoginResponse:
        print("Account has been banned or doesn't registered")
        return None
    Decode_MajorLogin = await MajorLogin_Decode(MajorLoginResponse)
    base_url = Decode_MajorLogin.url
    token = Decode_MajorLogin.token
    AccountUID = Decode_MajorLogin.account_uid
    Region = Decode_MajorLogin.region
    key = Decode_MajorLogin.key
    iv = Decode_MajorLogin.iv
    timestamp = Decode_MajorLogin.timestamp
    GetLoginDataResponse = await GetLoginData(base_url, payload, token)
    if not GetLoginDataResponse:
        print("Dam Something went Wrong, Please Check GetLoginData")
        return None
    Decode_GetLoginData = await GetLoginData_Decode(GetLoginDataResponse)
    AccountName = Decode_GetLoginData.AccountName
    Online_IP_Port = Decode_GetLoginData.Online_IP_Port
    AccountIP_Port = Decode_GetLoginData.AccountIP_Port
    online_ip, online_port = Online_IP_Port.split(":")
    account_ip, account_port = AccountIP_Port.split(":")
    print(equipe_emote)
    print("--------------------------------------------------")
    print(f" - NAME       => {AccountName}")
    print(f" - UID        => {AccountUID}")
    print(f" - REGION     => {Region}")
    print(f" - Server Url => {base_url}/")
    print("--------------------------------------------------")
    encrypted_startup = await get_encrypted_startup(int(AccountUID), token,
                                                    int(timestamp), key, iv)

    ready_event = asyncio.Event()
    task1 = asyncio.create_task(
        handle_tcp_connection(account_ip, account_port, encrypted_startup, key,
                              iv, Decode_GetLoginData, ready_event))

    await ready_event.wait()
    await asyncio.sleep(2)

    task2 = asyncio.create_task(
        handle_tcp_online_connection(online_ip, online_port, key, iv,
                                     encrypted_startup))

    await asyncio.gather(task1, task2)


async def api_create_team_task(uid, size_idx):
    if not online_writer: return
    await create_group(key, iv)
    await asyncio.sleep(0.5)
    await modify_team_player(str(size_idx), key, iv)
    await asyncio.sleep(0.3)
    await invite_target(int(uid), key, iv)
    await asyncio.sleep(8)
    await left_group(key, iv)

async def api_dance_task(code, uids, emote):
    if not online_writer: return
    await join_teamcode(code, key, iv)
    await asyncio.sleep(1)
    tasks = []
    for uid in uids:
        tasks.append(emote_send(int(uid), int(emote), key, iv))
    await asyncio.gather(*tasks)
    await asyncio.sleep(0.5)
    await left_group(key, iv)

async def api_evo_dance_task(code, uids, repeat):
    if not online_writer: return
    await join_teamcode(code, key, iv)
    await asyncio.sleep(1)
    for _ in range(repeat):
        random_emote = 909000063
        tasks = []
        for uid in uids:
            tasks.append(emote_send(int(uid), random_emote, key, iv))
        await asyncio.gather(*tasks)
        if repeat > 1:
            await asyncio.sleep(7.5)
    await asyncio.sleep(0.5)
    await left_group(key, iv)

async def api_clan_spam_task(clan_id):
    for i in range(100):
        await clan_protobuf_msg(int(clan_id))
        await send_join_request(int(clan_id))
        await asyncio.sleep(0.00003)

# API Helper Functions
async def api_create_team_task(uid, size_idx):
    if not online_writer: return
    await create_group(key, iv)
    await asyncio.sleep(0.5)
    await modify_team_player(str(size_idx), key, iv)
    await asyncio.sleep(0.3)
    await invite_target(int(uid), key, iv)
    await asyncio.sleep(8)
    await left_group(key, iv)

async def api_dance_task(code, uids, emote):
    if not online_writer: return
    await join_teamcode(code, key, iv)
    await asyncio.sleep(1)
    tasks = []
    for uid in uids:
        tasks.append(emote_send(int(uid), int(emote), key, iv))
    await asyncio.gather(*tasks)
    await asyncio.sleep(0.5)
    await left_group(key, iv)

async def api_evo_dance_task(code, uids, repeat):
    if not online_writer: return
    await join_teamcode(code, key, iv)
    await asyncio.sleep(1)
    for _ in range(repeat):
        random_emote = 909000063
        tasks = []
        for uid in uids:
            tasks.append(emote_send(int(uid), random_emote, key, iv))
        await asyncio.gather(*tasks)
        if repeat > 1:
            await asyncio.sleep(7.5)
    await asyncio.sleep(0.5)
    await left_group(key, iv)

async def api_room_lag_task(room_id, password, uid):
    start_time = time.time()
    while time.time() - start_time < 10:
        try:
            await RoomJoin(int(room_id), password, key, iv)
            await KrishnaLeaveRoom(int(uid), key, iv)
            await asyncio.sleep(0.10)
        except:
            pass

async def api_krishna_task(client_id):
    for i in range(30):
        try:
            await Krishna(int(client_id), key, iv, "BD")
            await asyncio.sleep(0.2)
        except:
            continue

async def api_friend_task(uid):
    try:
        msg = await create_protobuf_message(uid)
        enc = await encrypt_message(msg)
        await send_request(enc)
    except:
        pass

# Flask Routes
@app.route('/')
def dashboard():
    return render_template('index.html')

def verify_api():
    if request.args.get('key') != "KrishnaCoder_Secret_Key":
        return False
    return True

@app.route('/api/create_team', methods=['GET', 'POST'])
def api_create_team():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    size = request.args.get('size')
    if not uid or not size: return jsonify({"error": "Missing params"}), 400
    try:
        idx = int(size) - 1
        asyncio.run_coroutine_threadsafe(api_create_team_task(uid, idx), event_loop)
        return jsonify({"status": "success", "message": f"Creating team {size} for {uid}"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/spam_inv', methods=['GET', 'POST'])
def api_spam_inv():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    if not uid: return jsonify({"error": "Missing uid"}), 400
    try:
        asyncio.run_coroutine_threadsafe(handle_group_spam_invite(int(uid)), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/sm', methods=['GET', 'POST'])
def api_sm():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    if not uid: return jsonify({"error": "Missing uid"}), 400
    try:
        asyncio.run_coroutine_threadsafe(start_spam_invite(int(uid)), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/room', methods=['GET', 'POST'])
def api_room():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    if not uid: return jsonify({"error": "Missing uid"}), 400
    try:
        global spam_room, spam_uid, spam_chat_id, spammer_uid
        spam_chat_id = 3
        spam_uid = int(uid)
        spam_room = True
        spammer_uid = int(uid)
        asyncio.run_coroutine_threadsafe(uid_status(int(uid), key, iv), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/clan', methods=['GET', 'POST'])
def api_clan():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    cid = request.args.get('id')
    if not cid: return jsonify({"error": "Missing id"}), 400
    try:
        async def t():
            for _ in range(100):
                await clan_protobuf_msg(int(cid))
                await send_join_request(int(cid))
                await asyncio.sleep(0.00003)
        asyncio.run_coroutine_threadsafe(t(), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/leave_clan', methods=['GET', 'POST'])
def api_leave_clan():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    cid = request.args.get('id')
    try:
        async def t():
            await clan_protobuf_msg(cid)
            await leave_clan_request(cid)
        asyncio.run_coroutine_threadsafe(t(), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/lag', methods=['GET', 'POST'])
def api_lag():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    code = request.args.get('code')
    try:
        asyncio.run_coroutine_threadsafe(perform_lag_attack(code, key, iv), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/grouplag', methods=['GET', 'POST'])
def api_grouplag():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    code = request.args.get('code')
    try:
        asyncio.run_coroutine_threadsafe(team_lag_attack(code, key, iv), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/game', methods=['GET', 'POST'])
def api_game():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    code = request.args.get('code')
    try:
        asyncio.run_coroutine_threadsafe(game_start(code), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/join', methods=['GET', 'POST'])
def api_join():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    code = request.args.get('code')
    try:
        asyncio.run_coroutine_threadsafe(join_teamcode(code, key, iv), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/exit', methods=['GET', 'POST'])
def api_exit():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    try:
        asyncio.run_coroutine_threadsafe(left_group(key, iv), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/team', methods=['GET', 'POST'])
def api_team_spam():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    try:
        asyncio.run_coroutine_threadsafe(execute_team_spam(int(uid)), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/ghost', methods=['GET', 'POST'])
def api_ghost():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    code = request.args.get('code')
    try:
        url = f"https://ghost-nb8m.onrender.com/execute_command_all?command=/krishna={code}"
        requests.get(url)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/dance', methods=['GET', 'POST'])
def api_dance():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    code = request.args.get('code')
    uids = request.args.get('uids').split(',')
    emote = request.args.get('emote')
    try:
        asyncio.run_coroutine_threadsafe(api_dance_task(code, uids, emote), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/evo_dance', methods=['GET', 'POST'])
def api_evo_dance():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    code = request.args.get('code')
    uids = request.args.get('uids').split(',')
    repeat = int(request.args.get('repeat', 1))
    try:
        asyncio.run_coroutine_threadsafe(api_evo_dance_task(code, uids, repeat), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/rm', methods=['GET', 'POST'])
def api_rm():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    try:
        async def t():
            await RemoveFriendProto(uid)
            await RemoveFriend(uid)
        asyncio.run_coroutine_threadsafe(t(), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/like', methods=['GET', 'POST'])
def api_like():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    try:
        requests.get(f"https://krnkike5-eight.vercel.app/like?uid={uid}&region=ind&key=7year")
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/visit', methods=['GET', 'POST'])
def api_visit():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    try:
        requests.get(f"https://myvisitapi.vercel.app/ind/{uid}/mysecretkey")
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/reject', methods=['GET', 'POST'])
def api_krishna():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    try:
        asyncio.run_coroutine_threadsafe(api_krishna_task(uid), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/roomlag', methods=['GET', 'POST'])
def api_roomlag():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    rid = request.args.get('room_id')
    pwd = request.args.get('password')
    try:
        asyncio.run_coroutine_threadsafe(api_room_lag_task(rid, pwd, uid), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/friend', methods=['GET', 'POST'])
def api_friend():
    if not verify_api(): return jsonify({"error": "Invalid Key"}), 401
    uid = request.args.get('uid')
    try:
        asyncio.run_coroutine_threadsafe(api_friend_task(uid), event_loop)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
async def run_async(coro):
    """Helper function to run async coroutines in sync context"""
    loop = asyncio.get_event_loop()
    return await loop.create_task(coro)


key = b'Yg&tc%DEuh6%Zc^8'
iv = b'6oyZDr22E3ychjM%'

event_loop = asyncio.new_event_loop()


def run_async_loop(loop):
    asyncio.set_event_loop(loop)
    loop.run_forever()


# Start the event loop in a separate thread
async_thread = Thread(target=run_async_loop, args=(event_loop, ), daemon=True)
async_thread.start()

bot_busy = False
current_operation = None


@bot.message_handler(commands=["start"])
def handle_start_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    help_text = """
<b>🔥 FREE FIRE BOT COMMANDS 🔥</b>

<b>📌 BASIC TEAM COMMANDS</b>
<b>/2 [UID]</b> - CREATE 2-PLAYER TEAM
<b>/3 [UID]</b> - CREATE 3-PLAYER TEAM 
<b>/4 [UID]</b> - CREATE 4-PLAYER TEAM
<b>/5 [UID]</b> - CREATE 5-PLAYER TEAM
<b>/6 [UID]</b> - CREATE 6-PLAYER TEAM
<b>/tc [CODE]</b> - JOIN SPECIFIC TEAM

<b>💣 SPAM FUNCTIONS</b>  
<b>/spam_inv [UID]</b> - SEND MULTIPLE GROUP INVITES
<b>/sm [UID]</b> - SEND MULTIPLE JOIN REQUESTS 
<b>/spam_room [UID]</b> - SEND MULTIPLE ROOM JOIN REQUESTS
<b>/team [UID]</b> - RAPID TEAM SWITCHING
<b>/lag [CODE]</b> - TEAM CODE SPAM

<b>💃 DANCE & GHOST COMMANDS</b>
<b>/dance [TEAMCODE] [UID1] [UID2] ... [EMOTEID]</b> - SEND CUSTOM DANCE
<b>/evo_dance [TEAMCODE] [UID1] [UID2] ... [REPEAT]</b> - SEND RANDOM EVOLUTION DANCE
<b>/ghost [TEAMCODE]</b> - SEND GHOST TO TEAM

<b>✅ VERIFICATION</b>
<b>/check</b> - VERIFY CHANNEL MEMBERSHIP

<b>📝 IMPORTANT NOTES:</b>
<b>1. UID MUST BE 8-11 DIGITS</b>
<b>2. TEAM CODES MUST BE 7 DIGITS</b>  
<b>3. INVITES LAST 8 SECONDS</b>
<b>4. MAY TRIGGER COOLDOWNS</b>
<b>5. DON'T SPAM THE SAME TARGET REPEATEDLY</b>
    """
    
    bot.reply_to(message, help_text, parse_mode="HTML")
    
@bot.message_handler(commands=["check"])
def handle_check_channels(message):
    """Manual channel verification check command"""
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    membership_status = check_all_channel_memberships(user_id)
    all_joined = all(membership_status.values())
    
    if all_joined:
        save_channel_verified(user_id)
        bot.reply_to(
            message,
            "<b>✅ VERIFICATION SUCCESSFUL!</b>\n\n"
            "<b>ALL CHANNELS JOINED</b>\n"
            "<b>YOU CAN USE ALL COMMANDS NOW</b>",
            parse_mode="HTML"
        )
    else:
        missing = [name for name, joined in membership_status.items() if not joined]
        missing_text = "\n".join([f"❌ {name}" for name in missing])
        
        markup = create_channel_verification_keyboard(missing)
        
        bot.reply_to(
            message,
            f"<b>⚠️ VERIFICATION INCOMPLETE</b>\n\n"
            f"<b>MISSING CHANNELS:</b>\n{missing_text}\n\n"
            f"<b>JOIN ALL CHANNELS AND TRY AGAIN</b>",
            parse_mode="HTML",
            reply_markup=markup
        )


@bot.message_handler(commands=["2", "3", "4", "5", "6"])
def handle_team_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(message, f"<b>⏳ BOT IS BUSY</b>\n"
                     f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
                     f"<b>PLEASE WAIT FOR COMPLETION</b>",
                     parse_mode="HTML")
        return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            command = parts[0]
            bot.reply_to(message, f"<b>⚠️ MISSING UID</b>\n"
                         f"<b>USAGE: {command} [UID]</b>\n"
                         f"<b>EXAMPLE: {command} 16519667180</b>\n"
                         f"<b>CREATES {command[1:]}-PLAYER TEAM</b>",
                         parse_mode="HTML")
            return

        command = parts[0]
        uid = parts[1]

        if not uid.isdigit() or len(uid) < 8 or len(uid) > 11:
            bot.reply_to(message, "<b>❌ INVALID UID FORMAT</b>\n"
                         "<b>• MUST BE 8-11 DIGITS</b>\n"
                         "<b>• EXAMPLE: 16519667180</b>",
                         parse_mode="HTML")
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(message, "<b>⚠️ CONNECTION ERROR</b>\n"
                         "<b>BOT NOT CONNECTED TO FREE FIRE</b>\n"
                         "<b>PLEASE TRY AGAIN LATER</b>",
                         parse_mode="HTML")
            return

        team_size = int(command[1:]) - 1
        masked_uid = f"{uid}"

        bot_busy = True
        current_operation = f"{team_size+1}-PLAYER TEAM"

        processing_msg = bot.reply_to(
            message, f"<b>🔄 CREATING {team_size+1}-PLAYER TEAM...</b>\n"
            f"<b>• FOR UID: {masked_uid}</b>\n"
            f"<b>• PLEASE WAIT</b>",
            parse_mode="HTML")

        asyncio.run_coroutine_threadsafe(
            handle_group_invite(int(uid), team_size, message.chat.id,
                                processing_msg.message_id), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(message, f"<b>❌ UNEXPECTED ERROR</b>\n"
                     f"<b>PLEASE TRY AGAIN LATER</b>\n"
                     f"<b>ERROR: {str(e)}</b>",
                     parse_mode="HTML")


@bot.message_handler(commands=["spam_inv"])
def handle_spam_inv_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(message, f"<b>⏳ BOT IS BUSY</b>\n"
                     f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
                     f"<b>PLEASE WAIT FOR COMPLETION</b>",
                     parse_mode="HTML")
        return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, "<b>⚠️ MISSING UID</b>\n"
                         "<b>USAGE: /spam_inv [UID]</b>\n"
                         "<b>EXAMPLE: /spam_inv 16519667180</b>",
                         parse_mode="HTML")
            return

        uid = parts[1]

        if not uid.isdigit() or len(uid) < 8 or len(uid) > 11:
            bot.reply_to(message, "<b>❌ INVALID UID</b>\n"
                         "<b>MUST BE 8-11 DIGITS</b>",
                         parse_mode="HTML")
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(message, "<b>⚠️ BOT OFFLINE</b>\n"
                         "<b>NOT CONNECTED TO FREE FIRE</b>",
                         parse_mode="HTML")
            return

        bot_busy = True
        current_operation = "SPAM INVITE"

        sent_msg = bot.reply_to(message, f"<b>🚀 SPAM INVITE STARTED</b>\n"
                                f"<b>• TARGET: {uid}</b>\n"
                                f"<b>• DURATION: 30 SECONDS</b>\n"
                                f"<b>• STATUS: RUNNING...</b>",
                                parse_mode="HTML")

        async def perform_spam_invite():
            try:
                start_time = time.time()
                success_count = 0
                while time.time() - start_time < 30:
                    try:
                        await handle_group_spam_invite(int(uid))
                        success_count += 1
                        await asyncio.sleep(0.1)
                    except Exception as e:
                        print(f"Error in spam invite: {str(e)[:50]}")
                        await asyncio.sleep(0.5)
            finally:
                global bot_busy, current_operation
                bot_busy = False
                current_operation = None
                bot.edit_message_text(
                    f"<b>✅ SPAM INVITE COMPLETED</b>\n"
                    f"<b>• TARGET: {uid}</b>",
                    chat_id=sent_msg.chat.id,
                    message_id=sent_msg.message_id,
                    parse_mode="HTML")

        asyncio.run_coroutine_threadsafe(perform_spam_invite(), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(message, f"<b>❌ ERROR</b>\n"
                     f"<b>{str(e)}</b>",
                     parse_mode="HTML")


@bot.message_handler(commands=["sm"])
def handle_spam_req_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(message, f"<b>⏳ BOT IS BUSY</b>\n"
                     f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
                     f"<b>PLEASE WAIT FOR COMPLETION</b>",
                     parse_mode="HTML")
        return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, "<b>⚠️ MISSING UID</b>\n"
                         "<b>USAGE: /sm [UID]</b>\n"
                         "<b>EXAMPLE: /sm 16519667180</b>",
                         parse_mode="HTML")
            return

        uid = parts[1]

        if not uid.isdigit() or len(uid) < 8 or len(uid) > 11:
            bot.reply_to(message, "<b>❌ INVALID UID</b>\n"
                         "<b>• MUST BE 8-11 DIGITS</b>\n"
                         "<b>• EXAMPLE: 16519667180</b>",
                         parse_mode="HTML")
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(message, "<b>⚠️ BOT OFFLINE</b>\n"
                         "<b>NOT CONNECTED TO FREE FIRE</b>",
                         parse_mode="HTML")
            return

        bot_busy = True
        current_operation = "JOIN REQUEST SPAM"

        sent_msg = bot.reply_to(message,
                                f"<b>🌀 JOIN REQUEST SPAM STARTED</b>\n"
                                f"<b>• TARGET: {uid}</b>\n"
                                f"<b>• DURATION: 30 SECONDS</b>\n"
                                f"<b>• STATUS: RUNNING...</b>",
                                parse_mode="HTML")

        async def perform_spam_req():
            try:
                start_time = time.time()
                success_count = 0
                while time.time() - start_time < 30:
                    try:
                        await start_spam_invite(int(uid))
                        success_count += 1
                        await asyncio.sleep(0.1)
                    except Exception as e:
                        print(f"Error in spam request: {str(e)[:50]}")
                        await asyncio.sleep(0.5)
            finally:
                global bot_busy, current_operation
                bot_busy = False
                current_operation = None
                bot.edit_message_text(
                    f"<b>✅ JOIN REQUEST SPAM COMPLETED</b>\n"
                    f"<b>• TARGET: {uid}</b>",
                    chat_id=sent_msg.chat.id,
                    message_id=sent_msg.message_id,
                    parse_mode="HTML")

        asyncio.run_coroutine_threadsafe(perform_spam_req(), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(message, f"<b>❌ COMMAND ERROR</b>\n"
                     f"<b>{str(e)[:100]}</b>",
                     parse_mode="HTML")


@bot.message_handler(commands=["spam_room"])
def handle_spam_room_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name

    # Channel verification
    if not verify_user_channels(message):
        return

    global bot_busy, current_operation, spam_room, spammer_uid, spam_chat_id, spam_uid

    if bot_busy:
        bot.reply_to(
            message,
            f"<b>⏳ BOT IS BUSY</b>\n"
            f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
            f"<b>PLEASE WAIT FOR COMPLETION</b>",
            parse_mode="HTML"
        )
        return

    try:
        parts = message.text.split()

        # Validate format
        if len(parts) < 2 or not parts[1].isdigit():
            bot.reply_to(message, "<b>⚠️ MISSING UID</b>\n"
                         "<b>USAGE: /spam_room [UID]</b>\n"
                         "<b>EXAMPLE: /spam_room 16519667180</b>",
                         parse_mode="HTML")
            return

        target_uid = parts[1]

        # Validate UID
        if len(target_uid) < 8 or len(target_uid) > 11:
            bot.reply_to(
                message,
                "<b>❌ INVALID UID</b>\n"
                "<b>UID must be 8–11 digits.</b>",
                parse_mode="HTML"
            )
            return
        
        # Check in-game connection
        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(
                message,
                "<b>⚠️ BOT OFFLINE</b>\n"
                "<b>NOT CONNECTED TO GAME</b>",
                parse_mode="HTML"
            )
            return

        # Set global spam flags
        spam_room = True
        spam_uid = int(target_uid)        # FIXED → convert to int
        spammer_uid = user_id
        spam_chat_id = message.chat.id

        bot_busy = True
        current_operation = "ROOM SPAM"

        status_msg = bot.reply_to(
            message,
            f"<b>🌀 ROOM SPAM STARTED</b>\n"
            f"<b>• TARGET UID: {target_uid}</b>\n"
            f"<b>• DURATION: 60 SECONDS</b>\n"
            f"<b>• STATUS: RUNNING...</b>",
            parse_mode="HTML"
        )

        # Background async spam logic
        async def perform_spam_room():
            start = time.time()

            while time.time() - start < 60:
                try:
                    await uid_status(int(target_uid), key, iv)
                    await asyncio.sleep(0.4)
                except:
                    await asyncio.sleep(0.6)

            # Stop spam
            global spam_room, bot_busy, current_operation
            spam_room = False
            bot_busy = False
            current_operation = None

            bot.edit_message_text(
                chat_id=status_msg.chat.id,
                message_id=status_msg.message_id,
                text=(
                    f"<b>✅ ROOM SPAM COMPLETE</b>\n"
                    f"<b>• TARGET UID: {target_uid}</b>"
                ),
                parse_mode="HTML"
            )

        asyncio.run_coroutine_threadsafe(perform_spam_room(), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(
            message,
            f"<b>❌ COMMAND ERROR</b>\n<b>{str(e)[:100]}</b>",
            parse_mode="HTML"
        )


@bot.message_handler(commands=["lag"])
def handle_lag_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(message, f"<b>⏳ BOT IS BUSY</b>\n"
                     f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
                     f"<b>PLEASE WAIT FOR COMPLETION</b>",
                     parse_mode="HTML")
        return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, "<b>⚠️ MISSING TEAM CODE</b>\n"
                         "<b>USAGE: /lag [7-DIGIT-CODE]</b>\n"
                         "<b>EXAMPLE: /lag 1234567</b>",
                         parse_mode="HTML")
            return

        team_code = parts[1]

        if not team_code.isdigit() or len(team_code) != 7:
            bot.reply_to(message, "<b>❌ INVALID CODE</b>\n"
                         "<b>• MUST BE 7 DIGITS</b>\n"
                         "<b>• EXAMPLE: 1234567</b>",
                         parse_mode="HTML")
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(message, "<b>⚠️ BOT OFFLINE</b>\n"
                         "<b>NOT CONNECTED TO FREE FIRE</b>",
                         parse_mode="HTML")
            return

        bot_busy = True
        current_operation = "LAG ATTACK"

        sent_msg = bot.reply_to(message, f"<b>💣 LAG ATTACK INITIATED</b>\n"
                                f"<b>• TARGET CODE: {team_code}</b>\n"
                                f"<b>• DURATION: 10 SECONDS</b>\n"
                                f"<b>• STATUS: RUNNING...</b>",
                                parse_mode="HTML")

        async def execute_attack():
            try:
                success_count = await perform_lag_attack(team_code, key, iv)
            finally:
                global bot_busy, current_operation
                bot_busy = False
                current_operation = None
                bot.edit_message_text(
                    f"<b>💣 LAG ATTACK COMPLETED</b>\n"
                    f"<b>• TARGET CODE: {team_code}</b>",
                    chat_id=sent_msg.chat.id,
                    message_id=sent_msg.message_id,
                    parse_mode="HTML")
                print(
                    f"🔥 LAG ATTACK COMPLETE: {success_count} joins in 10 seconds"
                )

        asyncio.run_coroutine_threadsafe(execute_attack(), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(message, f"<b>❌ COMMAND ERROR</b>\n"
                     f"<b>{str(e)[:100]}</b>",
                     parse_mode="HTML")


@bot.message_handler(commands=["tc"])
def handle_join_tc_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(message, f"<b>⏳ BOT IS BUSY</b>\n"
                     f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
                     f"<b>PLEASE WAIT FOR COMPLETION</b>",
                     parse_mode="HTML")
        return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, "<b>⚠️ MISSING TEAM CODE</b>\n"
                         "<b>USAGE: /tc [7-DIGIT-CODE]</b>\n"
                         "<b>EXAMPLE: /tc 1234567</b>",
                         parse_mode="HTML")
            return

        team_code = parts[1]

        if not team_code.isdigit() or len(team_code) != 7:
            bot.reply_to(message, "<b>❌ INVALID CODE FORMAT</b>\n"
                         "<b>• MUST BE 7 DIGITS</b>\n"
                         "<b>• EXAMPLE: 1234567</b>",
                         parse_mode="HTML")
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(message, "<b>⚠️ CONNECTION ERROR</b>\n"
                         "<b>BOT NOT CONNECTED TO GAME</b>",
                         parse_mode="HTML")
            return

        bot_busy = True
        current_operation = "JOIN TEAM"

        status_msg = bot.reply_to(message,
                                  f"<b>🔍 ATTEMPTING TO JOIN TEAM...</b>\n"
                                  f"<b>CODE: {team_code}</b>",
                                  parse_mode="HTML")

        async def join_and_notify():
            try:
                result = await join_teamcode(team_code, key, iv)
                bot.edit_message_text(
                    chat_id=message.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>✅ JOINED TEAM SUCCESSFULLY</b>\n"
                    f"<b>CODE: {team_code}</b>",
                    parse_mode="HTML")
            except Exception as e:
                bot.edit_message_text(chat_id=message.chat.id,
                                      message_id=status_msg.message_id,
                                      text=f"<b>❌ FAILED TO JOIN TEAM</b>\n"
                                      f"<b>CODE: {team_code}</b>\n"
                                      f"<b>ERROR: {str(e)[:50]}</b>",
                                      parse_mode="HTML")
            finally:
                global bot_busy, current_operation
                bot_busy = False
                current_operation = None

        asyncio.run_coroutine_threadsafe(join_and_notify(), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(message, f"<b>❌ COMMAND ERROR</b>\n"
                     f"<b>{str(e)[:100]}</b>",
                     parse_mode="HTML")


@bot.message_handler(commands=["team"])
def handle_team_spam_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(message, f"<b>⏳ BOT IS BUSY</b>\n"
                     f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
                     f"<b>PLEASE WAIT FOR COMPLETION</b>",
                     parse_mode="HTML")
        return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, "<b>⚠️ MISSING UID</b>\n"
                         "<b>USAGE: /team [UID]</b>\n"
                         "<b>EXAMPLE: /team 16519667180</b>",
                         parse_mode="HTML")
            return

        uid = parts[1]

        if not uid.isdigit() or len(uid) < 8 or len(uid) > 11:
            bot.reply_to(message, "<b>❌ INVALID UID</b>\n"
                         "<b>• MUST BE 8-11 DIGITS</b>\n"
                         "<b>• EXAMPLE: 16519667180</b>",
                         parse_mode="HTML")
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(message, "<b>⚠️ BOT OFFLINE</b>\n"
                         "<b>NOT CONNECTED TO FREE FIRE</b>",
                         parse_mode="HTML")
            return

        bot_busy = True
        current_operation = "TEAM SPAM"

        status_msg = bot.reply_to(message, "<b>🌀 STARTING TEAM SPAM</b>\n"
                                  f"<b>• TARGET: {uid}</b>\n"
                                  "<b>• DURATION: 30 SECONDS</b>",
                                  parse_mode="HTML")

        def run_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            try:
                loop.run_until_complete(execute_team_spam(int(uid)))
                bot.edit_message_text(chat_id=message.chat.id,
                                      message_id=status_msg.message_id,
                                      text="<b>✅ TEAM SPAM COMPLETE</b>\n"
                                      f"<b>• Target: {uid}</b>",
                                      parse_mode="HTML")
            except Exception as e:
                bot.edit_message_text(chat_id=message.chat.id,
                                      message_id=status_msg.message_id,
                                      text=f"<b>❌ TEAM SPAM FAILED</b>\n"
                                      f"<b>• Error: {str(e)[:50]}</b>",
                                      parse_mode="HTML")
            finally:
                global bot_busy, current_operation
                bot_busy = False
                current_operation = None
                loop.close()

        thread = threading.Thread(target=run_async)
        thread.start()

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(message, f"<b>❌ COMMAND ERROR</b>\n"
                     f"<b>{str(e)[:100]}</b>",
                     parse_mode="HTML")

# Add these Telegram bot handlers after the existing @bot.message_handler commands

@bot.message_handler(commands=["dance"])
def handle_dance_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    chat = message.chat  # chat variable
    
    # Channel verification (keep it)
    if not verify_user_channels(message):
        return
    
    # ❌ VPLink verification removed completely
    
    # Busy system
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(
            message,
            f"<b>⏳ BOT IS BUSY</b>\n"
            f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
            f"<b>PLEASE WAIT FOR COMPLETION</b>",
            parse_mode="HTML"
        )
        return

    try:
        parts = message.text.split()
        
        # Format check
        if len(parts) < 3:
            bot.reply_to(
                message,
                "<b>⚠️ INVALID FORMAT</b>\n"
                "<b>USAGE: /dance [TEAMCODE] [UID1] [UID2] ... [EMOTEID]</b>\n"
                "<b>EXAMPLE: /dance 1234567 16519667180 909000063</b>",
                parse_mode="HTML"
            )
            return

        try:
            team_code = parts[1]
            emote_id = int(parts[-1])
            target_uids = [int(uid_str) for uid_str in parts[2:-1]]
            
            # Validate team code
            if not team_code.isdigit() or len(team_code) != 7:
                bot.reply_to(
                    message,
                    f"<b>❌ INVALID TEAM CODE: {team_code}</b>\n"
                    "<b>• MUST BE EXACTLY 7 DIGITS</b>",
                    parse_mode="HTML"
                )
                return
            
            # Minimum 1 UID
            if len(target_uids) < 1:
                bot.reply_to(
                    message,
                    "<b>❌ NEED AT LEAST 1 UID</b>\n"
                    "<b>EXAMPLE: /dance 1234567 16519667180 909000063</b>",
                    parse_mode="HTML"
                )
                return
            
            # UID validation
            for uid in target_uids:
                if len(str(uid)) < 8 or len(str(uid)) > 11:
                    bot.reply_to(
                        message,
                        f"<b>❌ INVALID UID: {uid}</b>\n"
                        "<b>• MUST BE 8-11 DIGITS</b>",
                        parse_mode="HTML"
                    )
                    return

        except ValueError:
            bot.reply_to(
                message,
                "<b>❌ INVALID NUMBER FORMAT</b>\n"
                "<b>CHECK YOUR TEAMCODE AND UIDS</b>",
                parse_mode="HTML"
            )
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(
                message,
                "<b>⚠️ BOT OFFLINE</b>\n"
                "<b>NOT CONNECTED TO FREE FIRE</b>",
                parse_mode="HTML"
            )
            return

        # Start operation
        bot_busy = True
        current_operation = "DANCE EMOTE"

        uids_display = ", ".join([str(uid)[:4] + "..." + str(uid)[-3:] for uid in target_uids])

        status_msg = bot.reply_to(
            message,
            f"<b>💃 STARTING DANCE EMOTE</b>\n"
            f"<b>• TEAM CODE: {team_code}</b>\n"
            f"<b>• TARGETS: {len(target_uids)} PLAYERS</b>\n"
            f"<b>• EMOTE ID: {emote_id}</b>\n"
            f"<b>• STATUS: JOINING TEAM...</b>",
            parse_mode="HTML"
        )

        async def perform_dance():
            try:
                # Join Team
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>🔄 JOINING TEAM...</b>\n<b>• CODE: {team_code}</b>",
                    parse_mode="HTML"
                )
                await join_teamcode(team_code, key, iv)
                await asyncio.sleep(1)
                
                # Send emotes
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>💃 SENDING DANCE EMOTES...</b>\n"
                         f"<b>• TARGETS: {len(target_uids)} PLAYERS</b>\n"
                         f"<b>• EMOTE ID: {emote_id}</b>",
                    parse_mode="HTML"
                )
                
                tasks = []
                for target_uid in target_uids:
                    tasks.append(emote_send(target_uid, emote_id, key, iv))
                
                await asyncio.gather(*tasks)
                await asyncio.sleep(0.5)
                
                # Leave team
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>🚪 LEAVING GROUP...</b>",
                    parse_mode="HTML"
                )
                await left_group(key, iv)
                await asyncio.sleep(0.5)
                
                # Success
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=(
                        f"<b>✅ DANCE EMOTE COMPLETE!</b>\n"
                        f"<b>• TEAM CODE: {team_code}</b>\n"
                        f"<b>• TARGETS: {len(target_uids)} PLAYERS</b>\n"
                        f"<b>• EMOTE ID: {emote_id}</b>\n"
                        f"<b>• STATUS: JOINED → DANCED → LEFT</b>"
                    ),
                    parse_mode="HTML"
                )

            except Exception as e:
                try:
                    await left_group(key, iv)
                except:
                    pass
                    
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>❌ DANCE FAILED</b>\n<b>• ERROR: {str(e)[:80]}</b>",
                    parse_mode="HTML"
                )
            finally:
                global bot_busy, current_operation
                bot_busy = False
                current_operation = None

        asyncio.run_coroutine_threadsafe(perform_dance(), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(
            message,
            f"<b>❌ COMMAND ERROR</b>\n<b>{str(e)[:100]}</b>",
            parse_mode="HTML"
        )


@bot.message_handler(commands=["evo_dance"])
def handle_evo_dance_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check channel verification first
    if not verify_user_channels(message):
        return  # User needs to verify channels first
    
    # Original help text (verification passed)
    global bot_busy, current_operation

    if bot_busy:
        bot.reply_to(message, f"<b>⏳ BOT IS BUSY</b>\n"
                     f"<b>CURRENTLY RUNNING: {current_operation}</b>\n"
                     f"<b>PLEASE WAIT FOR COMPLETION</b>",
                     parse_mode="HTML")
        return

    try:
        parts = message.text.split()
        
        # Check minimum parameters: /evo_dance teamcode uid1
        if len(parts) < 3:
            bot.reply_to(message, 
                "<b>⚠️ INVALID FORMAT</b>\n"
                "<b>USAGE: /evo_dance [TEAMCODE] [UID1] [UID2] ... [REPEAT]</b>\n"
                "<b>EXAMPLE: /evo_dance 1234567 16519667180 5</b>\n"
                "<b>• TEAMCODE MUST BE 7 DIGITS</b>\n"
                "<b>• YOU CAN ADD 1-6 UIDS</b>\n"
                "<b>• REPEAT IS OPTIONAL (DEFAULT: 1)</b>",
                parse_mode="HTML")
            return

        # Check if last part is repeat count (1-2 digits)
        repeat_count = 1
        temp_parts = parts[2:]  # All parts after teamcode
        
        if len(temp_parts) >= 2 and temp_parts[-1].isdigit() and 1 <= len(temp_parts[-1]) <= 2:
            # Last parameter might be repeat count
            # Check if it's valid UID or repeat
            last_num = temp_parts[-1]
            if len(last_num) <= 2:  # If 1-2 digits, it's repeat count
                repeat_count = int(last_num)
                temp_parts = temp_parts[:-1]  # Remove repeat from UIDs

        try:
            team_code = parts[1]
            
            # Get UIDs (after removing repeat if exists)
            target_uids = [int(uid_str) for uid_str in temp_parts]
            
            # Validate team code
            if not team_code.isdigit() or len(team_code) != 7:
                bot.reply_to(message, 
                    f"<b>❌ INVALID TEAM CODE: {team_code}</b>\n"
                    "<b>• MUST BE EXACTLY 7 DIGITS</b>\n"
                    "<b>• EXAMPLE: 1234567</b>",
                    parse_mode="HTML")
                return
            
            # Validate minimum 1 UID
            if len(target_uids) < 1:
                bot.reply_to(message, 
                    "<b>❌ NEED AT LEAST 1 UID</b>\n"
                    "<b>EXAMPLE: /evo_dance 1234567 16519667180</b>",
                    parse_mode="HTML")
                return
            
            # Validate UIDs
            for uid in target_uids:
                if len(str(uid)) < 8 or len(str(uid)) > 11:
                    bot.reply_to(message, 
                        f"<b>❌ INVALID UID: {uid}</b>\n"
                        "<b>• MUST BE 8-11 DIGITS</b>",
                        parse_mode="HTML")
                    return

        except ValueError:
            bot.reply_to(message, 
                "<b>❌ INVALID NUMBER FORMAT</b>\n"
                "<b>CHECK YOUR TEAMCODE AND UIDS</b>",
                parse_mode="HTML")
            return

        if not all([whisper_writer, online_writer, key, iv]):
            bot.reply_to(message, 
                "<b>⚠️ BOT OFFLINE</b>\n"
                "<b>NOT CONNECTED TO FREE FIRE</b>",
                parse_mode="HTML")
            return

        bot_busy = True
        current_operation = "EVOLUTION DANCE"

        # Create UIDs display
        uids_display = ", ".join([str(uid)[:4] + "..." + str(uid)[-3:] for uid in target_uids])
        
        status_msg = bot.reply_to(message, 
            f"<b>🎭 STARTING EVOLUTION DANCE</b>\n"
            f"<b>• TEAM CODE: {team_code}</b>\n"
            f"<b>• TARGETS: {len(target_uids)} PLAYERS</b>\n"
            f"<b>• REPEATS: {repeat_count}</b>\n"
            f"<b>• STATUS: JOINING TEAM...</b>",
            parse_mode="HTML")

        async def perform_evo_dance():
            try:
                # Step 1: Join team
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>🔄 JOINING TEAM...</b>\n"
                         f"<b>• CODE: {team_code}</b>",
                    parse_mode="HTML"
                )
                await join_teamcode(team_code, key, iv)
                await asyncio.sleep(1)
                
                # Step 2: Send evolution dances
                total_sent = 0
                emotes_sent = []
                
                for repeat in range(repeat_count):
                    # Get random evolution emote
                    random_emote = get_random_emotes()
                    emotes_sent.append(random_emote)
                    
                    # Update status with current repeat
                    bot.edit_message_text(
                        chat_id=status_msg.chat.id,
                        message_id=status_msg.message_id,
                        text=f"<b>🎭 SENDING EVOLUTION DANCE</b>\n"
                             f"<b>• PROGRESS: {repeat + 1}/{repeat_count}</b>\n"
                             f"<b>• TARGETS: {len(target_uids)} PLAYERS</b>\n"
                             f"<b>• CURRENT EMOTE: {random_emote}</b>",
                        parse_mode="HTML"
                    )
                    
                    # Send to all UIDs simultaneously
                    tasks = []
                    for target_uid in target_uids:
                        tasks.append(emote_send(target_uid, random_emote, key, iv))
                        total_sent += 1
                    
                    await asyncio.gather(*tasks)
                    
                    # 7.5 second delay between repeats (evolution dance duration)
                    if repeat < repeat_count - 1:
                        await asyncio.sleep(7.5)
                
                await asyncio.sleep(0.5)
                
                # Step 3: Leave group
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>🚪 LEAVING GROUP...</b>",
                    parse_mode="HTML"
                )
                await left_group(key, iv)
                await asyncio.sleep(0.5)
                
                # Success message
                emotes_display = ", ".join([str(e) for e in emotes_sent[:3]])
                if len(emotes_sent) > 3:
                    emotes_display += f" ... (+{len(emotes_sent)-3} more)"
                
                if repeat_count > 1:
                    result_text = (
                        f"<b>✅ EVOLUTION DANCE COMPLETE!</b>\n"
                        f"<b>• TEAM CODE: {team_code}</b>\n"
                        f"<b>• TARGETS: {len(target_uids)} PLAYERS</b>\n"
                        f"<b>• REPEATS: {repeat_count}</b>\n"
                        f"<b>• TOTAL EMOTES: {total_sent}</b>\n"
                        f"<b>• EMOTES USED: {emotes_display}</b>\n"
                        f"<b>• STATUS: JOINED → DANCED → LEFT</b>"
                    )
                else:
                    result_text = (
                        f"<b>✅ EVOLUTION DANCE COMPLETE!</b>\n"
                        f"<b>• TEAM CODE: {team_code}</b>\n"
                        f"<b>• TARGETS: {len(target_uids)} PLAYERS</b>\n"
                        f"<b>• EMOTE ID: {emotes_sent[0]}</b>\n"
                        f"<b>• STATUS: JOINED → DANCED → LEFT</b>"
                    )
                
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=result_text,
                    parse_mode="HTML"
                )

            except Exception as e:
                # Try to leave group even if error occurs
                try:
                    await left_group(key, iv)
                except:
                    pass
                    
                bot.edit_message_text(
                    chat_id=status_msg.chat.id,
                    message_id=status_msg.message_id,
                    text=f"<b>❌ EVOLUTION DANCE FAILED</b>\n"
                         f"<b>• ERROR: {str(e)[:80]}</b>",
                    parse_mode="HTML"
                )
            finally:
                global bot_busy, current_operation
                bot_busy = False
                current_operation = None

        asyncio.run_coroutine_threadsafe(perform_evo_dance(), event_loop)

    except Exception as e:
        bot_busy = False
        current_operation = None
        bot.reply_to(message, 
            f"<b>❌ COMMAND ERROR</b>\n"
            f"<b>{str(e)[:100]}</b>",
            parse_mode="HTML")

@bot.message_handler(commands=["ghost"])
def handle_code_command(message):
    # 🔒 CHANNEL VERIFICATION
    if not verify_user_channels(message):
        return

    update_command_stats("ghost ")

    parts = message.text.split()
    if len(parts) < 2:
        bot.reply_to(
            message,
            "<b>⚠️ MISSING TEAM CODE</b>\n"
            "<b>USAGE:</b> /ghost [7-DIGIT-CODE]\n"
            "<b>EXAMPLE:</b> /ghost 1234567",
            parse_mode="HTML"
        )
        return

    team_code = parts[1].strip()

    # Validate code length
    if not team_code.isdigit() or not (6 <= len(team_code) <= 7):
        bot.reply_to(
            message,
            "<b>❌ INVALID TEAM CODE</b>\n"
            "<b>CODE MUST BE 6-7 DIGITS</b>\n"
            "<b>EXAMPLE:</b> 1234567",
            parse_mode="HTML"
        )
        return

    # ⏳ FIRST LOADING MESSAGE
    status = bot.reply_to(
        message,
        f"<b>⏳ CONNECTING TO GHOST SERVER...</b>\n"
        f"<b>TEAM CODE:</b> {team_code}",
        parse_mode="HTML"
    )

    try:
        import requests
        url = "http://dev-ghost-api.up.railway.app/execute_command_all"
        params = {"command": f"/bngx={team_code}"}

        res = requests.get(url, params=params, timeout=15)

        if res.status_code == 200:
            # ✅ SUCCESS → EDIT MESSAGE
            bot.edit_message_text(
                chat_id=status.chat.id,
                message_id=status.message_id,
                text=(
                    "<b>✅ GHOST ENTERED TEAM SUCCESSFULLY</b>\n"
                    f"<b>TEAM CODE:</b> {team_code}"
                ),
                parse_mode="HTML"
            )
        else:
            # ❌ API ERROR
            bot.edit_message_text(
                chat_id=status.chat.id,
                message_id=status.message_id,
                text=(
                    "<b>❌ API FAILED</b>\n"
                    f"<b>STATUS:</b> {res.status_code}\n"
                    f"<b>TEAM CODE:</b> {team_code}"
                ),
                parse_mode="HTML"
            )

    except Exception as e:
        # ❌ INTERNAL ERROR
        bot.edit_message_text(
            chat_id=status.chat.id,
            message_id=status.message_id,
            text=(
                "<b>❌ ERROR OCCURRED</b>\n"
                f"<b>{str(e)}</b>"
            ),
            parse_mode="HTML"
        )


async def handle_group_invite(target_uid, team_size, chat_id, msg_id):
    try:
        uid_str = str(target_uid)
        masked_uid = f"{uid_str}"
        team_count = team_size + 1

        bot.edit_message_text(
            chat_id=chat_id,
            message_id=msg_id,
            text=f"<b>🔄 STARTING {team_count}-PLAYER TEAM</b>\n"
            f"<b>• FOR: {masked_uid}</b>\n"
            f"<b>• STATUS: CREATING GROUP...</b>",
            parse_mode="HTML")
        await create_group(key, iv)
        await asyncio.sleep(0.5)

        bot.edit_message_text(
            chat_id=chat_id,
            message_id=msg_id,
            text=f"<b>🔄 CONFIGURING TEAM</b>\n"
            f"<b>• FOR: {masked_uid}</b>\n"
            f"<b>• STATUS: SETTING {team_count}-PLAYER MODE...</b>",
            parse_mode="HTML")
        await modify_team_player(str(team_size), key, iv)
        await asyncio.sleep(0.3)

        bot.edit_message_text(chat_id=chat_id,
                              message_id=msg_id,
                              text=f"<b>📩 INVITATION SENT!</b>\n"
                              f"<b>• TO: {masked_uid}</b>\n"
                              f"<b>• TEAM SIZE: {team_count}</b>\n"
                              f"<b>• EXPIRES IN: 8 SECONDS</b>",
                              parse_mode="HTML")
        await invite_target(target_uid, key, iv)

        for remaining in [7, 6, 5, 4, 3, 2, 1]:
            await asyncio.sleep(1)
            bot.edit_message_text(chat_id=chat_id,
                                  message_id=msg_id,
                                  text=f"<b>⏳ INVITATION ACTIVE</b>\n"
                                  f"<b>• TO: {masked_uid}</b>\n"
                                  f"<b>• EXPIRES IN: {remaining} SECONDS</b>\n"
                                  f"<b>• ACCEPT QUICKLY!</b>",
                                  parse_mode="HTML")

        await left_group(key, iv)
        await asyncio.sleep(1)

        bot.edit_message_text(chat_id=chat_id,
                              message_id=msg_id,
                              text=f"<b>⌛ INVITATION EXPIRED</b>\n"
                              f"<b>• TO: {masked_uid}</b>\n"
                              f"<b>• TEAM SIZE: {team_count}</b>\n"
                              f"<b>• DURATION: 8 SECONDS</b>\n"
                              f"<b>• SEND NEW INVITE IF NEEDED</b>",
                              parse_mode="HTML")

    except Exception as e:
        try:
            await left_group(key, iv)
        except:
            pass

        bot.edit_message_text(chat_id=chat_id,
                              message_id=msg_id,
                              text=f"<b>❌ FAILED</b>\n"
                              f"<b>• FOR: {masked_uid}</b>\n"
                              f"<b>• ERROR: {str(e)[:50]}</b>\n"
                              f"<b>• TRY AGAIN OR CHECK UID</b>",
                              parse_mode="HTML")
    finally:
        global bot_busy, current_operation
        bot_busy = False
        current_operation = None


async def perform_lag_attack(team_code, key, iv):
    start_time = time.time()
    success_count = 0
    while time.time() - start_time < 10:
        try:
            await join_teamcode(team_code, key, iv)
            await asyncio.sleep(0.0001)
            await left_group(key, iv)
            success_count += 1
            await asyncio.sleep(0.0001)
        except Exception as e:
            print(f"❌ Error: {str(e)[:50]}")
            await asyncio.sleep(0.1)
    return success_count


async def execute_team_spam(target_uid):
    start_time = time.time()
    try:
        await create_group(key, iv)
        await asyncio.sleep(0.4)
        await modify_team_player("4", key, iv)
        await asyncio.sleep(3)
        await invite_target(target_uid, key, iv)

        while time.time() - start_time < 30:
            try:
                await modify_team_player("4", key, iv)
                await asyncio.sleep(0.01)
                await modify_team_player("2", key, iv)
                await asyncio.sleep(0.01)
            except Exception as loop_error:
                print(f"⚠️ Loop error: {str(loop_error)[:50]}")
                await asyncio.sleep(0.5)
                continue

        await left_group(key, iv)

    except Exception as main_error:
        print(f"❌ Critical error in team spam: {str(main_error)[:50]}")
        try:
            await left_group(key, iv)
        except:
            pass
        raise


async def handle_group_spam_invite(target_uid):
    start_time = time.time()
    uid_str = str(target_uid)
    invite_count = 0

    while time.time() - start_time < 30:
        try:
            await create_group(key, iv)
            await asyncio.sleep(0.1)
            await modify_team_player("0", key, iv)
            await asyncio.sleep(0.1)
            await invite_target(target_uid, key, iv)
            invite_count += 1
            await asyncio.sleep(0.1)
            await left_group(key, iv)
            await asyncio.sleep(0.1)
        except Exception as e:
            print(f"❌ Error: {str(e)[:50]}")
            await asyncio.sleep(0.5)

    print(f"🔥 COMPLETED: {invite_count} invites in 30 seconds")


async def game_start(team_code):
    try:
        teamcode = str(team_code)
        start_time = time.time()        
        while time.time() - start_time < 20:
            await join_teamcode(teamcode, key, iv)
            await start_autooo(key, iv)       
            await left_group(key, iv)         
            await asyncio.sleep(0.15)                               
    except Exception as e:
        print(f"тЭМ Fatal error: {e}")


async def start_spam_invite(target_uid):
    try:
        uid_str = str(target_uid)
        start_time = time.time()
        request_count = 0

        while time.time() - start_time < 30:
            try:
                await skwad(target_uid, key, iv)
                request_count += 1
                await asyncio.sleep(0.3)
            except Exception as e:
                print(f"❌ Error: {str(e)[:50]}")
                await asyncio.sleep(0.5)

        print(f"🔥 COMPLETED: {request_count} requests in 30 seconds")
    except Exception as e:
        print(f"❌ Fatal error: {e}")

from flask import request, jsonify

async def api_skwad_packet(uid, key, iv, writer):
    """
    Standalone packet generator for API that writes to a local writer 
    instead of the global online_writer.
    """
    try:
        packet = spam_pb2.GameSkwadPacket()
        packet.field1 = 33
        details = packet.field2
        details.user_id = int(uid)
        details.country_code = "IND"
        details.status1 = 1
        details.status2 = 1
        details.numbers = bytes([1, 7, 9, 10, 11, 18, 25, 26, 32])
        details.empty1 = "iG:[C][B][FF0000] @API.Spam" # Modified signature for API
        details.rank = 330
        details.field8 = 1000
        details.region_code = "IND"
        details.uuid = bytes([
            49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49,
            50, 48, 102, 53
        ])
        details.field12 = 1
        details.repeated_uid = int(uid)
        nested14 = details.field14
        nested14.field1 = 2203434355
        nested14.field2 = 8
        nested14.field3 = "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
        details.field16 = 1
        details.field17 = 1
        details.field18 = 312
        details.field19 = 46
        details.field23 = bytes([16, 1, 24, 1])
        details.avatar = get_random_avatar()
        details.field26.SetInParent()
        details.field28.SetInParent()
        nested27 = details.field27
        nested27.field1 = 11
        nested27.field2 = 12999994075
        nested27.field3 = 9999
        nested31 = details.field31
        nested31.field1 = 1
        nested31.field2 = 262144
        details.field32 = 262144
        nested34 = details.field34
        nested34.field1 = int(uid)
        nested34.field2 = 8
        nested34.field3 = bytes([15, 6, 21, 8, 10, 11, 19, 12, 17, 4, 14, 20, 7, 2, 1, 5, 16, 3, 13, 18])
        packet.lang = "en"
        nested13 = packet.field13
        nested13.field2 = 1
        nested13.field3 = 1
        serialized = packet.SerializeToString().hex()
        encrypted_packet = await encrypt_packet(serialized, key, iv)
        packet_length = len(encrypted_packet) // 2
        packet_length_hex = await base_to_hex(packet_length)

        if len(packet_length_hex) == 2:
            final_packet = "0515000000" + packet_length_hex + encrypted_packet
        elif len(packet_length_hex) == 3:
            final_packet = "051500000" + packet_length_hex + encrypted_packet
        elif len(packet_length_hex) == 4:
            final_packet = "05150000" + packet_length_hex + encrypted_packet
        
        if writer:
            writer.write(bytes.fromhex(final_packet))
            await writer.drain()
            return True
    except Exception as e:
        print(f"API Packet Gen Error: {e}")
        return False

async def execute_api_spam_process(target_uid, duration=30):
    """
    Full logic: Login -> Connect -> Spam -> Disconnect
    """
    writer = None
    try:
        # 1. Load Credentials
        accounts = load_accounts()
        if not accounts:
            print("[API] No accounts found in access.txt")
            return
        
        # Use the first account available
        open_id, access_token = accounts[0]
        print(f"[API] Starting spam for {target_uid} using OpenID: {open_id}")

        # 2. Major Login
        payload = await MajorLoginProto_Encode(open_id, access_token)
        MajorLoginResponse = await MajorLogin(payload)
        if not MajorLoginResponse:
            print("[API] Login Failed")
            return

        Decode_MajorLogin = await MajorLogin_Decode(MajorLoginResponse)
        base_url = Decode_MajorLogin.url
        token = Decode_MajorLogin.token
        AccountUID = Decode_MajorLogin.account_uid
        key = Decode_MajorLogin.key
        iv = Decode_MajorLogin.iv
        timestamp = Decode_MajorLogin.timestamp

        # 3. Get Login Data (Server IP)
        GetLoginDataResponse = await GetLoginData(base_url, payload, token)
        if not GetLoginDataResponse:
            print("[API] GetLoginData Failed")
            return

        Decode_GetLoginData = await GetLoginData_Decode(GetLoginDataResponse)
        Online_IP_Port = Decode_GetLoginData.Online_IP_Port
        online_ip, online_port = Online_IP_Port.split(":")
        
        # 4. Prepare Startup Packet
        encrypted_startup = await get_encrypted_startup(int(AccountUID), token, int(timestamp), key, iv)

        # 5. Establish TCP Connection
        print(f"[API] Connecting to game server {online_ip}:{online_port}")
        reader, writer = await asyncio.open_connection(online_ip, int(online_port))
        
        # Send Handshake
        writer.write(bytes.fromhex(encrypted_startup))
        await writer.drain()
        
        # 6. Spam Loop
        start_time = time.time()
        count = 0
        print(f"[API] Connection established. Spamming {target_uid} for {duration}s")
        
        while time.time() - start_time < duration:
            await api_skwad_packet(target_uid, key, iv, writer)
            count += 1
            await asyncio.sleep(0.2) # Adjust speed here
            
            # Optional: Read incoming to keep connection alive, but usually not strictly necessary for short spam
            # try:
            #     data = await asyncio.wait_for(reader.read(1024), timeout=0.1)
            # except:
            #     pass

        print(f"[API] Finished. Sent {count} packets.")

    except Exception as e:
        print(f"[API] Error during execution: {e}")
    finally:
        if writer:
            try:
                writer.close()
                await writer.wait_closed()
            except:
                pass
# ... keep the execute_api_spam_process and api_skwad_packet functions as they were ...
# ==========================================
#          SPAM REQUEST API SECTION (FIXED)
# ==========================================

@app.route('/sm', methods=['GET', 'POST'])
def api_spam_req_endpoint():
    """
    API Endpoint: /sm?uid=12345678&duration=30
    Uses the existing bot connection instead of creating new ones
    """
    # Get parameters
    uid = request.args.get('uid')
    duration = request.args.get('duration', default=30, type=int)

    if not uid:
        return jsonify({
            "status": "error",
            "message": "Missing 'uid' parameter"
        }), 400

    if not uid.isdigit():
        return jsonify({
            "status": "error",
            "message": "UID must be numeric"
        }), 400

    # Check if bot is connected
    if not online_writer:
        return jsonify({
            "status": "error", 
            "message": "Bot is not connected to Free Fire"
        }), 503

    # Use the existing connection via the global online_writer
    asyncio.run_coroutine_threadsafe(
        execute_api_spam_with_existing_connection(uid, duration), 
        event_loop
    )

    return jsonify({
        "status": "success",
        "message": f"Spam request initiated for UID {uid}",
        "duration": duration,
        "details": "Using existing bot connection"
    })

async def execute_api_spam_with_existing_connection(target_uid, duration=30):
    """
    Use the existing bot connection instead of creating new ones
    """
    try:
        start_time = time.time()
        count = 0
        print(f"[API] Starting spam for {target_uid} using existing connection")
        
        while time.time() - start_time < duration and online_writer and not online_writer.is_closing():
            try:
                # Use the original skwad function with global online_writer
                await skwad(int(target_uid), key, iv)
                count += 1
                await asyncio.sleep(0.3)  # Reasonable delay
                
            except Exception as e:
                print(f"[API] Error in spam loop: {e}")
                if "Broken pipe" in str(e) or "Connection reset" in str(e):
                    print("[API] Connection lost, stopping spam")
                    break
                await asyncio.sleep(1)  # Wait before retrying on other errors
        
        print(f"[API] Finished. Sent {count} packets via existing connection.")
        
    except Exception as e:
        print(f"[API] Fatal error: {e}")

async def start_bot(uid, password):
    try:
        await asyncio.wait_for(main(uid, password), timeout=TOKEN_EXPIRY)
    except asyncio.TimeoutError:
        print("Token expired after 7 hours. Restarting...")
    except Exception as e:
        print(f"TCP Error: {e}. Restarting...")


async def run_forever(uid, password):
    while True:
        await start_bot(uid, password)


def load_accounts():
    """Load accounts from accounts.txt file"""
    accounts = []
    try:
        with open('accounts.txt', 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    parts = line.split()
                    if len(parts) == 2:
                        uid, password = parts
                        accounts.append((uid, password))
                        print(f"Loaded account: {uid}")
    except FileNotFoundError:
        print("accounts.txt not found, using default account")
        accounts = [("4096333893", "C6FC36E05EBFBCD5116372CD1B0697F170A7A8EB341CC6CD936243C7C50D62E0")]
    return accounts


def run_bot():
    """Run all accounts concurrently"""
    accounts = load_accounts()
    
    async def run_all_accounts():
        tasks = []
        for uid, password in accounts:
            print(f"Starting account: {uid}")
            task = asyncio.create_task(run_forever(uid, password))
            tasks.append(task)
        await asyncio.gather(*tasks)
    
    asyncio.run(run_all_accounts())
#end
if __name__ == '__main__':
    import threading
    
    # 1. Start the Game Client (Async Loop) in a thread
    bot_thread = threading.Thread(target=run_bot)
    bot_thread.daemon = True
    bot_thread.start()

    # 2. Start the Flask API in a separate thread
    def start_api():
        # use_reloader=False is important when running in a thread
        app.run(host='0.0.0.0', port=8081, use_reloader=False)

    flask_thread = threading.Thread(target=start_api)
    flask_thread.daemon = True
    flask_thread.start()

    # 3. Start Telegram Bot (Main Thread - Blocking)
    print("---------------------------------------")
    print(" - Telegram Bot Started")
    print(" - API Server Running at => http://127.0.0.1:8080")
    print(" - Game Client Running...")
    print(f" - Server Login Url => https://loginbp.ggpolarbear.com/")
    print(f" - OB => OB54 | Version => 1.126.1")
    
    print("---------------------------------------")
    
    try:
        bot.infinity_polling()
    except Exception as e:
        print(f"Bot Polling Error: {e}")