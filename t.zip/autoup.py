import os
import sys
import re
import json
import time
import base64
import socket
import pickle
import binascii
import threading
import datetime
import requests
import urllib3
import random
import jwt
from protobuf_decoder.protobuf_decoder import Parser
from datetime import datetime
from google.protobuf.timestamp_pb2 import Timestamp
from concurrent.futures import ThreadPoolExecutor
from threading import Thread
from google_play_scraper import app

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Uaa():
    versions = [
        '4.0.18P6', '4.0.19P7', '4.0.20P1', '4.1.0P3', '4.1.5P2', '4.2.1P8',
        '4.2.3P1', '5.0.1B2', '5.0.2P4', '5.1.0P1', '5.2.0B1', '5.2.5P3',
        '5.3.0B1', '5.3.2P2', '5.4.0P1', '5.4.3B2', '5.5.0P1', '5.5.2P3'
    ]
    models = [
        'SM-A125F', 'SM-A225F', 'SM-A325M', 'SM-A515F', 'SM-A725F', 'SM-M215F', 'SM-M325FV',
        'Redmi 9A', 'Redmi 9C', 'POCO M3', 'POCO M4 Pro', 'RMX2185', 'RMX3085',
        'moto g(9) play', 'CPH2239', 'V2027', 'OnePlus Nord', 'ASUS_Z01QD',
    ]
    android_versions = ['9', '10', '11', '12', '13', '14']
    languages = ['en-US', 'es-MX', 'pt-BR', 'id-ID', 'ru-RU', 'hi-IN']
    countries = ['USA', 'MEX', 'BRA', 'IDN', 'RUS', 'IND']
    version = random.choice(versions)
    model = random.choice(models)
    android = random.choice(android_versions)
    lang = random.choice(languages)
    country = random.choice(countries)
    return f"GarenaMSDK/{version}({model};Android {android};{lang};{country};)"

def Get_OB():
    try:
        url = "https://version.freefire.info/mscrtfree/live/ver.php?version=2.114.18&lang=en&device=android&channel=android_max&appstore=googleplay_max&region=DEFAULT&whitelist_version=1.3.0&whitelist_sp_version=1.0.0&device_name=samsung%20SM-A165F&device_CPU=ARM64%20FP%20ASIMD%20AES&device_GPU=Mali-G57%20MC2&device_mem=3621"
        response = requests.get(url)
        ob = response.json()["latest_release_version"]
        return ob
    except:
        return None
    
def obv():
    ob = Get_OB()
    if ob == None:
        print('Error FeTCinG OB VErsiON ! ')
        return obv()
    else:
        print("OB VERSION = > {}".format(ob))
        return ob
    


def AutoUpdate():
    result = app('com.dts.freefireth',
                lang="fr",
                country='fr')

    version = result['version']


    r = requests.get(f'https://version.ggwhitehawk.com/live/ver.php?version={version}&lang=en&device=android&channel=android&appstore=googleplay&region=ME&whitelist_version=1.3.0&whitelist_sp_version=1.0.0&device_name=google%20G011A&device_CPU=ARMv7%20VFPv3%20NEON%20VMH&device_GPU=Adreno%20(TM)%20640&device_mem=1993').json()
    #print(r['server_url'],r['latest_release_version'])
    url , ob = r['server_url'] , r['latest_release_version']
    
    return url , ob , version