# BY KRISHNA CODER
import os
import re
import json
import time
import base64
import random
import socket
import asyncio
import threading
import binascii
import datetime
from datetime import datetime
import requests
import urllib3
from protobuf_decoder.protobuf_decoder import Parser
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from google.protobuf.timestamp_pb2 import Timestamp

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

Key , Iv = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56]) , bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

async def Enc_Aes(HeX):
    cipher = AES.new(Key , AES.MODE_CBC , Iv)
    return cipher.encrypt(pad(bytes.fromhex(HeX), AES.block_size)).hex()
    
async def Dec_Aes(HeX):
    cipher = AES.new(Key , AES.MODE_CBC , Iv)
    return unpad(cipher.decrypt(bytes.fromhex(HeX)), AES.block_size).hex()
    
async def Enc_Packet(HeX , K , V): 
    return AES.new(K , AES.MODE_CBC , V).encrypt(pad(bytes.fromhex(HeX) ,16)).hex()
    
async def Dec_Packet(HeX , K , V):
    return unpad(AES.new(K , AES.MODE_CBC , V).decrypt(bytes.fromhex(HeX)) , 16).hex()  

async def Enc_Uid(H , Tp):
    e , H = [] , int(H)
    while H:
        e.append((H & 0x7F) | (0x80 if H > 0x7F else 0)) ; H >>= 7
    return bytes(e).hex() if Tp == 'Uid' else None

async def Enc_Vr(N):
    if N < 0: ''
    H = []
    while True:
        Krishna = N & 0x7F ; N >>= 7
        if N: Krishna |= 0x80
        H.append(Krishna)
        if not N: break
    return bytes(H)
    
def Dec_Uid(H):
    n = s = 0
    for b in bytes.fromhex(H):
        n |= (b & 0x7F) << s
        if not b & 0x80: break
        s += 7
    return n
    
async def Create_Variant(field_number, value):
    field_header = (field_number << 3) | 0
    return await Enc_Vr(field_header) + await Enc_Vr(value)

async def Create_Length(field_number, value):
    field_header = (field_number << 3) | 2
    encoded_value = value.encode() if isinstance(value, str) else value
    return await Enc_Vr(field_header) + await Enc_Vr(len(encoded_value)) + encoded_value

async def Create_Proto(fields):
    packet = bytearray()
    for field, value in fields.items():
        if isinstance(value, dict):
            nested_packet = await Create_Proto(value)  # لازم await
            packet.extend(await Create_Length(field, nested_packet))
        elif isinstance(value, int):
            packet.extend(await Create_Variant(field, value))
        elif isinstance(value, str) or isinstance(value, bytes):
            packet.extend(await Create_Length(field, value))
    return packet


    
async def Decode_Hex(H):
    R = hex(H) 
    F = str(R)[2:]
    if len(F) == 1: F = "0" + F ; return F
    else: return F

async def Fix_Packet(parsed_results):
    result_dict = {}
    for result in parsed_results:
        field_data = {}
        field_data['wire_type'] = result.wire_type
        if result.wire_type == "varint":
            field_data['data'] = result.data
        if result.wire_type == "string":
            field_data['data'] = result.data
        if result.wire_type == "bytes":
            field_data['data'] = result.data
        elif result.wire_type == 'length_delimited':
            field_data["data"] = await Fix_Packet(result.data.results)
        result_dict[result.field] = field_data
    return result_dict




async def Enc_UidInFo(uid):
    fields = {1:int(uid)}
    uid = await Create_Proto(fields)
    uid = uid.hex()
    print(uid)
    uid = str(uid)[2:]
    return uid



async def SendInFoPaCKeT(uid , key , iv):
    uid = await Enc_UidInFo(int(uid))
    print(uid)
    hex = f"080112090A05{uid}1005"

    return await GeneRaTePk((hex) , '0F15' , key , iv)

import datetime


async def SendRoomInfo(roomuid , key , iv):
    fields = {
    1: 1,
    2: {
        1: roomuid,
        3: {},
        4: 1,
        6: "en"
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0E15' , key , iv)

def get_idroom_by_idplayer(packet):
    parsed_data = json.loads(packet)
    json_data = parsed_data["5"]["data"]
    data = json_data["1"]["data"]
    idroom = data['15']["data"]
    return idroom
    
def get_room_info(packet):
    parsed_data = json.loads(packet)
    print(parsed_data)
    is_emulator = True
    room_data = parsed_data['5']['data']['1']['data']
    room_id = int(room_data['1']['data'])
    owner_uid = int(room_data['37']['data']['1']['data'])
    room_name = room_data['2']['data']
    mode = room_data['4']['data']
    members = 0
    max_members = room_data['7']['data']
    specs_number = room_data['9']['data']
    
    
    try:
        spectators = room_data['8']['data']
    except KeyError:
        spectators = 0

    try:
        members = room_data['6']['data']
        spectators = room_data['8']['data']
        is_emulator = room_data['17']['data']
        is_emulator = False
    except KeyError:
        is_emulator = True

    if members == 0:
        room_text = f" No Players , Everyone is a spectator  Spectators : {spectators}[FF0000]/[FFFFFF]{specs_number} "
    else:
        room_text = f"{members}/{max_members}"


    if mode == 1:
        mode = "BERMUDA"
    elif mode == 201:
        mode = "BATTLE CAGE"
    elif mode == 15:
        mode = "CLASH SQUAD"
    elif mode == 43:
        mode = "LONE WOLF"
    elif mode == 3:
        mode = "RUSH HOUR"
    elif mode == 27:
        mode = "BOMB SQUAD 5v5"
    elif mode == 24:
        mode = f"{xMsGFixinG('DEATH MATCH')}"

        

    return f"[B][00FF00]- PLAYER IS IN ROOM !\n\n[00FF00]- Room Name : [FFFFFF]{room_name}\n[00FF00]- Room Uid : [FFFFFF]{xMsGFixinG(room_id)}\n[FFFF00]- Owner Uid : [FFFFFF]{xMsGFixinG(owner_uid)}\n[FF0000]- Players In The Room : [FFFFFF]({room_text})\n[FF00FF]- Spectators Count : [FFFFFF]{specs_number}\n[FFA500]- MODE SELECTED : [FFFFFF]{mode}\n[FF00FF]- Emulator Allowed : [FFFFFF]{is_emulator}\n\n[FF0000] - DEV => {xMsGFixinG('@DEVXTLIVE')}"
    


def time_since(timestamp: int) -> str:

    past_time = datetime.datetime.fromtimestamp(timestamp)
    now = datetime.datetime.now()
    diff = now - past_time

    total_seconds = int(diff.total_seconds())
    minutes = (abs(total_seconds) % 3600) // 60
    seconds = abs(total_seconds) % 60

    
    return f"{minutes:02}:{seconds:02}"

def get_player_status(packet):
    parsed_data = json.loads(packet)
    print(parsed_data)
    if "5" not in parsed_data or "data" not in parsed_data["5"]:
        return "OFFLINE"

    json_data = parsed_data["5"]["data"]

    if "1" not in json_data or "data" not in json_data["1"]:
        return "OFFLINE"

    data = json_data["1"]["data"]

    if "3" not in data or "data" not in data["3"]:
        return "OFFLINE"

    status = data["3"]["data"]

    group_count = data.get("9", {}).get("data", 0)
    countmax = data.get("10", {}).get("data", 0) + 1 if "10" in data else 0
    group_owner = data.get("8", {}).get("data", 0)
    time_game_started = data.get("4", {}).get("data", 0)
    if time_game_started == 0:
        pass
    else:
        time_game_started = time_since(time_game_started)
        minutes , seconds = time_game_started.split(":")
    print(time_game_started)
    squad_text = f"{group_count}/{countmax}" if group_count and countmax else None


    mode_id_5 = data.get("5", {}).get("data")
    mode_id_6 = data.get("6", {}).get("data")
    playing = False
    print(status)
    if status == 1:
        base = "SOLO"
    elif status == 2:
        base = "INSQUAD"
    elif status in [3, 5]:
        base = "INGAME"
    elif status == 7:
        base = "MATCHMAKING"
    elif status == 4:
        room_uid = data['15']['data']
        players_count = data['17']['data']
        max_players = data['18']['data']
        room_text = f"{players_count}/{max_players}"
        room_owner = xMsGFixinG(data['1']['data'])
        base = "IN ROOM"
    elif status == 6:
        base = "SOCIAL ISLAND MODE"
    else:
        base = "NOTFOUND"


    parts = []
    mode = None

    if data.get("14") and "data" in data["14"] :
        field14 = data["14"]["data"]
        if field14 == 1:
            mode = "TRAINING"
        elif field14 == 2:
            mode = "SOCIAL ISLAND"
        playing = True
    elif status == 3:
        playing = True

    print(status , mode_id_5 , mode_id_6)
    if mode_id_5 == 2 and mode_id_6 == 1:
        mode = "BR RANK"
    if mode_id_5 == 5 and mode_id_6 == 23:
        mode = "TRAINING"
    elif mode_id_5 == 6 and mode_id_6 == 15:
        mode = "CS RANK"
    elif mode_id_5 == 1 and mode_id_6 == 43:
        mode = "LONE WOLF"
    elif mode_id_5 == 1 and mode_id_6 == 1:
        mode = "BERMUDA"
    elif mode_id_5 == 1 and mode_id_6 == 15:
        mode = "CLASH SQUAD"
    elif mode_id_5 == 1 and mode_id_6 == 29:
        mode = "CONVOY CRUNCH"
    elif mode_id_5 == 1 and mode_id_6 == 61:
        mode = "FREE FOR ALL"


    if base == "INSQUAD" and playing:
        if squad_text:
            parts.append(f"[FFFF00] INSQUAD\n- SQUAD OWNER : {xMsGFixinG(group_owner)}\n[00FF00]- PLAYING ([FFFFFF]{squad_text}) ! \n- [00FF00]PLAYING [FFFFFF]: {mode or 'UNKNOWN'}\n- [FFFF00]For : {minutes} Minutes , {seconds} Seconds ! ")
        else:
            parts.append(f"[FFFF00] INSQUAD\n- SQUAD OWNER : {xMsGFixinG(group_owner)}\n[00FF00]- PLAYING [FFFFFF]: {mode or 'UNKNOWN'}\n- [FFFF00]For : {minutes} Minutes , {seconds} Seconds ! ")


    elif base == "INSQUAD":
        if squad_text:
            parts.append(f"[FFFF00]INSQUAD ([FFFFFF]{squad_text}) \n- SQUAD OWNER : {xMsGFixinG(group_owner)}\n- [00FF00]SELECTED [FFFFFF]: {mode or 'UNKNOWN'}")
        else:
            parts.append(f"[FFFF00]INSQUAD \n- SQUAD OWNER : {xMsGFixinG(group_owner)}\n- SELECTED [FFFFFF]: {mode or 'UNKNOWN'}")


    elif base == "INGAME" or playing:
        parts.append(f"[00FF00] PLAYING [FFFFFF] : {mode or 'UNKNOWN'}\n- [FFFF00]For : {minutes} Minutes , {seconds} Seconds ! ")
    elif base == "IN ROOM":
        return {"IN_ROOM":True,"room_uid":room_uid}
    else:
        parts.append(base)

    return " ".join(parts)

async def DeCode_PackEt(input_text):
    try:
        parsed_results = Parser().parse(input_text)
        parsed_results_objects = parsed_results
        parsed_results_dict = await Fix_Packet(parsed_results_objects)
        json_data = json.dumps(parsed_results_dict)
        return json_data
    except Exception as e:
        print(f"error {e}")
        return None
                      
def xMsGFixinG(n):
    return '🗿'.join(str(n)[i:i + 3] for i in range(0 , len(str(n)) , 3))
    
async def Ua():
    versions = [
        '4.0.18P6', '4.0.19P7', '4.0.20P1', '4.1.0P3', '4.1.5P2', '4.2.1P8',
        '4.2.3P1', '5.0.1B2', '5.0.2P4', '5.1.0P1', '5.2.0B1', '5.2.5P3',
        '5.3.0B1', '5.3.2P2', '5.4.0P1', '5.4.3B2', '5.5.0P1', '5.5.2P3'
    ]
    models = [
        'SM-A125F', 'SM-A225F', 'SM-A325M', 'SM-A515F', 'SM-A725F', 'SM-M215F', 'SM-M325FV',
        'Redmi 9A', 'Redmi 9C', 'POCO M3', 'POCO M4 Pro', 'RMX2185', 'RMX3085',
        'moto g(9) play', 'CPH2239', 'V2027', 'OnePlus Nord', 'ASUS_Z01QD',
    ]
    android_versions = ['9', '10', '11', '12', '13', '14']
    languages = ['en-US', 'es-MX', 'pt-BR', 'id-ID', 'ru-RU', 'hi-IN']
    countries = ['USA', 'MEX', 'BRA', 'IDN', 'RUS', 'IND']
    version = random.choice(versions)
    model = random.choice(models)
    android = random.choice(android_versions)
    lang = random.choice(languages)
    country = random.choice(countries)
    return f"GarenaMSDK/{version}({model};Android {android};{lang};{country};)"


def Uaa():
    versions = [
        '4.0.18P6', '4.0.19P7', '4.0.20P1', '4.1.0P3', '4.1.5P2', '4.2.1P8',
        '4.2.3P1', '5.0.1B2', '5.0.2P4', '5.1.0P1', '5.2.0B1', '5.2.5P3',
        '5.3.0B1', '5.3.2P2', '5.4.0P1', '5.4.3B2', '5.5.0P1', '5.5.2P3'
    ]
    models = [
        'SM-A125F', 'SM-A225F', 'SM-A325M', 'SM-A515F', 'SM-A725F', 'SM-M215F', 'SM-M325FV',
        'Redmi 9A', 'Redmi 9C', 'POCO M3', 'POCO M4 Pro', 'RMX2185', 'RMX3085',
        'moto g(9) play', 'CPH2239', 'V2027', 'OnePlus Nord', 'ASUS_Z01QD',
    ]
    android_versions = ['9', '10', '11', '12', '13', '14']
    languages = ['en-US', 'es-MX', 'pt-BR', 'id-ID', 'ru-RU', 'hi-IN']
    countries = ['USA', 'MEX', 'BRA', 'IDN', 'RUS', 'IND']
    version = random.choice(versions)
    model = random.choice(models)
    android = random.choice(android_versions)
    lang = random.choice(languages)
    country = random.choice(countries)
    return f"GarenaMSDK/{version}({model};Android {android};{lang};{country};)"


    
def get_random_color():
    colors = [
        "[FF0000]", "[00FF00]", "[0000FF]", "[FFFF00]", "[FF00FF]", "[00FFFF]", "[FFFFFF]", "[FFA500]",
        "[A52A2A]", "[800080]", "[000000]", "[808080]", "[C0C0C0]", "[FFC0CB]", "[FFD700]", "[ADD8E6]",
        "[90EE90]", "[D2691E]", "[DC143C]", "[00CED1]", "[9400D3]", "[F08080]", "[20B2AA]", "[FF1493]",
        "[7CFC00]", "[B22222]", "[FF4500]", "[DAA520]", "[00BFFF]", "[00FF7F]", "[4682B4]", "[6495ED]",
        "[5F9EA0]", "[DDA0DD]", "[E6E6FA]", "[B0C4DE]", "[556B2F]", "[8FBC8F]", "[2E8B57]", "[3CB371]",
        "[6B8E23]", "[808000]", "[B8860B]", "[CD5C5C]", "[8B0000]", "[FF6347]", "[FF8C00]", "[BDB76B]",
        "[9932CC]", "[8A2BE2]", "[4B0082]", "[6A5ACD]", "[7B68EE]", "[4169E1]", "[1E90FF]", "[191970]",
        "[00008B]", "[000080]", "[008080]", "[008B8B]", "[B0E0E6]", "[AFEEEE]", "[E0FFFF]", "[F5F5DC]",
        "[FAEBD7]"
    ]
    return random.choice(colors)
    



def get_random_title():
    title_ids = [
        905190079, 904090026, 904090027, 904290048, 904590058, 904590059,
        904790062, 904890068, 904990069, 904990070, 904990071,
        904990072, 904090023, 905090075
    ]
    return random.choice(title_ids)
        
async def ArA_CoLor():
    Tp = ["32CD32" , "00BFFF" , "00FA9A" , "90EE90" , "FF4500" , "FF6347" , "FF69B4" , "FF8C00" , "FF6347" , "FFD700" , "FFDAB9" , "F0F0F0" , "F0E68C" , "D3D3D3" , "A9A9A9" , "D2691E" , "CD853F" , "BC8F8F" , "6A5ACD" , "483D8B" , "4682B4", "9370DB" , "C71585" , "FF8C00" , "FFA07A"]
    return random.choice(Tp)
    
async def xBunnEr():
    bN = [902000306 , 902000305 , 902000003 , 902000016 , 902000017 , 902000019 , 902031010 , 902043025 , 902043024 , 902000020 , 902000021 , 902000023 , 902000070 , 902000087 , 902000108 , 902000011 , 902049020 , 902049018 , 902049017 , 902049016 , 902049015 , 902049003 , 902033016 , 902033017 , 902033018 , 902048018 , 902000306 , 902000305 , 902000079]
    return random.choice(bN)



async def Send_GhosTs(Uid , Nm , sQ , K , V):
    fields =  {1: 61 , 2: {1: int(Uid) , 2: {1: int(Uid) , 2: 1159, 3: f'{Nm}', 5: 12, 6: 9999999, 7: 1, 8: {2: 1, 3: 1}, 9: 3}, 3: sQ}}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)

async def Join_Sq(T , UiD, sQ , K , I):
    fields = {
  1: 4,
  2: {
    1: UiD,
    4: "\u0001\u0003\u0004\u0007\t\n\u000b\u0012\u000f\u0019\u001a ",
    6: 1,
    8: 1,
    9: {
      4: "y[WW",
      6: 11,
      7: "\u001d`at\u0005d\u001d\u0016",
      8: "1.118.1",
      9: 3,
      10: 2
    },
    13: T,
    15: sQ,
    16: "OR",
    20: {
      1: 21
    }
  }
}

    return await GeneRaTePk((await Create_Proto(fields)).hex(), '0515', K , I)
    
async def xSEndMsg(Msg, Tp, Tp2, id, K, V):
    fields = {
        1: id,
        2: Tp2,
        3: Tp,
        4: Msg,
        5: 1735129800,
        7: 2,
        9: {
            1: "DEV",
            2: int(await xBunnEr()),
            3: 901048018,
            4: 330,
            5: 909034009,
            8: "DEV",
            10: 1,
            11: random.choice([1,10,20,30,40,50,60,70,80,90,100]),
            12: 0,
            13: {
                1: 2,
                2: 1,
            },
            14: {
                1: 11017917409,
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            }
        },
        10: "en",
        13: {
            1: "https://graph.facebook.com/v9.0/253082355523299/picture?width=160&height=160",
            2: 1,
            3: 1
        },
        14: {
            1: {
               1: random.choice([1, 4]),
               2: 1,
               3: random.randint(1, 180),
               4: 1,
               5: int(time.time()),  
               6: "IND"
            }
        }
    }
    Pk = (await Create_Proto(fields)).hex()
    Pk = "080112" + await Enc_Uid(len(Pk) // 2, Tp='Uid') + Pk
    return await GeneRaTePk(Pk, '1201', K, V)
    
def xSEndMsgsQ(msg, idT,  K, V):
    fields = {
    1: 1,
    2: {
        1: 12404281032,
        2: idT,
        4: msg,
        7: 2,
        10: "fr",
        9: {
            1: "BNGX",
            2: xBunnEr(),
            4: 330,
            5: 827001005,
            8: "BNGX",
            10: 1,
            11: 1,
            12: {
                1: 2
            },
            14: {
                1: 1158053040,
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            }
        },
        13: {
            1: 2,
            2: 1
        },
        14:{}
    }
}
    
    return GeneRaTePk(str(CrEaTe_ProTo(fields).hex()) , '1215' , K , V)
import datetime


async def xSEndtitle(Tp, Tp2, id, K, V):
    fields = {
        1: id,
        2: Tp2,
        3: Tp,       
        5: int(datetime.datetime.now().timestamp()),
        8: json.dumps({"TitleID":904990072,"type":"Title"}),
        9: {
            1: "DEV",
            2: int(await xBunnEr()),
            3: 901048018,
            4: 330,
            5: 909034009,
            8: "DEV",
            10: 1,
            11: random.choice([1,10,20,30,40,50,60,70,80,90,100]),
            12: 0,
            13: {
                1: 2,
                2: 1,
            },
            14: {
                1: 11017917409,
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            }
        },
        10: "en",
        13: {
            1: "https://graph.facebook.com/v9.0/253082355523299/picture?width=160&height=160",
            2: 1,
            3: 1
        },
        14: {
            1: {
               1: random.choice([1, 4]),
               2: 1,
               3: random.randint(1, 180),
               4: 1,
               5: int(time.time()),  
               6: "IND"
            }
        }
    }
    Pk = (await Create_Proto(fields)).hex()
    Pk = "080112" + await Enc_Uid(len(Pk) // 2, Tp='Uid') + Pk
    return await GeneRaTePk(Pk, '1201', K, V)
    
async def xSEndtitleQ( id, K, V):
    fields = {
        1: id,
        2: id,   
        5: int(datetime.datetime.now().timestamp()),
        8: json.dumps({"TitleID": get_random_title(), "type": "Title"}),
        9: {
            1: "DEV",
            2: int(await xBunnEr()),
            4: 330,
            5: 827001005,
            8: "DEV",
            10: 1,
            11: random.choice([1,10,20,30,40,50,60,70,80,90,100]),
            13: {1: 2},
            14: {
                1: 1158053040,
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            }
        },
        10: "en",
        13: {2: 2, 3: 1},
        14: {
            1: {
               1: random.choice([1, 4]),
               2: 1,
               3: random.randint(1, 180),
               4: 1,
               5: int(time.time()),  
               6: "IND"
            }
        }
    }

    proto_hex = (await Create_Proto(fields)).hex()
    Pk = "080112" + await Enc_Uid(len(proto_hex) // 2, Tp='Uid') + proto_hex
    return await GeneRaTePk(Pk, '1201', K, V)
    
async def AuthClan(CLan_Uid, AuTh, K, V):
    fields = {1: 3, 2: {1: int(CLan_Uid), 2: 1, 4: str(AuTh)}}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '1215' , K , V)
async def AutH_GlobAl(K, V):
    fields = {
    1: 3,
    2: {
        2: 5,
        3: "fr"
    }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '1215' , K , V)

async def XRLeaveRoom(uid,key,iv):
    fields = {
        1: 6,
        2: {
            1: uid
        }
        }
    return await GeneRaTePk((await Create_Proto(fields)).hex(), '0E15', key , iv)

async def XRJoinRomm(uid,password,key,iv):
    fields = {
  1: 3,
  2: {
    1: int(uid),
    2: str(password),
    8: {
      1: "IDC3",
      2: 149,
      3: "IND"
    },
    9: "\u0001\u0003\u0004\u0007\t\n\u000b\u0012\u000e\u0016\u0019 \u001d",
    10: 1,
    12: {},
    13: 1,
    14: 1,
    16: "en",
    22: {
      1: 21
    }
  }
}
    print(fields)
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0E15' , key , iv)

async def new_lag(K,I):
    fields = {
        1: 15,
        2: {
            1: 11963383719,
            2: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , I)


async def DEVRefuse(owner, uid, K, V):
    gay_text = f"""
[0000FF]███████╗██╗   ██╗ ██████╗██╗  ██╗
██╔════╝██║   ██║██╔════╝██║ ██╔╝
[87CEEB]█████╗  ██║   ██║██║     █████╔╝ 
[00FF00]██╔══╝  ██║   ██║██║     ██╔═██╗ 
██║     ╚██████╔╝╚██████╗██║  ██╗
[82C8E5]██████████████████████████████

[B][C][00FF00]D E VㅤD E VㅤX T
[ff0000]━━━━━━━━━━━━━━━━━━━━━
[B][C][FF9900]D O N EㅤH A C K I N G
[B][C][E75480]Y O U RㅤA C C O U N T
[81DACA]━━━━━━━━━━━━━━━━━━━━━
[B][C][FF0000]F U C KㅤY O U
[CCFFCC]━━━━━━━━━━━━━━━━━━━━━
[B][C][81DACA]P O W E R E DㅤB YㅤD E VㅤX T
[FFFF00]━━━━━━━━━━━━━━━━━━━━━
[B][C][00FF00]F O L L O WㅤM EㅤI NㅤI N S T A G R A Mㅤ[FFFFFF]@DEVXTLIVE
[00008B]━━━━━━━━━━━━━━━━━━━━━
[B][C][81DACA]I FㅤY O UㅤN O TㅤF A L L O WㅤM EㅤIㅤW I L LㅤB A NㅤY O U RㅤA C C O U N T
    """

    fields = {
        1: 5,
        2: {
            1: int(owner),
            2: 1,
            3: int(uid),
            4: gay_text
        },
    }

    proto_data = await Create_Proto(fields)
    return await GeneRaTePk(proto_data.hex(), '0515', K, V)


async def DEV_SendInv(uid,K,V):
    fields = fields = {1: 33, 2: {1: int(uid), 2: "IND", 3: 1, 4: 1, 6: "DEV!!", 7: 330, 8: 1000, 9: 100, 10: "IND", 12: 1, 13: int(uid), 16: 1, 17: {2: 159, 4: "y[WW", 6: 11, 8: "1.118.1", 9: 3, 10: 1}, 18: 306, 19: 18, 24: await xBunnEr(), 26: {}, 27: {1: 11, 2: 12999994075, 3: 9999}, 28: {}, 31: {1: 1, 2: 32768}, 32: 32768, 34: {1: 12947882969, 2: 8, 3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"}}}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)



async def trydecByDEV(pack):

    try:
        r = pack['5']['data']['3']['data']['31']['data']
    except KeyError:
        r = pack['5']['data']['31']['data']
    except:
        return None
    return r

async def DEVAccepted(uid,code,K,V):
    fields = {
        1: 4,
        2: {
            1: uid,
            3: uid,
            8: 1,
            9: {
                2: 161,
                4: "DEV",
                6: 11,
                8: "1.118.1",
                9: 3,
                10: 1
            },
            10: str(code),
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)

async def LagSquad(K,V):
    fields = {
    1: 15,
    2: {
        1: 11963383719,
        2: 1
    }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)

async def GeT_Status(PLayer_Uid , K , V):
    PLayer_Uid = await Enc_Uid(PLayer_Uid , Tp = 'Uid')
    if len(PLayer_Uid) == 8: Pk = f'080112080a04{PLayer_Uid}1005'
    elif len(PLayer_Uid) == 10: Pk = f"080112090a05{PLayer_Uid}1005"
    return await GeneRaTePk(Pk , '0f15' , K , V)
           
async def SPam_Room(Uid , Rm , Nm , K , V):
    fields = {1: 78, 2: {1: int(Rm), 2: f"[{ArA_CoLor()}]{Nm}", 3: {2: 1, 3: 1}, 4: 330, 5: 1, 6: 201, 10: xBunnEr(), 11: int(Uid), 12: 1}}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0e15' , K , V)
async def GenJoinSquadsPacket(code,  K , V):
    fields = {}
    fields[1] = 4
    fields[2] = {}
    fields[2][4] = bytes.fromhex("01090a0b121920")
    fields[2][5] = str(code)
    fields[2][6] = 6
    fields[2][8] = 1
    fields[2][9] = {}
    fields[2][9][2] = 800
    fields[2][9][6] = 11
    fields[2][9][8] = "1.118.1"
    fields[2][9][9] = 5
    fields[2][9][10] = 1
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)   
async def GenJoinGlobaL(owner , code , K, V):
    fields = {
    1: 4,
    2: {
        1: owner,
        6: 1,
        8: 1,
        13: "en",
        15: code,
        16: "OR",
    }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)

async def FS(K,V):
    fields = {
            1: 9,
            2: {
                1: 11963383719
            }
            }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)





async def Emote_k(TarGeT , idT, K, V,region):
    fields = {
        1: 21,
        2: {
            1: 804266360,
            2: 909000001,
            5: {
                1: TarGeT,
                3: idT,
            }
        }
    }
    if region.lower() == "ind":
        packet = '0514'
    elif region.lower() == "bd":
        packet = "0519"
    else:
        packet = "0515"
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex() , packet , K , V)


async def GeTSQDaTa(D):
    uid = D['5']['data']['1']['data']
    chat_code = D["5"]["data"]["17"]["data"]
    squad_code = D["5"]["data"]["31"]["data"]


    return uid, chat_code , squad_code


async def AutH_Chat(T , uid, code , K, V):
    fields = {
  1: T,
  2: {
    1: uid,
    3: "en",
    4: str(code)
  }
}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '1215' , K , V)
async def Msg_Sq(msg, owner, bot, K, V):
    fields = {
    1: 1,
    2: 2,
    2: {
        1: bot,
        2: owner,
        4: msg,
        5: 1757799182,
        7: 2,
        9: {
            1: "DEV",
            2: await xBunnEr(),
            3: 909000024,
            4: 330,
            5: 909000024,
            7: 2,
            10: 1,
            11: 1,
            12: 0,
            13: {1: 2},
            14: {
                1: bot,
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            }
        },
        10: "ar",
        13: {3: 1},
        14: ""
    }
}
    proto_bytes = await Create_Proto(fields)
    return await GeneRaTePk(proto_bytes.hex(), '1215', K, V)


async def ghost_pakcet(player_id , secret_code ,K , V):
    fields = {
        1: 61,
        2: {
            1: int(player_id),  
            2: {
                1: int(player_id),  
                2: int(time.time()),  
                3: "DEV",
                5: 12,  
                6: 9999999,
                7: 1,
                8: {
                    2: 1,
                    3: 1,
                },
                9: 3,
            },
            3: secret_code,},}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)
async def GeneRaTePk(Pk , N , K , V):
    PkEnc = await Enc_Packet(Pk , K , V)
    _ = await Decode_Hex(int(len(PkEnc) // 2))
    if len(_) == 2: HeadEr = N + "000000"
    elif len(_) == 3: HeadEr = N + "00000"
    elif len(_) == 4: HeadEr = N + "0000"
    elif len(_) == 5: HeadEr = N + "000"
    else: print('ErroR => GeneRatinG ThE PacKeT !! ')
    return bytes.fromhex(HeadEr + _ + PkEnc)
async def OpEnSq(K , V):
    fields = {1: 1, 2: {2: "\u0001", 3: 1, 4: 1, 5: "en", 9: 1, 11: 1, 13: 1, 14: {2: 5756, 6: 11, 8: "1.118.1", 9: 2, 10: 4}}}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 

async def cHSq(Nu , Uid , K , V):
    fields = {1: 17, 2: {1: int(Uid), 2: 1, 3: int(Nu - 1), 4: 62, 5: "\u001a", 8: 5, 13: 329}}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 

async def SEnd_InV(Nu , Uid , K , V):
    fields = {1: 2 , 2: {1: int(Uid) , 2: "IND" , 4: int(Nu)}}
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 
 
async def modify_team_player(team, K, V):
    fields = {
        1: 17,  # key1
        2: {
            1: 11963383719,               # UID
            2: 1,                        # key2
            3: int(team),                # team number
            4: 62,                       # key4
            5: base64.b64decode("Gg=="), # byte data
            8: 5,                        # key8
            13: 227                      # key13
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 
       
async def invite_target(uid, K, V):
    fields = {
        1: 2,  # num
        2: {   # Func
            1: int(uid),   # uid
            2: "IND",      # region
            3: 1           # number
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 
       
async def create_group(K, V):
    packet = "080112bc04120101180120032a02656e420d0a044944433110661a03494e444801520601090a121920580168017288040a403038303230303032433733464233454430323031303030303030303030303030303030303030303030303030303030303137424236333544303930303030303010151a8f0375505d5413070448565556000b5009070405500303560a08030354550007550f02570d03550906521702064e76544145491e0418021e11020b4d1a42667e58544776725757486575441f5a584a065b46426a5a65650e14034f7e5254047e005a7b7c555c0d5562637975670a7f765b0102537906091702044e72747947457d0d6267456859587b596073435b7205046048447d080b170c4f584a6b007e4709740661625c545b0e7458405f5e4e427f486652420c13070c484b597a717a5a5065785d4343535d7c7a6450675a787e05736418010c12034a475b71717a566360437170675a6b1c740748796065425e017e4f5d0e1a034d09660358571843475c774b5f524d47670459005a4870780e795e7a0a110a457e5e5a00776157597069094266014f716d7246754a60506b747404091005024f7e765774035967464d687c724703075d4e76616f7a184a7f057a6f0917064b5f797d05434250031b0555717b0d00611f59027e60077b4a0a5c7c0d1500480143420b5a65746803636e41556a511269087e4f5f7f675c0440600c22047c5c5754300b3a1a16024a424202050607021316677178637469785d51745a565a5a4208312e3130392e3136480650029801c902aa01024f52"
    return await GeneRaTePk(packet, '0515', K, V)
    
async def left_group(K, V):
    packet = "0807120608da89d98d27"    
    return await GeneRaTePk(packet, '0515', K, V)
                                  
async def ExiT(idT , K , V):
    fields = {
        1: 7,
        2: {
            1: idT,
        }
        }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 

async def request_craft_badge(idplayer, K, V):    
    fields = {
        1: 33,
        2: {
            1: int(idplayer),
            2: "IND",
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] @DEV",
            7: 330,
            8: 1000,
            10: "IND",
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(idplayer),         
            14: {
            1: 2203434355,
            2: 8,
            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            24: await xBunnEr(),
            26: "",
            27: {
            1: 11,
            2: 12999994075,
            3: 9999
            },
            28: "",
            31: {
            1: 1,
            2: 1048576
            },
            32: 1048576,
            34: {
            1: int(idplayer),
            2: 8,
            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)
    
async def request_pro_badge(idplayer, K, V):    
    fields = {
        1: 33,
        2: {
            1: int(idplayer),
            2: "IND",
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] @DEV",
            7: 330,
            8: 1000,
            10: "IND",
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(idplayer),
            14: {
            1: 2203434355,
            2: 8,
            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            24: await xBunnEr(),
            26: "",
            27: {
            1: 11,
            2: 12999994075,
            3: 9999
            },
            28: "",
            31: {
            1: 1,
            2: 262144
            },
            32: 262144,
            34: {
            1: int(idplayer),
            2: 8,
            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)
    
async def request_oldV_badge(idplayer, K, V):    
    fields = {
        1: 33,
        2: {
            1: int(idplayer),
            2: "IND",
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] @DEV",
            7: 330,
            8: 1000,
            10: "IND",
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(idplayer),
            14: {
            1: 2203434355,
            2: 8,
            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            24: await xBunnEr(),
            26: "",
            27: {
            1: 11,
            2: 12999994075,
            3: 9999
            },
            28: "",
            31: {
            1: 1,
            2: 64
            },
            32: 64,
            34: {
            1: int(idplayer),
            2: 8,
            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)
        
async def request_newV_badge(idplayer, K, V):
    
    fields = {
        1: 33,
        2: {
            1: int(idplayer),
            2: "IND",
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] @DEV",
            7: 330,
            8: 1000,
            10: "IND",
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(idplayer),
            14: {
            1: 2203434355,
            2: 8,
            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            24: await xBunnEr(),
            26: "",
            27: {
            1: 11,
            2: 12999994075,
            3: 9999
            },
            28: "",
            31: {
            1: 1,
            2: 32768
            },
            32: 32768,
            34: {
            1: int(idplayer),
            2: 8,
            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)
        
async def request_normalV_badge(idplayer, K, V):
    
    fields = {
        1: 33,
        2: {
            1: int(idplayer),
            2: "IND",
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] @DEV",
            7: 330,
            8: 1000,
            10: "IND",
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(idplayer),
            14: {
            1: 2203434355,
            2: 8,
            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            24: await xBunnEr(),
            26: "",
            27: {
            1: 11,
            2: 12999994075,
            3: 9999
            },
            28: "",
            31: {
            1: 1,
            2: 8192
            },
            32: 8192,
            34: {
            1: int(idplayer),
            2: 8,
            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)    
    
async def request_MediumV_badge(idplayer, K, V):
    
    fields = {
        1: 33,
        2: {
            1: int(idplayer),
            2: "IND",
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] @DEV",
            7: 330,
            8: 1000,
            10: "IND",
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(idplayer),
            14: {
            1: 2203434355,
            2: 8,
            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            24: await xBunnEr(),
            26: "",
            27: {
            1: 11,
            2: 12999994075,
            3: 9999
            },
            28: "",
            31: {
            1: 1,
            2: 16384
            },
            32: 16384,
            34: {
            1: int(idplayer),
            2: 8,
            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)    

async def request_mod_badge(idplayer, K, V):
    
    fields = {
        1: 33,
        2: {
            1: int(idplayer),
            2: "IND",
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] @DEV",
            7: 330,
            8: 1000,
            10: "IND",
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
            97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(idplayer),
            14: {
            1: 2203434355,
            2: 8,
            3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            24: await xBunnEr(),
            26: "",
            27: {
            1: 11,
            2: 12999994075,
            3: 9999
            },
            28: "",
            31: {
            1: 1,
            2: 4096
            },
            32: 4096,
            34: {
            1: int(idplayer),
            2: 8,
            3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)    
       
async def changes(num, K, V):
    fields = {
        1: 17,
        2: {
            1: 16519667180,
            2: 1,
            3: int(num),
            4: 60,
            5: "\u001a",
            8: 5,
            13: 329
        }
    }
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)
    
    
async def leave_s(K, V):
    # ... same code ...
     fields = {
        1: 7,
        2: {
            1: 16519667180
        }
     }
     return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)
     
async def start_autooo(K, V):
     fields = {
        1: 9,
        2: {
            1: 16519667180
        }
     }     
     return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)      
     
async def invite_skwad(idplayer, K, V):
     fields = {
        1: 2,
        2: {
            1: int(idplayer),
            10: int(await xBunnEr()),
            2: "IND",
            4: 1
        }
     }     
     return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 
 
async def skwad_maker(K, V):
    # ... same code ...
     fields = {
        1: 1,
        2: {
            2: "\u0001",
            3: 1,
            4: 1,
            5: "en",
            9: 1,
            11: 1,
            13: 1,
            14: {
            2: 5756,
            6: 11,
            8: "1.114.1",
            9: 3,
            10: 2
            },
        }
     }
     return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)        
     
async def banecipher(client_id, K, V):
     banner_text = f"""


{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
                """        
        
     fields = {
        1: 5,
        2: {
            1: int(client_id),
            2: 1,
            3: int(client_id),
            4: banner_text
        }
     }
     return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V) 
        
async def banecipher1(client_id, K, V):
     gay_text = f"""


{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
{get_random_color()} XR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPERXR SUPER
             """        
     fields = {
        1: int(client_id),
        2: 5,
        4: 50,
        5: {
            1: int(client_id),
            2: gay_text,
            3: 1
        }
     }
     return await GeneRaTePk((await Create_Proto(fields)).hex() , '0515' , K , V)      
     
async def spam_room(idroom, idplayer, K, V):
    fields = {
        1: 78,
        2: {
            1: int(idroom),
            2: f"{get_random_color()}XR",
            4: 330,
            5: 6000,
            6: 201,
            10: int(get_random_avatar()),
            11: int(idplayer),
            12: 1
        }
    }     
    return await GeneRaTePk((await Create_Proto(fields)).hex() , '0e15' , K , V)

async def SendInFoPaCKeT(uid , key , iv):
    uid = await EnC_UiDInFo(int(uid))
    print(uid)
    hex = f"080112090A05{uid}1005"
    return await GeneRaTePk((hex) , '0F15' , key , iv)

def get_player_status(packet):
    parsed_data = json.loads(packet)
    print(parsed_data)
    if "5" not in parsed_data or "data" not in parsed_data["5"]:
        return "OFFLINE"

    json_data = parsed_data["5"]["data"]

    if "1" not in json_data or "data" not in json_data["1"]:
        return "OFFLINE"

    data = json_data["1"]["data"]

    if "3" not in data or "data" not in data["3"]:
        return "OFFLINE"

    status = data["3"]["data"]
    
    if status == 4:
        room_uid = data['15']['data']
        return {"IN_ROOM":True,"room_uid":room_uid}
    
    return "OFFLINE"

async def SPam_Room(Uid, Rm, Nm, K, V):
    badge_id = await xBadgE_Room()
    
    fields = {
        1: 78,
        2: {
            1: int(Rm),
            2: f"[{await ArA_CoLor()}]{Nm}",
            3: {
                2: 1,
                3: 1
            },
            4: 330,
            5: 1,
            6: 201,
            10: int(await xBunnEr()), 
            11: int(Uid),
            12: 1,
            15: {
                1: 1,
                2: badge_id
            },
            16: badge_id,
            18: {
                1: 11481904755,
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            }
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0e15', K, V)

async def xBadgE_Room():
    bd = [1048576, 32768, 2048, 64, 4096, 16384, 8192, 262144]
    return random.choice(bd)

async def xBunnEr():
    bN = [902000306 , 902000305 , 902000003 , 902000016 , 902000017 , 902000019 , 902031010 , 902043025 , 902043024 , 902000020 , 902000021 , 902000023 , 902000070 , 902000087 , 902000108 , 902000011 , 902049020 , 902049018 , 902049017 , 902049016 , 902049015 , 902049003 , 902033016 , 902033017 , 902033018 , 902048018 , 902000306 , 902000305 , 902000079]
    return random.choice(bN)

async def ArA_CoLor():
    Tp = ["32CD32" , "00BFFF" , "00FA9A" , "90EE90" , "FF4500" , "FF6347" , "FF69B4" , "FF8C00" , "FF6347" , "FFD700" , "FFDAB9" , "F0F0F0" , "F0E68C" , "D3D3D3" , "A9A9A9" , "D2691E" , "CD853F" , "BC8F8F" , "6A5ACD" , "483D8B" , "4682B4", "9370DB" , "C71585" , "FF8C00" , "FFA07A"]
    return random.choice(Tp)


