import os
import json
import logging
import asyncio
import random
import string
import qrcode
from io import BytesIO
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple
import aiohttp
import html 
import secrets
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton, User, InputFile
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
    ConversationHandler,
)
from telegram.error import TelegramError
from telegram.constants import ParseMode

# ==================== CONFIGURATION ====================
BOT_TOKEN = "8717911881:AAFamWsJ7L1begdbUEYH7NDDdVHVOws1sSM"
BOT_USERNAME = "NxNCoinBot"
OWNER_ID = 5651796937

# Admins list
ADMINS = [5651796937, 5721250406, 8290865241]

# Force Join Channels
FORCE_CHANNELS = [
    "@Nexo_Autolikes",
    "@NoobVellenLikes",
    "@Nexo_Stores",
    "@NoobVellen_Autolike",
    "@NoobVellen_Autolikes",
    "@FREEFlRECODE"
]

# Group IDs for broadcasts (only like success notifications)
LIKE_SUCCESS_GROUPS = [
    -1002860814694,
    -1003014205347,
    -1003995166498
]

# UPI IDs - EXACT mapping
UPI_IDS = {
    "NoobVellen": "crazylegend5116-2@okicici",
    "Nexo": "jiy040572-1@okaxis"
}

# USDT Details
USDT = {
    "BINANCE_ID": "970121746",
    "WALLET": "YOUR_USDT_WALLET_ADDRESS",
    "NETWORK": "TRC20"
}

# API Configuration
API_URL = "https://nxn-like-api.vercel.app/api/{region}/{uid}"
API_KEY = "nxnbot"

# Global settings
REFERRAL_REWARD = 60
MIN_COINS_REQUIRED = 250
COST_PER_LIKE = 1.7
MAX_COINS = 10000000

# Regions list
REGIONS = ["IND", "BR", "US", "UK"]

# ==================== VPLINK API CONFIGURATION ====================
VPLINK_API_KEY_NOOBVELLEN = "e860e64c428d5e0a6754cf5f222f26d644185dc9"
VPLINK_API_KEY_NEXO = "fff213a0802910aa7c3ce694a27f1b8c8f7f97eb"
VPLINK_BASE_URL = "https://vplink.in/api"

# Verification settings
VERIFICATION_REWARD = 80
MAX_DAILY_VERIFICATIONS = 2
VERIFICATION_TIMEOUT_SECONDS = 250
VERIFICATION_LINK_VALID_HOURS = 6  

# ==================== LIKE TEMP BAN (2 DAYS) ====================
LIKE_TEMP_BAN_HOURS = 48  # 2 days

# ==================== JSON DATABASES ====================
DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

USERS_FILE = os.path.join(DATA_DIR, "users.json")
CODES_FILE = os.path.join(DATA_DIR, "codes.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")
CONFIG_FILE = os.path.join(DATA_DIR, "config.json")
SETTINGS_FILE = os.path.join(DATA_DIR, "bot_settings.json")
LIKE_HISTORY_FILE = os.path.join(DATA_DIR, "like_history.json")
VERIFIED_USERS_FILE = os.path.join(DATA_DIR, "verified_users.json")

# ==================== LOGGING ====================
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ==================== KEYBOARDS ====================
def get_main_keyboard():
    return ReplyKeyboardMarkup(
        [
            ["💰 My Balance", "🎟️ Redeem Code"],
            ["👥 Earn Coins", "👥 My Referrals"],
            ["❤️ Get Likes", "✅ Daily Verification"],
            ["📊 My Usage", "🛒 Buy Coins"],
            ["🏆 Leaderboard", "❓ Help"],
            ["👑 Admin Panel"]
        ],
        resize_keyboard=True,
    )

def get_admin_keyboard():
    return ReplyKeyboardMarkup(
        [
            ["👥 Admin List", "📊 Statistics"],
            ["📢 Broadcast", "🎫 Generate Code"],
            ["➕ Add Coins", "➖ Remove Coins"],
            ["🚫 Ban User", "✅ Unban User"],
            ["📝 Add Admin", "❌ Remove Admin"],
            ["📋 Pending Orders", "🌍 Manage Regions"],
            ["⚙️ Bot Settings", "🔙 Back to Main Menu"]
        ],
        resize_keyboard=True,
    )

def get_cancel_keyboard():
    return ReplyKeyboardMarkup(
        [["❌ Cancel"]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )

def get_package_keyboard():
    return ReplyKeyboardMarkup(
        [
            ["2200 Coins - ₹160"],
            ["5500 Coins - ₹320"],
            ["11000 Coins - ₹640"],
            ["❌ Cancel"]
        ],
        resize_keyboard=True,
    )

def get_payment_keyboard():
    return ReplyKeyboardMarkup(
        [
            ["🇮🇳 UPI Payment"],
            ["💰 USDT"],
            ["❌ Cancel"]
        ],
        resize_keyboard=True,
    )

def get_merchant_keyboard():
    return ReplyKeyboardMarkup(
        [
            ["🏦 NoobVellen"],
            ["🏦 Nexo"],
            ["❌ Cancel"]
        ],
        resize_keyboard=True,
    )

def get_redeem_menu():
    return ReplyKeyboardMarkup(
        [
            ["🎟️ Redeem Promo Code"],
            ["➕ Create Promo Code"],
            ["📢 Redeem Code Channel"],
            ["🔙 Back to Main Menu"]
        ],
        resize_keyboard=True
    )

def get_leaderboard_menu():
    return ReplyKeyboardMarkup(
        [
            ["💰 Top Coins"],
            ["👥 Top Referrals"],
            ["🔙 Back to Main Menu"]
        ],
        resize_keyboard=True
    )

# ==================== JSON FUNCTIONS ====================
def load_users():
    try:
        with open(USERS_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return {}
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_users(data):
    with open(USERS_FILE, "w") as f:
        json.dump(data, f, indent=4)

def load_codes():
    try:
        with open(CODES_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return {}
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_codes(data):
    with open(CODES_FILE, "w") as f:
        json.dump(data, f, indent=4)

def load_orders():
    try:
        with open(ORDERS_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, list):
                return {"orders": data}
            if isinstance(data, dict) and "orders" in data:
                return data
            if isinstance(data, dict):
                data["orders"] = data.get("orders", [])
                return data
            return {"orders": []}
    except (FileNotFoundError, json.JSONDecodeError):
        return {"orders": []}

def save_orders(data):
    with open(ORDERS_FILE, "w") as f:
        json.dump(data, f, indent=4)

def load_like_history():
    try:
        with open(LIKE_HISTORY_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return {}
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_like_history(data):
    with open(LIKE_HISTORY_FILE, "w") as f:
        json.dump(data, f, indent=4)

def load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return {}
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=4)

def load_settings():
    try:
        with open(SETTINGS_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return {}
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
    
def save_settings(data):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(data, f, indent=4)

def get_like_settings():
    settings = load_settings()
    return {
        "enabled": settings.get("like_enabled", True)
    }

def update_like_settings(enabled=None):
    settings = load_settings()
    if enabled is not None:
        settings["like_enabled"] = enabled
    save_settings(settings)

def load_verified_users():
    try:
        with open(VERIFIED_USERS_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return {}
    except:
        return {}

def save_verified_users(data):
    with open(VERIFIED_USERS_FILE, "w") as f:
        json.dump(data, f, indent=4)

# ==================== USER DATA FUNCTIONS ====================
def get_balance(user):
    bal = user.get("balance", 0)
    if isinstance(bal, dict):
        return int(bal.get("total", 0))
    return int(bal)

def get_referral_balance(user):
    bal = user.get("balance", 0)
    if isinstance(bal, dict):
        return int(bal.get("referral", 0))
    return int(bal)

def get_purchased_balance(user):
    bal = user.get("balance", 0)
    if isinstance(bal, dict):
        return int(bal.get("purchased", 0))
    return int(bal)

def get_redeemed_balance(user):
    bal = user.get("balance", 0)
    if isinstance(bal, dict):
        return int(bal.get("redeemed", 0))
    return int(bal)

def get_clickable_name(user):
    name = user.first_name if hasattr(user, 'first_name') else str(user)
    user_id = user.id if hasattr(user, 'id') else user
    escaped_name = html.escape(str(name))
    return f'<a href="tg://user?id={user_id}">{escaped_name}</a>'

def format_separator():
    return "━━━━━━━━━━━━━━━━━"

def fix_user(user):
    if not isinstance(user, dict):
        user = {}
    
    if "balance" not in user:
        user["balance"] = {
            "total": 0,
            "purchased": 0,
            "referral": 0,
            "redeemed": 0,
            "verification": 0
        }
    
    if isinstance(user["balance"], dict):
        user["balance"].setdefault("total", 0)
        user["balance"].setdefault("purchased", 0)
        user["balance"].setdefault("referral", 0)
        user["balance"].setdefault("redeemed", 0)
        user["balance"].setdefault("verification", 0)

        user["balance"]["total"] = min(int(user["balance"]["total"]), MAX_COINS)
        user["balance"]["purchased"] = min(int(user["balance"]["purchased"]), MAX_COINS)
        user["balance"]["referral"] = min(int(user["balance"]["referral"]), MAX_COINS)
        user["balance"]["redeemed"] = min(int(user["balance"]["redeemed"]), MAX_COINS)
        user["balance"]["verification"] = min(int(user["balance"]["verification"]), MAX_COINS)
    else:
        old_balance = min(int(user["balance"]), MAX_COINS)
        user["balance"] = {
            "total": old_balance,
            "purchased": 0,
            "referral": 0,
            "redeemed": 0,
            "verification": 0
        }
    
    user.setdefault("referrals", [])
    user.setdefault("ref_limit", 25)
    user.setdefault("today_created_codes", 0)
    user.setdefault("create_code_limit", 5)
    user.setdefault("last_code_date", datetime.now().strftime("%Y-%m-%d"))
    user.setdefault("joined_via_ref", False)
    user.setdefault("referred_by", None)
    user.setdefault("ref_warning_sent", False)
    user.setdefault("name", "")
    user.setdefault("banned", False)
    user.setdefault("ban_reason", "")
    user.setdefault("joined_at", datetime.now().isoformat())
    user.setdefault("likes_used", 0)
    user.setdefault("total_likes", 0)
    user.setdefault("today_likes", 0)
    user.setdefault("today_refs", 0)
    user.setdefault("uids", [])
    user.setdefault("last_date", datetime.now().strftime("%Y-%m-%d"))
    user.setdefault("vip", False)
    user.setdefault("vip_expiry", None)
    user.setdefault("vip_given_by", None)
    user.setdefault("vip_warned", False)
    user.setdefault("vip_expired_notified", False)
    user.setdefault("today_verifications", 0)
    user.setdefault("last_verification_date", datetime.now().strftime("%Y-%m-%d"))
    user.setdefault("verification_history", [])
    user.setdefault("used_verification_sessions", [])
    user.setdefault("temp_ban", False)
    user.setdefault("temp_ban_expiry", None)
    user.setdefault("bypass_attempts", 0)
    user.setdefault("current_verification_provider", None)
    user.setdefault("verification_timestamp", None)
    user.setdefault("verification_link", None)
    user.setdefault("verification_session_id", None)
    
    # LIKE TEMP BAN FIELDS
    user.setdefault("like_temp_ban", False)
    user.setdefault("like_temp_ban_expiry", None)
    user.setdefault("like_bypass_attempts", 0)
    
    today = datetime.now().strftime("%Y-%m-%d")

    if user.get("last_date") != today:
        user["today_likes"] = 0
        user["today_refs"] = 0
        user["last_date"] = today

    if user.get("last_code_date") != today:
        user["today_created_codes"] = 0
        user["last_code_date"] = today
    
    if user.get("last_verification_date") != today:
        user["today_verifications"] = 0
        user["last_verification_date"] = today

    return user

async def get_user_data(user_id: int) -> Dict:
    users = load_users()
    if str(user_id) not in users:
        users[str(user_id)] = {
            "balance": {
                "total": 0,
                "purchased": 0,
                "referral": 0,
                "redeemed": 0,
                "verification": 0
            },
            "referrals": [],
            "ref_limit": 25,
            "banned": False,
            "ban_reason": "",
            "joined_at": datetime.now().isoformat(),
            "likes_used": 0,
            "total_likes": 0,
            "today_likes": 0,
            "today_refs": 0,
            "uids": [],
            "last_date": datetime.now().strftime("%Y-%m-%d"),
            "like_temp_ban": False,
            "like_temp_ban_expiry": None,
            "like_bypass_attempts": 0
        }
        save_users(users)
    
    user_data = users[str(user_id)]
    user_data = fix_user(user_data)
    return user_data

async def update_user_data(user_id: int, data: Dict):
    users = load_users()
    data = fix_user(data)
    users[str(user_id)] = data
    save_users(users)

async def add_coins(user_id: int, amount: int, source: str):
    user = await get_user_data(user_id)
    if isinstance(user["balance"], dict):
        new_total = int(user["balance"]["total"]) + amount
        user["balance"]["total"] = min(new_total, MAX_COINS)
        if source == "referral":
            new_ref = int(user["balance"]["referral"]) + amount
            user["balance"]["referral"] = min(new_ref, MAX_COINS)
        elif source == "purchased":
            new_purch = int(user["balance"]["purchased"]) + amount
            user["balance"]["purchased"] = min(new_purch, MAX_COINS)
        elif source == "redeemed":
            new_red = int(user["balance"]["redeemed"]) + amount
            user["balance"]["redeemed"] = min(new_red, MAX_COINS)
        elif source == "verification":
            new_verif = int(user["balance"].get("verification", 0)) + amount
            user["balance"]["verification"] = min(new_verif, MAX_COINS)
    else:
        new_balance = int(user["balance"]) + amount
        user["balance"] = min(new_balance, MAX_COINS)
    
    await update_user_data(user_id, user)

async def deduct_coins(user_id: int, amount: int, source: str = "balance"):
    user = await get_user_data(user_id)
    current_balance = get_balance(user)
    
    if current_balance >= amount:
        if isinstance(user["balance"], dict):
            new_total = int(user["balance"]["total"]) - amount
            user["balance"]["total"] = max(0, new_total)
            if source == "referral":
                new_ref = int(user["balance"]["referral"]) - amount
                user["balance"]["referral"] = max(0, new_ref)
        else:
            new_balance = int(user["balance"]) - amount
            user["balance"] = max(0, new_balance)
        await update_user_data(user_id, user)
        return True
    return False

def is_admin(user_id: int) -> bool:
    return user_id in ADMINS or user_id == OWNER_ID

async def check_daily_limit(user_id: int, limit_type: str) -> bool:
    if is_admin(user_id):
        return True
    
    user = await get_user_data(user_id)
    
    if limit_type == "likes":
        return user.get("today_likes", 0) < 2
    elif limit_type == "referrals":
        limit = user.get("ref_limit", 25)
        return user.get("today_refs", 0) < limit
    
    return True

def is_vip_active(user):
    if not user.get("vip"):
        return False
    expiry = user.get("vip_expiry")
    if not expiry:
        return False
    try:
        expiry_date = datetime.fromisoformat(expiry)
        return datetime.now() < expiry_date
    except:
        return False

def check_vip_expiry():
    users = load_users()
    updated = False
    for uid, user in users.items():
        expiry = user.get("vip_expiry")
        if expiry:
            try:
                expiry_date = datetime.fromisoformat(expiry)
                if datetime.now() > expiry_date:
                    user["vip"] = False
                    user["vip_expiry"] = None
                    user["vip_given_by"] = None
                    user["vip_expired_notified"] = False
                    user["vip_warned"] = False
                    updated = True
            except:
                continue
    if updated:
        save_users(users)

async def vip_notifications(application):
    users = load_users()
    for uid, user in users.items():
        expiry = user.get("vip_expiry")
        if not expiry:
            continue
        try:
            expiry_date = datetime.fromisoformat(expiry)
            remaining = expiry_date - datetime.now()
            if 0 < remaining.days <= 3 and not user.get("vip_warned"):
                try:
                    await application.bot.send_message(
                        int(uid),
                        f"⚠️ VIP Expiring Soon!\n\n"
                        f"━━━━━━━━━━━━━━━\n"
                        f"⏳ Remaining: {remaining.days} days\n"
                        f"📅 Expiry: {expiry_date.strftime('%d %b %Y, %I:%M %p')}\n"
                        f"━━━━━━━━━━━━━━━\n\n"
                        f"💳 Renew now to keep using Promo Code feature!"
                    )
                except:
                    pass
                for admin in ADMINS:
                    try:
                        await application.bot.send_message(admin, f"⚠️ VIP Expiring Soon\nUser: {uid}\nRemaining: {remaining.days} days")
                    except:
                        pass
                user["vip_warned"] = True
                save_users(users)
            if remaining.total_seconds() <= 0 and not user.get("vip_expired_notified"):
                user["vip"] = False
                user["vip_expiry"] = None
                user["vip_given_by"] = None
                try:
                    await application.bot.send_message(
                        int(uid),
                        f"❌ VIP EXPIRED!\n\n"
                        f"━━━━━━━━━━━━━━━\n"
                        f"📅 Expired On: {expiry_date.strftime('%d %b %Y, %I:%M %p')}\n"
                        f"━━━━━━━━━━━━━━━\n\n"
                        f"🔒 Promo Code Access Disabled\n"
                        f"💳 Renew to continue using features"
                    )
                except:
                    pass
                for admin in ADMINS:
                    try:
                        await application.bot.send_message(admin, f"❌ VIP EXPIRED\nUser: {uid}")
                    except:
                        pass
                user["vip_expired_notified"] = True
                save_users(users)
        except:
            continue

# ==================== REFERRAL PENALTY ====================

async def send_ref_warning_later(user_id, context):
    await asyncio.sleep(300)
    try:
        user = await get_user_data(user_id)
        warning_msg = (
            "⚠️ IMPORTANT NOTICE!\n\n"
            "━━━━━━━━━━━━━━━\n"
            "👥 You joined via referral\n"
            "🚫 If you leave required channels:\n"
            "• Your coins will be deducted 💸\n"
            "• Referrer's coins will also be deducted 💸\n\n"
            "⚡ Stay connected & earn more!"
        )
        await context.bot.send_message(user_id, warning_msg)
    except:
        pass

async def check_referral_penalty(application):
    users = load_users()
    updated = False
    for uid, user in users.items():
        await asyncio.sleep(0.2)
        if not user.get("joined_via_ref"):
            continue
        left = False
        for channel in FORCE_CHANNELS:
            try:
                member = await asyncio.wait_for(application.bot.get_chat_member(channel, int(uid)), timeout=5)
                if member.status in ["left", "kicked"]:
                    left = True
                    break
            except:
                left = True
                break
        if left:
            ref_id = user.get("referred_by")
            user_name = user.get("name", "User")
            deducted_user = 0
            deducted_ref = 0
            if user["balance"]["total"] > 40:
                user["balance"]["total"] -= 40
                deducted_user = 40
            ref_user = None
            if ref_id:
                ref_user = users.get(str(ref_id))
                if ref_user and ref_user["balance"]["total"] >= 80:
                    ref_user["balance"]["total"] -= 80
                    deducted_ref = 80
            try:
                await application.bot.send_message(
                    int(uid),
                    f"❌ You left required channels!\n\n"
                    f"💸 Coins Deducted: {deducted_user}\n"
                    f"💰 Your Balance: {user['balance']['total']}",
                    parse_mode="HTML"
                )
            except:
                pass
            if ref_id and ref_user:
                try:
                    await application.bot.send_message(
                        int(ref_id),
                        f"⚠️ Your referred user left channels!\n\n"
                        f"💸 Coins Deducted: {deducted_ref}\n"
                        f"💰 Your Balance: {ref_user['balance']['total']}",
                        parse_mode="HTML"
                    )
                except:
                    pass
            user["joined_via_ref"] = False
            updated = True
    if updated:
        save_users(users)

# ==================== LIKE TEMP BAN FUNCTIONS ====================

async def check_like_temp_ban(user_id: int):
    """Check if user has like temp ban. Returns (is_banned, remaining_days, remaining_hours, remaining_minutes, time_string)"""
    user = await get_user_data(user_id)
    
    if user.get("like_temp_ban") and user.get("like_temp_ban_expiry"):
        try:
            expiry = datetime.fromisoformat(user["like_temp_ban_expiry"])
            if datetime.now() < expiry:
                remaining = expiry - datetime.now()
                days = remaining.days
                hours = remaining.seconds // 3600
                minutes = (remaining.seconds % 3600) // 60
                
                time_parts = []
                if days > 0:
                    time_parts.append(f"{days} Days")
                if hours > 0:
                    time_parts.append(f"{hours} Hours")
                if minutes > 0:
                    time_parts.append(f"{minutes} Minutes")
                time_str = " ".join(time_parts) if time_parts else "Less than a minute"
                
                return True, days, hours, minutes, time_str
            else:
                user["like_temp_ban"] = False
                user["like_temp_ban_expiry"] = None
                await update_user_data(user_id, user)
                return False, 0, 0, 0, None
        except:
            user["like_temp_ban"] = False
            user["like_temp_ban_expiry"] = None
            await update_user_data(user_id, user)
            return False, 0, 0, 0, None
    return False, 0, 0, 0, None

async def apply_like_temp_ban(user_id: int):
    """Apply 2 days like temp ban"""
    user = await get_user_data(user_id)
    expiry = datetime.now() + timedelta(hours=LIKE_TEMP_BAN_HOURS)
    
    user["like_temp_ban"] = True
    user["like_temp_ban_expiry"] = expiry.isoformat()
    user["like_bypass_attempts"] = user.get("like_bypass_attempts", 0) + 1
    
    await update_user_data(user_id, user)
    
    users = load_users()
    users[str(user_id)] = user
    save_users(users)
    
    return True

async def auto_like_unban(application):
    """Auto unban users after 2 days - restores Get Likes access"""
    users = load_users()
    updated = False
    current_time = datetime.now()
    for uid, user in users.items():
        if user.get("like_temp_ban") and user.get("like_temp_ban_expiry"):
            try:
                expiry = datetime.fromisoformat(user["like_temp_ban_expiry"])
                if current_time >= expiry:
                    user["like_temp_ban"] = False
                    user["like_temp_ban_expiry"] = None
                    updated = True
                    try:
                        await application.bot.send_message(
                            int(uid),
                            f"✅ Your Get Likes access has been automatically restored!\n\n"
                            f"━━━━━━━━━━━━━━━\n"
                            f"You can now use ❤️ Get Likes again.\n"
                            f"⚠️ Please follow the rules to avoid future blocks.\n"
                            f"━━━━━━━━━━━━━━━"
                        )
                    except:
                        pass
            except:
                continue
    if updated:
        save_users(users)

async def show_like_ban_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show block message when banned user tries to use Get Likes"""
    
    user_id = update.effective_user.id

    is_banned, days, hours, minutes, time_str = await check_like_temp_ban(user_id)

    if is_banned:

        block_message = (
            f"⛔ Get Likes Access Temporarily Blocked\n\n"
            f"━━━━━━━━━━━━━━━\n"
            f"Reason:\n"
            f"Your using bypass bots & scripts & groups\n"
            f"━━━━━━━━━━━━━━━\n\n"
            f"⏳ Remaining Time:\n"
            f"{time_str}\n\n"
            f"⚠️ If this was a mistake,\n"
            f"DM Admin & apologize:\n"
            f"@NoobVellen\n"
            f"━━━━━━━━━━━━━━━"
        )

        if update.callback_query:
            await update.callback_query.answer()

            await update.callback_query.message.reply_text(
                block_message,
                reply_markup=get_main_keyboard()
            )

        elif update.message:
            await update.message.reply_text(
                block_message,
                reply_markup=get_main_keyboard()
            )

        context.user_data.clear()

        return True

    return False

# ==================== TEMP BAN FUNCTIONS (Compatibility) ====================

async def check_temp_ban(user_id: int) -> tuple:
    """Legacy function - kept for compatibility"""
    user = await get_user_data(user_id)
    
    if user.get("temp_ban") and user.get("temp_ban_expiry"):
        try:
            expiry = datetime.fromisoformat(user["temp_ban_expiry"])
            if datetime.now() < expiry:
                remaining = expiry - datetime.now()
                total_seconds = int(remaining.total_seconds())
                hours = total_seconds // 3600
                minutes = (total_seconds % 3600) // 60
                return True, f"{hours} Hours {minutes} Minutes"
            else:
                user["temp_ban"] = False
                user["temp_ban_expiry"] = None
                await update_user_data(user_id, user)
                return False, ""
        except:
            user["temp_ban"] = False
            user["temp_ban_expiry"] = None
            await update_user_data(user_id, user)
            return False, ""
    return False, ""

async def global_temp_ban_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Check if user is permanently banned. Returns True if banned."""
    if not update.effective_user:
        return False
    
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    
    if user.get("banned"):
        ban_message = f"🚫 You are permanently banned.\nReason: {user.get('ban_reason', 'No reason')}"
        
        if update.callback_query:
            await update.callback_query.answer()
            await update.callback_query.edit_message_text(ban_message)
        elif update.message:
            await update.message.reply_text(ban_message)
        return True
    return False

async def apply_temp_ban(user_id: int, reason: str = "Bypass detected") -> bool:
    """Apply LIKE TEMP BAN only - NOT full bot ban"""
    await apply_like_temp_ban(user_id)
    
    user = await get_user_data(user_id)
    user["verification_session_id"] = None
    user["verification_timestamp"] = None
    user["current_verification_provider"] = None
    user["verification_link"] = None
    user["bypass_attempts"] = user.get("bypass_attempts", 0) + 1
    
    await update_user_data(user_id, user)
    
    users = load_users()
    users[str(user_id)] = user
    save_users(users)
    
    return True

async def auto_unban_check(application):
    """Legacy auto unban - kept for compatibility"""
    users = load_users()
    updated = False
    current_time = datetime.now()
    for uid, user in users.items():
        if user.get("temp_ban") and user.get("temp_ban_expiry"):
            try:
                expiry = datetime.fromisoformat(user["temp_ban_expiry"])
                if current_time >= expiry:
                    user["temp_ban"] = False
                    user["temp_ban_expiry"] = None
                    updated = True
            except:
                continue
    if updated:
        save_users(users)

# ==================== VPLINK VERIFICATION SYSTEM ====================

async def generate_vplink_link(api_key: str, user_id: int, provider: str, session_id: str) -> str:
    try:
        verify_url = f"https://t.me/{BOT_USERNAME}?start=verify_{user_id}_{provider}_{session_id}"
        url = f"{VPLINK_BASE_URL}?api={api_key}&url={verify_url}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") == "success":
                        short_url = data.get("shortenedUrl", "")
                        if short_url:
                            short_url = short_url.replace("\\/", "/")
                            return short_url
                return None
    except Exception as e:
        logger.error(f"VPLINK Generation Error: {e}")
        return None

async def can_verify_today(user_id: int) -> tuple:
    user = await get_user_data(user_id)
    today = datetime.now().strftime("%Y-%m-%d")
    if user.get("last_verification_date") != today:
        user["today_verifications"] = 0
        user["last_verification_date"] = today
        await update_user_data(user_id, user)
    completed = user.get("today_verifications", 0)
    remaining = MAX_DAILY_VERIFICATIONS - completed
    if remaining <= 0:
        return False, 0, None
    if completed == 0:
        next_provider = "NoobVellen"
        api_key = VPLINK_API_KEY_NOOBVELLEN
    elif completed == 1:
        next_provider = "Nexo"
        api_key = VPLINK_API_KEY_NEXO
    else:
        return False, 0, None
    return True, remaining, {"name": next_provider, "api_key": api_key, "reward": VERIFICATION_REWARD}

async def auto_verify_user(user_id: int, provider: str, session_id: str, context) -> tuple:
    user = await get_user_data(user_id)
    
    used_sessions = user.get("used_verification_sessions", [])
    if session_id in used_sessions:
        logger.warning(f"REPLAY ATTACK: {user_id}")
        await apply_temp_ban(user_id)
        user["verification_session_id"] = None
        user["verification_timestamp"] = None
        user["current_verification_provider"] = None
        await update_user_data(user_id, user)
        return False, "❌ Session already used - Get Likes blocked for 2 days!"
    
    stored_session = user.get("verification_session_id")
    if stored_session != session_id:
        return False, "❌ Invalid session"
    
    timestamp_str = user.get("verification_timestamp")
    if not timestamp_str:
        return False, "❌ No active session"
    
    try:
        verification_time = datetime.fromisoformat(timestamp_str)
        elapsed = (datetime.now() - verification_time).total_seconds()
    except:
        return False, "❌ Invalid timestamp"
    
    max_valid_seconds = VERIFICATION_LINK_VALID_HOURS * 3600
    if elapsed > max_valid_seconds:
        user["verification_session_id"] = None
        user["verification_timestamp"] = None
        user["current_verification_provider"] = None
        await update_user_data(user_id, user)
        return False, f"❌ Link expired ({VERIFICATION_LINK_VALID_HOURS} hours)"
    
    if elapsed < VERIFICATION_TIMEOUT_SECONDS:

        logger.warning(f"BYPASS DETECTED: {user_id} | {elapsed:.1f}s")

        # Apply LIKE TEMP BAN
        await apply_temp_ban(user_id)

        context.user_data.clear()

        current_balance = get_balance(user)
        deducted_amount = 100 if current_balance >= 100 else current_balance
        if deducted_amount > 0:
            await deduct_coins(user_id, deducted_amount)
        
        user_name = user.get("name", "User")
        clickable_name = f'<a href="tg://user?id={user_id}">{html.escape(user_name)}</a>'
        
        alert_msg = (
            f"⚠️ BYPASS ATTEMPT DETECTED\n"
            f"━━━━━━━━━━━━━━━\n"
            f"👤 User: {clickable_name}\n"
            f"🆔 User ID: {user_id}\n"
            f"🚫 Action: Get Likes Blocked for 2 Days\n"
            f"💸 Coins Deducted: {deducted_amount}\n"
            f"⏱️ Time: {int(elapsed)}s\n"
            f"━━━━━━━━━━━━━━━"
        )
        
        for admin_id in ADMINS + [OWNER_ID]:
            try:
                await context.bot.send_message(admin_id, alert_msg, parse_mode=ParseMode.HTML)
            except:
                pass
        
        await send_bypass_group_log(context.application, user_id, user_name, deducted_amount)
        

        
        return False, f"⚠️ BYPASS DETECTED!\n\n❤️ Get Likes blocked for 2 days.\nCoins deducted: {deducted_amount}\nAll other features still work."
    
    logger.info(f"VALID VERIFY: {user_id} | {elapsed:.1f}s")
    
    today = datetime.now().strftime("%Y-%m-%d")
    if user.get("last_verification_date") != today:
        user["today_verifications"] = 0
    
    if user.get("today_verifications", 0) >= MAX_DAILY_VERIFICATIONS:
        return False, "❌ Daily limit reached"
    
    reward = VERIFICATION_REWARD
    user["today_verifications"] = user.get("today_verifications", 0) + 1
    user["last_verification_date"] = today
    
    if isinstance(user["balance"], dict):
        user["balance"]["total"] = user["balance"].get("total", 0) + reward
        user["balance"]["verification"] = user["balance"].get("verification", 0) + reward
    
    used_sessions.append(session_id)
    user["used_verification_sessions"] = used_sessions[-50:]
    user["verification_session_id"] = None
    user["verification_timestamp"] = None
    user["current_verification_provider"] = None
    
    await update_user_data(user_id, user)
    return True, f"✅ Verified! +{reward} coins"

async def send_verification_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Check like ban first - Get Likes blocked but verification still works
    # Actually verification should still work even if like banned
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    can_verify, remaining_count, provider_info = await can_verify_today(user_id)
    if not can_verify:
        await update.message.reply_text(
            f"❌ Daily Limit Reached\n\n"
            f"━━━━━━━━━━━━━━━\n"
            f"📅 Completed {MAX_DAILY_VERIFICATIONS}/2 verifications today.\n"
            f"🔄 Resets at 12:00 AM IST",
            reply_markup=get_main_keyboard()
        )
        return
    api_key = provider_info["api_key"]
    provider_name = provider_info["name"]
    reward = provider_info["reward"]
    status_msg = await update.message.reply_text(f"🔄 Generating link...\n🌐 Provider: {provider_name}\n⏳ Please wait...")
    session_id = secrets.token_hex(16)
    shortlink = await generate_vplink_link(api_key, user_id, provider_name, session_id)
    if not shortlink:
        await status_msg.edit_text("❌ Failed to generate link\nPlease try again later.", reply_markup=get_main_keyboard())
        return
    user["current_verification_provider"] = provider_name
    user["verification_timestamp"] = datetime.now().isoformat()
    user["verification_link"] = shortlink
    user["verification_session_id"] = session_id
    await update_user_data(user_id, user)
    keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("✅ CLICK TO VERIFY ✅", url=shortlink)]])
    await status_msg.edit_text(
        f"🔗 VERIFICATION LINK GENERATED\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🌐 Provider: {provider_name}\n"
        f"💰 Reward: {reward} Coins\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"⚠️ INSTRUCTIONS:\n"
        f"1️⃣ Click the button below\n"
        f"2️⃣ Complete the shortlink\n"
        f"3️⃣ AUTO-VERIFIED\n\n"
        f"⏳ Valid for {VERIFICATION_LINK_VALID_HOURS} hours\n"
        f"🚫 Bypass = 2 Days Get Likes Block!",
        reply_markup=keyboard
    )

async def send_to_groups(application, user_id: int, username: str, provider: str, reward: int):
    clickable_user = f'<a href="tg://user?id={user_id}">{html.escape(username)}</a>'
    group_msg = (
        f"✅ Verification Completed\n"
        f"━━━━━━━━━━━━━━━\n"
        f"👤 User: {clickable_user}\n"
        f"🆔 ID: {user_id}\n"
        f"🌐 Provider: {provider}\n"
        f"💰 Reward: {reward} Coins\n"
        f"━━━━━━━━━━━━━━━"
    )
    for group_id in LIKE_SUCCESS_GROUPS:
        try:
            await application.bot.send_message(group_id, group_msg, parse_mode=ParseMode.HTML)
        except:
            pass

async def send_bypass_group_log(application, user_id: int, username: str, deducted_coins: int):
    clickable_user = f'<a href="tg://user?id={user_id}">{html.escape(username)}</a>'
    group_msg = (
        f"⚠️ Bypass Attempt Detected\n"
        f"━━━━━━━━━━━━━━━\n"
        f"👤 User: {clickable_user}\n"
        f"🆔 ID: {user_id}\n"
        f"🚫 Action: Get Likes Blocked for 2 Days\n"
        f"💸 Coins Deducted: {deducted_coins}\n"
        f"━━━━━━━━━━━━━━━"
    )
    for group_id in LIKE_SUCCESS_GROUPS:
        try:
            await application.bot.send_message(group_id, group_msg, parse_mode=ParseMode.HTML)
        except:
            pass

# ==================== BASIC COMMANDS ====================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):

    user = update.effective_user
    args = context.args
    user_id = user.id

    if not await force_join_check(update, context):
        return

    logger.info(f"USER ACTION: /start from {user_id}")

    if args and len(args) > 0 and args[0].startswith("verify_"):

        logger.info(f"START ARGS: {args}")

        try:

            verify_data = args[0].replace("verify_", "", 1)

            parts = verify_data.split("_")

            if len(parts) != 3:

                await update.message.reply_text(
                    "❌ Invalid verification link.",
                    reply_markup=get_main_keyboard()
                )

                return

            target_id = int(parts[0])
            provider = parts[1]
            session_id = parts[2]

        except Exception as e:

            logger.error(f"VERIFY PARSE ERROR: {e}")

            await update.message.reply_text(
                "❌ Verification link broken.",
                reply_markup=get_main_keyboard()
            )

            return

        if target_id == user_id:

            success, message = await auto_verify_user(
                user_id,
                provider,
                session_id,
                context
            )

            if success:

                user_data = await get_user_data(user_id)

                total_coins = get_balance(user_data)

                completed = user_data.get(
                    "today_verifications",
                    0
                )

                await update.message.reply_text(
                    f"✅ VERIFICATION SUCCESSFUL!\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🌐 Provider: {provider}\n"
                    f"💰 Reward: {VERIFICATION_REWARD} Coins\n"
                    f"💳 Balance: {total_coins} Coins\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📅 Today: {completed}/{MAX_DAILY_VERIFICATIONS}",
                    reply_markup=get_main_keyboard()
                )

                await send_to_groups(
                    context.application,
                    user_id,
                    user.first_name,
                    provider,
                    VERIFICATION_REWARD
                )

                verified = load_verified_users()

                today = datetime.now().strftime("%Y-%m-%d")

                verified[str(user_id)] = today

                save_verified_users(verified)

                return
    
    user_data = await get_user_data(user_id)
    user_data["name"] = update.effective_user.first_name
    await update_user_data(user_id, user_data)
    
    if user_data.get("banned"):
        await update.message.reply_text(f"🚫 You are permanently banned.\nReason: {user_data['ban_reason']}")
        return
    
    verified = load_verified_users()

    today = datetime.now().strftime("%Y-%m-%d")

    if verified.get(str(user_id)) == today:

        await update.message.reply_text(
            f"✅ Welcome back {html.escape(user.first_name)}! 👋\n⭐ Select an option:",
            reply_markup=get_main_keyboard()
        )

        return
    
    await update.message.reply_text(
        f"👋 Welcome {html.escape(user.first_name)}!\n⭐ Select an option:",
        reply_markup=get_main_keyboard(),
    )
    
    escaped_name = html.escape(user.first_name)
    clickable_name = f'<a href="tg://user?id={user_id}">{escaped_name}</a>'
    notify_text = f"🆕 New User Joined!\n\n{format_separator()}\n{clickable_name}\n{format_separator()}"
    for admin_id in ADMINS:
        try:
            await context.bot.send_message(admin_id, notify_text, parse_mode=ParseMode.HTML)
        except:
            pass

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    total_balance = get_balance(user)
    ref_balance = get_referral_balance(user)
    purchased_balance = get_purchased_balance(user)
    redeemed_balance = get_redeemed_balance(user)
    verification_balance = user.get("balance", {}).get("verification", 0) if isinstance(user.get("balance"), dict) else 0
    usd_value = total_balance / 2200
    text = (
        f"💰 Your Balance\n\n"
        f"🪙 Total: {total_balance}\n"
        f"💵 Worth: ${usd_value:.2f}\n\n"
        f"📊 Breakdown:\n"
        f"• Referral: {ref_balance}\n"
        f"• Purchased: {purchased_balance}\n"
        f"• Redeemed: {redeemed_balance}\n"
        f"• Verification: {verification_balance}"
    )
    await update.message.reply_text(text, reply_markup=get_main_keyboard())

async def earn(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    referral_link = f"https://t.me/{BOT_USERNAME}?start=ref_{user_id}"
    settings = load_bot_settings()
    text = (
        f"👥 Earn Coins\n\n"
        f"Balance: {get_balance(user)}\n\n"
        f"1 Refer = {settings['referral_reward']} coins\n\n"
        f"Your link:\n{referral_link}"
    )
    await update.message.reply_text(text, reply_markup=get_main_keyboard())

async def referrals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    text = f"👥 My Referrals\n\nTotal: {len(user['referrals'])}\nEarnings: {get_referral_balance(user)} coins\n\nList:\n"
    if user['referrals']:
        for ref_id in user['referrals'][:10]:
            try:
                ref_user = await context.bot.get_chat(ref_id)
                text += f"{ref_user.first_name} (ID: {ref_id})\n"
            except:
                text += f"User {ref_id}\n"
    else:
        text += "No referrals yet."
    await update.message.reply_text(text, reply_markup=get_main_keyboard())

async def usage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    likes_used = user.get("likes_used", 0)
    total_likes = user.get("total_likes", 0)
    today_likes = user.get("today_likes", 0)
    today_refs = user.get("today_refs", 0)
    referrals_count = len(user.get("referrals", []))
    uids_list = user.get("uids", [])
    if not uids_list:
        uids_text = "• None"
    else:
        recent_uids = uids_list[-20:]
        uids_text = "\n".join([f"• {uid}" for uid in recent_uids])
        if len(uids_list) > 20:
            uids_text += f"\n• ... and {len(uids_list) - 20} more"
    text = (
        f"📊 My Usage\n\n"
        f"👥 Referrals: {referrals_count}\n"
        f"❤️ Likes Claimed: {likes_used}\n"
        f"📊 Total Likes: {total_likes}\n\n"
        f"📅 Today:\n"
        f"• Likes: {today_likes}/2\n"
        f"• Referrals: {today_refs}/{user.get('ref_limit',25)}\n"
        f"ℹ️ UIDs Used:\n{uids_text}"
    )
    await update.message.reply_text(text, reply_markup=get_main_keyboard())

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    text = (
        "❓ Help & Commands\n\n"
        "/start - Start the bot\n"
        "/balance - Check balance\n"
        "/redeem - Redeem promo code\n"
        "/earn - Earn coins\n"
        "/referrals - View referrals\n"
        "/getlikes - Get likes\n"
        "/buy - Buy coins\n"
        "/usage - View stats\n"
        "/leaderboard - Top users\n"
        "/help - This message\n\n"
        "Admin: /admin"
    )
    await update.message.reply_text(text, reply_markup=get_main_keyboard())

async def leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    users = load_users()
    fixed_users = {}
    for uid, data in users.items():
        fixed_users[uid] = fix_user(data)
    top_users = sorted(fixed_users.items(), key=lambda x: get_balance(x[1]), reverse=True)[:20]
    text = f"🏆 Leaderboard\n\n{format_separator()}\n"
    for i, (uid, data) in enumerate(top_users, 1):
        try:
            user_obj = await context.bot.get_chat(int(uid))
            user_name = user_obj.first_name if user_obj.first_name else str(uid)
            safe_name = html.escape(user_name)
            clickable_name = f'<a href="tg://user?id={uid}">{safe_name}</a>'
            text += f"{i}. {clickable_name} - {get_balance(data)} 🪙\n"
        except:
            safe_name = html.escape(f"User {uid}")
            clickable_name = f'<a href="tg://user?id={uid}">{safe_name}</a>'
            text += f"{i}. {clickable_name} - {get_balance(data)} 🪙\n"
    text += format_separator()
    await update.message.reply_text(text, reply_markup=get_main_keyboard(), parse_mode=ParseMode.HTML)

async def show_top_coins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    users = load_users()
    fixed_users = {}
    for uid, data in users.items():
        fixed_users[uid] = fix_user(data)
    top_users = sorted(fixed_users.items(), key=lambda x: get_balance(x[1]), reverse=True)[:20]
    text = "💰 Top 20 Coins\n\n━━━━━━━━━━━━━━\n"
    for i, (uid, data) in enumerate(top_users, 1):
        try:
            user_obj = await context.bot.get_chat(int(uid))
            safe_name = html.escape(user_obj.first_name)
        except:
            safe_name = f"User {uid}"
        clickable = f'<a href="tg://user?id={uid}">{safe_name}</a>'
        rank = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        text += f"{rank} {clickable} - {get_balance(data)} 🪙\n"
    text += "━━━━━━━━━━━━━━"
    await update.message.reply_text(text, reply_markup=get_leaderboard_menu(), parse_mode=ParseMode.HTML)

async def show_top_referrals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    users = load_users()
    fixed_users = {}
    for uid, data in users.items():
        fixed_users[uid] = fix_user(data)
    top_users = sorted(fixed_users.items(), key=lambda x: len(x[1].get("referrals", [])), reverse=True)[:20]
    text = "👥 Top 20 Referrers\n\n━━━━━━━━━━━━━━\n"
    for i, (uid, data) in enumerate(top_users, 1):
        try:
            user_obj = await context.bot.get_chat(int(uid))
            safe_name = html.escape(user_obj.first_name)
        except:
            safe_name = f"User {uid}"
        clickable = f'<a href="tg://user?id={uid}">{safe_name}</a>'
        rank = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        text += f"{rank} {clickable} - {len(data.get('referrals', []))} referrals\n"
    text += "━━━━━━━━━━━━━━"
    await update.message.reply_text(text, reply_markup=get_leaderboard_menu(), parse_mode=ParseMode.HTML)

# ==================== REDEEM SYSTEM ====================

async def redeem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    await update.message.reply_text("🎟️ Send promo code:", reply_markup=get_cancel_keyboard())
    return "WAITING_CODE"

async def process_redeem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    user_id = update.effective_user.id
    code = update.message.text.strip().upper()
    codes = load_codes()
    if code not in codes:
        await update.message.reply_text("❌ Invalid code. Try again:", reply_markup=get_cancel_keyboard())
        return "WAITING_CODE"
    code_data = codes[code]
    if len(code_data["users"]) >= code_data["max_users"]:
        await update.message.reply_text("❌ Code max uses reached.", reply_markup=get_cancel_keyboard())
        return "WAITING_CODE"
    if code_data.get("created_by") == user_id:
        await update.message.reply_text("❌ Cannot use own code.", reply_markup=get_cancel_keyboard())
        return "WAITING_CODE"
    if user_id in code_data["users"]:
        await update.message.reply_text("❌ Already used this code.", reply_markup=get_cancel_keyboard())
        return "WAITING_CODE"
    await add_coins(user_id, code_data["amount"], "redeemed")
    code_data["users"].append(user_id)
    codes[code] = code_data
    save_codes(codes)
    user = await get_user_data(user_id)
    await update.message.reply_text(f"✅ Redeemed! +{code_data['amount']} 🪙\nNew balance: {get_balance(user)}", reply_markup=get_main_keyboard())
    return ConversationHandler.END

async def check_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message and update.message.text == "❌ Cancel":
        context.user_data.clear()
        await update.message.reply_text("❌ Cancelled.", reply_markup=get_main_keyboard())
        return True
    return False

# ==================== LIKE SYSTEM ====================

async def get_likes(update: Update, context: ContextTypes.DEFAULT_TYPE):

    # IMPORTANT: Check LIKE TEMP BAN FIRST
    if await show_like_ban_message(update, context):
        context.user_data.clear()
        return ConversationHandler.END

    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    
    settings = get_like_settings()
    if not settings["enabled"]:
        await update.message.reply_text("❌ GET LIKE CLOSED")
        return ConversationHandler.END
    
    await update.message.reply_text("❤️ Enter UID:", reply_markup=get_cancel_keyboard())
    return "WAITING_UID"

async def process_uid(update: Update, context: ContextTypes.DEFAULT_TYPE):

    # HARD BLOCK CHECK
    is_banned, days, hours, minutes, time_str = await check_like_temp_ban(update.effective_user.id)

    if is_banned:
        context.user_data.clear()

        await update.message.reply_text(
            f"⛔ Get Likes Access Temporarily Blocked\n\n"
            f"━━━━━━━━━━━━━━━\n"
            f"Reason:\n"
            f"Your using bypass bots & scripts & groups\n"
            f"━━━━━━━━━━━━━━━\n\n"
            f"⏳ Remaining Time:\n"
            f"{time_str}\n\n"
            f"⚠️ If this was a mistake,\n"
            f"DM Admin & apologize:\n"
            f"@NoobVellen\n"
            f"━━━━━━━━━━━━━━━",
            reply_markup=get_main_keyboard()
        )

        return ConversationHandler.END

    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    
    if await check_cancel(update, context):
        return ConversationHandler.END
    
    uid = update.message.text.strip()
    if not uid.isdigit() or len(uid) < 6 or len(uid) > 12:
        await update.message.reply_text("❌ Invalid UID (6-12 digits). Try again:", reply_markup=get_cancel_keyboard())
        return "WAITING_UID"
    context.user_data["uid"] = uid
    await update.message.reply_text(f"✅ UID: {uid}\n\nEnter Server ({', '.join(REGIONS)}):", reply_markup=get_cancel_keyboard())
    return "WAITING_SERVER"

async def process_server(update: Update, context: ContextTypes.DEFAULT_TYPE):

    # HARD BLOCK CHECK
    is_banned, days, hours, minutes, time_str = await check_like_temp_ban(update.effective_user.id)

    if is_banned:
        context.user_data.clear()

        await update.message.reply_text(
            f"⛔ Get Likes Access Temporarily Blocked\n\n"
            f"━━━━━━━━━━━━━━━\n"
            f"Reason:\n"
            f"Your using bypass bots & scripts & groups\n"
            f"━━━━━━━━━━━━━━━\n\n"
            f"⏳ Remaining Time:\n"
            f"{time_str}\n\n"
            f"⚠️ If this was a mistake,\n"
            f"DM Admin & apologize:\n"
            f"@NoobVellen\n"
            f"━━━━━━━━━━━━━━━",
            reply_markup=get_main_keyboard()
        )

        return ConversationHandler.END

    # EXTRA SAFETY CHECK
    if "uid" not in context.user_data:
        context.user_data.clear()

        await update.message.reply_text(
            "❌ Session expired.\nPlease click ❤️ Get Likes again.",
            reply_markup=get_main_keyboard()
        )

        return ConversationHandler.END

    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    
    if await check_cancel(update, context):
        return ConversationHandler.END
    
    user_id = update.effective_user.id
    server = update.message.text.strip().upper()
    uid = context.user_data.get("uid")
    if not server:
        await update.message.reply_text("❌ Server required:", reply_markup=get_cancel_keyboard())
        return "WAITING_SERVER"
    if server not in REGIONS:
        await update.message.reply_text(f"❌ Invalid. Available: {', '.join(REGIONS)}", reply_markup=get_cancel_keyboard())
        return "WAITING_SERVER"
    allowed, message = await check_uid_daily_limit(uid, server)
    if not allowed:
        await update.message.reply_text(message, reply_markup=get_main_keyboard())
        return ConversationHandler.END
    user = await get_user_data(user_id)
    balance = get_balance(user)
    if balance < MIN_COINS_REQUIRED:
        await update.message.reply_text(f"❌ Need {MIN_COINS_REQUIRED} coins. Balance: {balance}", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    if not is_admin(user_id):
        allowed = await check_daily_limit(user_id, "likes")
        if not allowed:
            await update.message.reply_text("❌ Daily limit of 2 likes reached.", reply_markup=get_main_keyboard())
            return ConversationHandler.END
    await update.message.reply_text("⏳ Processing...", reply_markup=get_main_keyboard())
    try:
        url = f"{API_URL.format(region=server, uid=uid)}?key={API_KEY}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                data = await response.json()
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    if data.get("status") != 1:
        await update.message.reply_text(f"❌ Failed: {data.get('message', 'Unknown error')}", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    likes = int(data["response"].get("LikesGivenByAPI", 0))
    before = data["response"].get("LikesbeforeCommand", 0)
    after = data["response"].get("LikesafterCommand", 0)
    player_name = data["response"].get("PlayerNickname", "Unknown")
    remaining_requests = data["response"].get("KeyRemainingRequests", "Unknown")
    response_uid = str(data["response"].get("UID", uid))
    if likes <= 0:
        await update.message.reply_text("❌ No likes received.", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    settings = load_bot_settings()
    cost = int(likes * settings["cost_per_like"])
    if not await deduct_coins(user_id, cost):
        await update.message.reply_text(f"❌ Need {cost} coins.", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    await mark_uid_used(uid, server)
    await increment_likes_stats(user_id, likes, response_uid)
    user = await get_user_data(user_id)
    success_msg = (
        f"✅ Likes Added!\n\n"
        f"Player: {player_name}\n"
        f"UID: {uid}\n"
        f"Server: {server}\n\n"
        f"Likes: {likes}\n"
        f"Before: {before}\n"
        f"After: {after}\n"
        f"API Remaining: {remaining_requests}\n\n"
        f"Cost: {cost}\n"
        f"Balance: {get_balance(user)}"
    )

    # ================= GROUP LIKE SUCCESS LOG =================

    clickable_user = f'<a href="tg://user?id={user_id}">{html.escape(update.effective_user.first_name)}</a>'

    group_text = (
        f"❤️ LIKE SUCCESS\n"
        f"━━━━━━━━━━━━━━━\n"
        f"👤 User: {clickable_user}\n"
        f"🆔 ID: {user_id}\n"
        f"🎮 Player: {player_name}\n"
        f"🌍 Server: {server}\n"
        f"🆔 UID: {uid}\n"
        f"❤️ Likes Sent: {likes}\n"
        f"📈 Before: {before}\n"
        f"📉 After: {after}\n"
        f"🔑 Remaining Req: {remaining_requests}\n"
        f"━━━━━━━━━━━━━━━"
    )

    for group_id in LIKE_SUCCESS_GROUPS:
        try:
            await context.bot.send_message(
                chat_id=group_id,
                text=group_text,
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"GROUP LOG ERROR: {e}")

    await update.message.reply_text(success_msg, reply_markup=get_main_keyboard())

    return ConversationHandler.END                  

async def check_uid_daily_limit(uid: str, server: str) -> tuple:
    history = load_like_history()
    today = datetime.now().strftime("%Y-%m-%d")
    key = f"{uid}_{server}"
    if key in history and history[key] == today:
        return False, "⚠️ UID already used today."
    return True, ""

async def mark_uid_used(uid: str, server: str):
    history = load_like_history()
    today = datetime.now().strftime("%Y-%m-%d")
    key = f"{uid}_{server}"
    history[key] = today
    save_like_history(history)

async def increment_likes_stats(user_id: int, likes_given: int, uid: str):
    if is_admin(user_id):
        return
    user = await get_user_data(user_id)
    today = datetime.now().strftime("%Y-%m-%d")
    if user.get("last_date") != today:
        user["today_likes"] = 0
        user["today_refs"] = 0
        user["last_date"] = today
    user.setdefault("likes_used", 0)
    user.setdefault("total_likes", 0)
    user.setdefault("today_likes", 0)
    user.setdefault("uids", [])
    user["likes_used"] += 1
    user["total_likes"] += int(likes_given)
    user["today_likes"] += 1
    if uid and uid not in user["uids"]:
        user["uids"].append(uid)
    await update_user_data(user_id, user)

def load_bot_settings():
    settings = load_settings()
    return {
        "referral_reward": settings.get("referral_reward", REFERRAL_REWARD),
        "cost_per_like": settings.get("cost_per_like", COST_PER_LIKE),
        "daily_limit": settings.get("daily_limit", 25)
    }

# ==================== BUY SYSTEM ====================

async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    await update.message.reply_text("🛒 Select package:", reply_markup=get_package_keyboard())
    return "WAITING_PACKAGE"

async def buy_package(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    text = update.message.text
    if "2200" in text:
        package = 2200
    elif "5500" in text:
        package = 5500
    elif "11000" in text:
        package = 11000
    else:
        await update.message.reply_text("❌ Invalid.", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    context.user_data["buy_amount"] = package
    await update.message.reply_text(f"💰 {package} Coins\n\nSelect payment:", reply_markup=get_payment_keyboard())
    return "WAITING_PAYMENT_METHOD"

async def payment_method(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    text = update.message.text
    if "UPI" in text:
        context.user_data["payment_method"] = "upi"
        await update.message.reply_text("Select Merchant:", reply_markup=get_merchant_keyboard())
        return "WAITING_MERCHANT"
    elif "USDT" in text:
        context.user_data["payment_method"] = "usdt"
        amount = context.user_data["buy_amount"]
        price = amount * 160 // 2200
        usdt_amount = price / 80
        await update.message.reply_text(
            f"💰 USDT TRC20\n\nWallet: {USDT['WALLET']}\nNetwork: {USDT['NETWORK']}\n"
            f"Amount: ${usdt_amount:.2f}\n\nSend screenshot after payment.",
            reply_markup=get_cancel_keyboard()
        )
        return "WAITING_PAYMENT_PROOF"
    else:
        await update.message.reply_text("❌ Invalid.", reply_markup=get_main_keyboard())
        return ConversationHandler.END

async def select_merchant(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    text = update.message.text
    if text == "🏦 NoobVellen":
        merchant_name = "NoobVellen"
    elif text == "🏦 Nexo":
        merchant_name = "Nexo"
    else:
        await update.message.reply_text("❌ Invalid.", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    upi_id = UPI_IDS[merchant_name]
    amount = context.user_data["buy_amount"]
    price = amount * 160 // 2200
    upi_link = f"upi://pay?pa={upi_id}&pn={merchant_name}&am={price}&cu=INR"
    qr = qrcode.make(upi_link)
    bio = BytesIO()
    qr.save(bio, format='PNG')
    bio.seek(0)
    context.user_data["merchant"] = merchant_name
    context.user_data["upi_id"] = upi_id
    order_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    context.user_data["order_id"] = order_id
    await update.message.reply_photo(
        photo=InputFile(bio),
        caption=f"📋 Order: {order_id}\n🪙 Coins: {amount}\n💰 Amount: ₹{price}\n💳 UPI: {upi_id}\n\nSend screenshot after payment.",
        reply_markup=get_cancel_keyboard()
    )
    return "WAITING_PAYMENT_PROOF"

async def process_payment_proof(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    user = update.effective_user
    user_id = user.id
    amount = context.user_data.get("buy_amount")
    method = context.user_data.get("payment_method", "upi")
    merchant = context.user_data.get("merchant", "N/A")
    upi_id = context.user_data.get("upi_id", "N/A")
    order_id = context.user_data.get("order_id", ''.join(random.choices(string.ascii_uppercase + string.digits, k=8)))
    if not update.message.photo:
        await update.message.reply_text("❌ Send payment screenshot.", reply_markup=get_cancel_keyboard())
        return "WAITING_PAYMENT_PROOF"
    photo = update.message.photo[-1].file_id
    order_data = {
        "id": order_id, "user_id": user_id, "username": user.username,
        "name": user.first_name, "coins": amount, "amount": amount * 160 // 2200,
        "method": method, "merchant": merchant, "upi_id": upi_id,
        "status": "pending", "created_at": datetime.now().isoformat(),
    }
    orders_data = load_orders()
    orders_data["orders"].append(order_data)
    save_orders(orders_data)
    await update.message.reply_text(f"✅ Payment proof submitted!\nOrder ID: {order_id}\nAdmin will verify.", reply_markup=get_main_keyboard())
    clickable_name = get_clickable_name(user)
    admin_text = (
        f"💰 New Payment!\n\nOrder: {order_id}\nUser: {clickable_name}\nID: {user_id}\n"
        f"Coins: {amount}\nAmount: ₹{amount * 160 // 2200}\n\n/verifypayment {order_id} confirm/reject"
    )
    for admin_id in ADMINS:
        try:
            await context.bot.send_photo(chat_id=admin_id, photo=photo, caption=admin_text, parse_mode=ParseMode.HTML)
        except:
            try:
                await context.bot.send_message(admin_id, admin_text, parse_mode=ParseMode.HTML)
            except:
                pass
    context.user_data.clear()
    return ConversationHandler.END

# ==================== REDEEM CODE (Create) ====================

async def create_code_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    if not is_vip_active(user):
        await update.message.reply_text("❌ VIP required to create codes.\nContact @NoobVellen", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    if user.get("today_created_codes", 0) >= user.get("create_code_limit", 5):
        await update.message.reply_text("❌ Daily limit of 5 codes reached.", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    await update.message.reply_text("➕ Enter value per user (10-500):", reply_markup=get_cancel_keyboard())
    return "CREATE_VALUE"

async def create_code_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    try:
        value = int(update.message.text)
    except:
        await update.message.reply_text("❌ Enter a number (10-500):", reply_markup=get_cancel_keyboard())
        return "CREATE_VALUE"
    if value < 10 or value > 500:
        await update.message.reply_text("❌ Between 10-500:", reply_markup=get_cancel_keyboard())
        return "CREATE_VALUE"
    context.user_data["code_value"] = value
    await update.message.reply_text(f"ℹ️ Value: {value}\n\nEnter max users:", reply_markup=get_cancel_keyboard())
    return "CREATE_MAX"

async def create_code_final(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    user_id = update.effective_user.id
    try:
        max_users = int(update.message.text)
    except:
        await update.message.reply_text("❌ Enter a number:", reply_markup=get_cancel_keyboard())
        return "CREATE_MAX"
    if max_users <= 0:
        await update.message.reply_text("❌ Must be > 0:", reply_markup=get_cancel_keyboard())
        return "CREATE_MAX"
    value = context.user_data.get("code_value")
    total_cost = value * max_users
    if not await deduct_coins(user_id, total_cost):
        await update.message.reply_text(f"❌ Need {total_cost} coins.", reply_markup=get_main_keyboard())
        return ConversationHandler.END
    code = f"NXN_{random.randint(100000,999999)}"
    codes = load_codes()
    codes[code] = {"amount": value, "max_users": max_users, "users": [], "created_by": user_id}
    save_codes(codes)
    user = await get_user_data(user_id)
    user["today_created_codes"] = user.get("today_created_codes", 0) + 1
    await update_user_data(user_id, user)
    await update.message.reply_text(
        f"✅ Code Created!\n\n🔑 `{code}`\n🪙 Value: {value}\n👥 Max: {max_users}\n💰 Cost: {total_cost}\n"
        f"💰 New Balance: {get_balance(user)}",
        parse_mode="Markdown", reply_markup=get_main_keyboard()
    )
    return ConversationHandler.END

async def redeem_code_channel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    await update.message.reply_text("📢 Join Giveaway: https://t.me/NXN_COPANS", reply_markup=get_redeem_menu())

# ==================== ADMIN COMMANDS ====================

async def on_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    update_like_settings(enabled=True)
    await update.message.reply_text("🟢 GET LIKE ENABLED")

async def off_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    update_like_settings(enabled=False)
    await update.message.reply_text("🔴 GET LIKE DISABLED")

async def admin_panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Not admin.")
        return
    await update.message.reply_text("👑 Admin Panel", reply_markup=get_admin_keyboard())

async def admin_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text(f"Admins: {', '.join(map(str, ADMINS))}", reply_markup=get_admin_keyboard())

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    users = load_users()
    total_coins = 0
    for u in users.values():
        fixed = fix_user(u)
        total_coins += get_balance(fixed)
    await update.message.reply_text(
        f"📊 Stats\n\nTotal Users: {len(users)}\nTotal Coins: {total_coins}\nAdmins: {len(ADMINS)}",
        reply_markup=get_admin_keyboard()
    )

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("📢 Send message to broadcast:", reply_markup=get_cancel_keyboard())
    return "WAITING_BROADCAST"

async def process_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    message = update.message
    admin_id = update.effective_user.id
    asyncio.create_task(broadcast_task(context.application, message, admin_id))
    await update.message.reply_text("🚀 Broadcast started!", reply_markup=get_admin_keyboard())
    return ConversationHandler.END

async def broadcast_task(application, message, admin_id):
    users = list(load_users().keys())
    success = 0
    failed = 0
    total = len(users)
    for i in range(0, total, 30):
        batch = users[i:i+30]
        tasks = []
        for uid in batch:
            tasks.append(application.bot.copy_message(chat_id=int(uid), from_chat_id=message.chat_id, message_id=message.message_id))
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for r in results:
            if isinstance(r, Exception):
                failed += 1
            else:
                success += 1
        await asyncio.sleep(1)
    try:
        await application.bot.send_message(admin_id, f"📢 Broadcast Done!\n✅ {success}\n❌ {failed}\n👥 {total}")
    except:
        pass

async def addcoins_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("➕ Format: USER_ID AMOUNT", reply_markup=get_cancel_keyboard())
    return "WAITING_ADD_COINS"

async def process_addcoins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    parts = update.message.text.split()
    if len(parts) != 2:
        await update.message.reply_text("❌ Format: USER_ID AMOUNT", reply_markup=get_cancel_keyboard())
        return "WAITING_ADD_COINS"
    user_id, amount = parts
    if not user_id.isdigit() or not amount.isdigit():
        await update.message.reply_text("❌ Numbers only.", reply_markup=get_cancel_keyboard())
        return "WAITING_ADD_COINS"
    await add_coins(int(user_id), int(amount), "purchased")
    await update.message.reply_text(f"✅ Added {amount} coins to {user_id}.", reply_markup=get_admin_keyboard())
    try:
        user = await get_user_data(int(user_id))
        await context.bot.send_message(int(user_id), f"💰 +{amount} coins!\nNew balance: {get_balance(user)}")
    except:
        pass
    return ConversationHandler.END

async def removecoins_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("➖ Format: USER_ID AMOUNT", reply_markup=get_cancel_keyboard())
    return "WAITING_REMOVE_COINS"

async def process_removecoins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    parts = update.message.text.split()
    if len(parts) != 2:
        await update.message.reply_text("❌ Format: USER_ID AMOUNT", reply_markup=get_cancel_keyboard())
        return "WAITING_REMOVE_COINS"
    user_id, amount = parts
    if not user_id.isdigit() or not amount.isdigit():
        await update.message.reply_text("❌ Numbers only.", reply_markup=get_cancel_keyboard())
        return "WAITING_REMOVE_COINS"
    if await deduct_coins(int(user_id), int(amount)):
        await update.message.reply_text(f"✅ Removed {amount} from {user_id}.", reply_markup=get_admin_keyboard())
        try:
            user = await get_user_data(int(user_id))
            await context.bot.send_message(int(user_id), f"💰 -{amount} coins!\nNew balance: {get_balance(user)}")
        except:
            pass
    else:
        await update.message.reply_text("❌ Insufficient balance.", reply_markup=get_cancel_keyboard())
        return "WAITING_REMOVE_COINS"
    return ConversationHandler.END

async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("🚫 Format: USER_ID REASON", reply_markup=get_cancel_keyboard())
    return "WAITING_BAN"

async def process_ban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    parts = update.message.text.split(maxsplit=1)
    if len(parts) != 2:
        await update.message.reply_text("❌ Format: USER_ID REASON", reply_markup=get_cancel_keyboard())
        return "WAITING_BAN"
    user_id, reason = parts
    if not user_id.isdigit():
        await update.message.reply_text("❌ User ID must be a number.", reply_markup=get_cancel_keyboard())
        return "WAITING_BAN"
    user = await get_user_data(int(user_id))
    user["banned"] = True
    user["ban_reason"] = reason
    await update_user_data(int(user_id), user)
    await update.message.reply_text(f"✅ Banned {user_id}.", reply_markup=get_admin_keyboard())
    try:
        await context.bot.send_message(int(user_id), f"🚫 You are permanently banned.\nReason: {reason}")
    except:
        pass
    return ConversationHandler.END

async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("✅ Send USER_ID:", reply_markup=get_cancel_keyboard())
    return "WAITING_UNBAN"

async def process_unban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    user_id = update.message.text
    if not user_id.isdigit():
        await update.message.reply_text("❌ User ID must be a number.", reply_markup=get_cancel_keyboard())
        return "WAITING_UNBAN"
    user = await get_user_data(int(user_id))
    user["banned"] = False
    user["ban_reason"] = ""
    user["temp_ban"] = False
    user["temp_ban_expiry"] = None
    user["like_temp_ban"] = False
    user["like_temp_ban_expiry"] = None
    await update_user_data(int(user_id), user)
    await update.message.reply_text(f"✅ Unbanned {user_id}.", reply_markup=get_admin_keyboard())
    try:
        await context.bot.send_message(int(user_id), f"✅ You have been unbanned.")
    except:
        pass
    return ConversationHandler.END

async def addadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("📝 Send USER_ID:", reply_markup=get_cancel_keyboard())
    return "WAITING_ADD_ADMIN"

async def process_addadmin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    user_id = update.message.text
    if not user_id.isdigit():
        await update.message.reply_text("❌ User ID must be a number.", reply_markup=get_cancel_keyboard())
        return "WAITING_ADD_ADMIN"
    if int(user_id) in ADMINS:
        await update.message.reply_text("❌ Already admin.", reply_markup=get_cancel_keyboard())
        return "WAITING_ADD_ADMIN"
    ADMINS.append(int(user_id))
    config = load_config()
    config["admins"] = ADMINS
    save_config(config)
    await update.message.reply_text(f"✅ Added admin {user_id}.", reply_markup=get_admin_keyboard())
    try:
        await context.bot.send_message(int(user_id), f"👑 You are now an admin!")
    except:
        pass
    return ConversationHandler.END

async def removeadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("❌ Send USER_ID:", reply_markup=get_cancel_keyboard())
    return "WAITING_REMOVE_ADMIN"

async def process_removeadmin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    user_id = update.message.text
    if not user_id.isdigit():
        await update.message.reply_text("❌ User ID must be a number.", reply_markup=get_cancel_keyboard())
        return "WAITING_REMOVE_ADMIN"
    if int(user_id) not in ADMINS:
        await update.message.reply_text("❌ Not an admin.", reply_markup=get_cancel_keyboard())
        return "WAITING_REMOVE_ADMIN"
    if int(user_id) == OWNER_ID:
        await update.message.reply_text("❌ Cannot remove owner.", reply_markup=get_admin_keyboard())
        return ConversationHandler.END
    ADMINS.remove(int(user_id))
    config = load_config()
    config["admins"] = ADMINS
    save_config(config)
    await update.message.reply_text(f"✅ Removed admin {user_id}.", reply_markup=get_admin_keyboard())
    try:
        await context.bot.send_message(int(user_id), f"❌ You are no longer an admin.")
    except:
        pass
    return ConversationHandler.END

async def genpromo_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("🎫 Format: CODE AMOUNT MAX_USERS\nExample: WELCOME100 100 10", reply_markup=get_cancel_keyboard())
    return "WAITING_CODE_GEN"

async def process_genpromo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return ConversationHandler.END
    if await check_cancel(update, context):
        return ConversationHandler.END
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    parts = update.message.text.split()
    if len(parts) != 3:
        await update.message.reply_text("❌ Format: CODE AMOUNT MAX_USERS", reply_markup=get_cancel_keyboard())
        return "WAITING_CODE_GEN"
    code, amount, max_users = parts
    if not amount.isdigit() or not max_users.isdigit():
        await update.message.reply_text("❌ Amount and max users must be numbers.", reply_markup=get_cancel_keyboard())
        return "WAITING_CODE_GEN"
    codes = load_codes()
    codes[code.upper()] = {"amount": int(amount), "max_users": int(max_users), "users": [], "created_by": update.effective_user.id, "created_at": datetime.now().isoformat()}
    save_codes(codes)
    await update.message.reply_text(f"✅ Code generated!\nCode: {code.upper()}\nAmount: {amount}\nMax: {max_users}", reply_markup=get_admin_keyboard())
    return ConversationHandler.END

async def pendingorders_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    orders_data = load_orders()
    pending = [o for o in orders_data["orders"] if o.get("status") == "pending"]
    if not pending:
        await update.message.reply_text("📋 No pending orders.", reply_markup=get_admin_keyboard())
        return
    for order in pending[:5]:
        text = (
            f"📋 Order: {order['id']}\nUser: {order['name']} (ID: {order['user_id']})\n"
            f"Coins: {order['coins']}\nAmount: ₹{order['amount']}\nMethod: {order.get('method', 'UPI').upper()}\n"
            f"Merchant: {order.get('merchant', 'N/A')}\n\n/verifypayment {order['id']} confirm/reject"
        )
        await update.message.reply_text(text, reply_markup=get_admin_keyboard())

async def verify_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Not admin.")
        return
    args = context.args
    if len(args) != 2:
        await update.message.reply_text("❌ /verifypayment ORDERID confirm/reject")
        return
    order_id, action = args
    action = action.lower()
    if action not in ["confirm", "reject"]:
        await update.message.reply_text("❌ Action: confirm/reject")
        return
    orders_data = load_orders()
    order = None
    for o in orders_data["orders"]:
        if o["id"] == order_id:
            order = o
            break
    if not order:
        await update.message.reply_text(f"❌ Order {order_id} not found.")
        return
    if order.get("status") != "pending":
        await update.message.reply_text(f"❌ Order already {order.get('status')}.")
        return
    if action == "confirm":
        await add_coins(order["user_id"], order["coins"], "purchased")
        order["status"] = "confirmed"
        order["confirmed_by"] = update.effective_user.id
        order["confirmed_at"] = datetime.now().isoformat()
        save_orders(orders_data)
        await update.message.reply_text(f"✅ Order {order_id} confirmed!\nCoins added.")
        try:
            user = await get_user_data(order["user_id"])
            await context.bot.send_message(order["user_id"], f"✅ Order {order_id} confirmed!\n+{order['coins']} coins!\nBalance: {get_balance(user)}")
        except:
            pass
    else:
        order["status"] = "rejected"
        order["rejected_by"] = update.effective_user.id
        order["rejected_at"] = datetime.now().isoformat()
        save_orders(orders_data)
        await update.message.reply_text(f"❌ Order {order_id} rejected.")
        try:
            await context.bot.send_message(order["user_id"], f"❌ Order {order_id} rejected.\nInvalid payment proof.")
        except:
            pass

async def reset_join_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    save_verified_users({})
    await update.message.reply_text("✅ All users verification reset!")

async def set_user_ref_limit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    args = context.args
    if len(args) != 2:
        await update.message.reply_text("❌ /setusrlmt USER_ID LIMIT")
        return
    user_id, limit = args
    if not user_id.isdigit() or not limit.isdigit():
        await update.message.reply_text("❌ Numbers only.")
        return
    user = await get_user_data(int(user_id))
    user["ref_limit"] = int(limit)
    await update_user_data(int(user_id), user)
    await update.message.reply_text(f"✅ User {user_id} referral limit set to {limit}")

async def give_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Only admin.")
        return
    args = context.args
    if len(args) != 2:
        await update.message.reply_text("❌ /vipnxn USER_ID DAYS")
        return
    user_id, days = args
    if not user_id.isdigit() or not days.isdigit():
        await update.message.reply_text("❌ Invalid input.")
        return
    user_id = int(user_id)
    days = int(days)
    user = await get_user_data(user_id)
    expiry_date = datetime.now() + timedelta(days=days)
    user["vip"] = True
    user["vip_expiry"] = expiry_date.isoformat()
    user["vip_given_by"] = update.effective_user.id
    user["vip_warned"] = False
    user["vip_expired_notified"] = False
    await update_user_data(user_id, user)
    await update.message.reply_text(f"✅ VIP activated for {user_id} for {days} days.")
    try:
        await context.bot.send_message(user_id, f"👑 VIP ACTIVATED!\nDuration: {days} days\nExpiry: {expiry_date.strftime('%d %b %Y')}\nNow you can create promo codes!")
    except:
        pass

async def check_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Only admin.")
        return
    args = context.args
    if len(args) != 1:
        await update.message.reply_text("❌ /checkvip USER_ID")
        return
    user_id = args[0]
    if not user_id.isdigit():
        await update.message.reply_text("❌ Invalid ID.")
        return
    user = await get_user_data(int(user_id))
    if not user.get("vip") or not user.get("vip_expiry"):
        await update.message.reply_text(f"❌ User {user_id} not VIP.")
        return
    expiry = datetime.fromisoformat(user["vip_expiry"])
    remaining = expiry - datetime.now()
    await update.message.reply_text(f"👑 VIP Status\nUser: {user_id}\nExpiry: {expiry.strftime('%d %b %Y')}\nRemaining: {remaining.days} days")

async def remove_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Only admin.")
        return
    args = context.args
    if len(args) != 1:
        await update.message.reply_text("❌ /removevip USER_ID")
        return
    user_id = args[0]
    if not user_id.isdigit():
        await update.message.reply_text("❌ Invalid ID.")
        return
    user = await get_user_data(int(user_id))
    user["vip"] = False
    user["vip_expiry"] = None
    user["vip_given_by"] = None
    await update_user_data(int(user_id), user)
    await update.message.reply_text(f"✅ VIP removed from {user_id}.")
    try:
        await context.bot.send_message(int(user_id), f"❌ VIP access removed by admin.")
    except:
        pass

async def my_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    user_id = update.effective_user.id
    user = await get_user_data(user_id)
    if not user.get("vip") or not user.get("vip_expiry"):
        await update.message.reply_text("❌ No VIP active.\nContact @NoobVellen to purchase.")
        return
    expiry = datetime.fromisoformat(user["vip_expiry"])
    remaining = expiry - datetime.now()
    await update.message.reply_text(
        f"👑 Your VIP\n━━━━━━━━━━━━━━━\n"
        f"Status: ACTIVE ✅\nExpiry: {expiry.strftime('%d %b %Y, %I:%M %p')}\n"
        f"Remaining: {remaining.days} days\n━━━━━━━━━━━━━━━"
    )

async def manage_regions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    text = f"🌍 Regions: {', '.join(REGIONS)}"
    await update.message.reply_text(text, reply_markup=get_admin_keyboard())

async def bot_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    if not is_admin(update.effective_user.id):
        return
    settings = load_bot_settings()
    text = (
        f"⚙️ Settings\n\nReferral: {settings['referral_reward']}\n"
        f"Cost/Like: {settings['cost_per_like']}\nDaily Limit: {settings['daily_limit']}"
    )
    await update.message.reply_text(text, reply_markup=get_admin_keyboard())

# ==================== FORCE JOIN ====================

async def force_join_verify(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if await global_temp_ban_check(update, context):
        return
    query = update.callback_query
    await query.answer()
    user_id = str(query.from_user.id)
    verified = load_verified_users()
    if verified.get(user_id):
        await query.message.delete()
        await context.bot.send_message(chat_id=query.message.chat_id, text="✅ Already verified!", reply_markup=get_main_keyboard())
        return
    for channel in FORCE_CHANNELS:
        try:
            member = await context.bot.get_chat_member(channel, int(user_id))
            if member.status in ["left", "kicked"]:
                await query.edit_message_text("❌ Join all channels first.")
                return
        except:
            await query.edit_message_text("❌ Error checking channels.")
            return
    verified[user_id] = True
    save_verified_users(verified)
    await query.message.delete()
    await context.bot.send_message(chat_id=query.message.chat_id, text="✅ Verified!", reply_markup=get_main_keyboard())

# ==================== MESSAGE HANDLER ====================

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Check permanent ban first
    if await global_temp_ban_check(update, context):
        return
    
    text = update.message.text
    user_id = update.effective_user.id
    
    # Direct database check for permanent ban
    users = load_users()
    user_data = users.get(str(user_id), {})
    
    if user_data.get("banned"):
        await update.message.reply_text(f"🚫 You are permanently banned.\nReason: {user_data.get('ban_reason', 'No reason')}")
        return
    
    user = await get_user_data(user_id)
    
    if not is_admin(user_id):

        if not await force_join_check(update, context):
            return

    if text == "🔙 Back to Main Menu":
        await update.message.reply_text("Main menu:", reply_markup=get_main_keyboard())
        return
    
    if text == "💰 My Balance":
        await balance(update, context)
    elif text == "🎟️ Redeem Code":
        await update.message.reply_text("🎟️ Options:", reply_markup=get_redeem_menu())
    elif text == "🎟️ Redeem Promo Code":
        return await redeem(update, context)
    elif text == "➕ Create Promo Code":
        return await create_code_start(update, context)
    elif text == "📢 Redeem Code Channel":
        await redeem_code_channel(update, context)
    elif text == "👥 Earn Coins":
        await earn(update, context)
    elif text == "👥 My Referrals":
        await referrals(update, context)
    elif text == "❤️ Get Likes":
        return await get_likes(update, context)
    elif text == "✅ Daily Verification":
        await send_verification_link(update, context)
    elif text == "📊 My Usage":
        await usage(update, context)
    elif text == "🛒 Buy Coins":
        return await buy(update, context)
    elif text == "🏆 Leaderboard":
        await update.message.reply_text("Leaderboard Menu:", reply_markup=get_leaderboard_menu())
    elif text == "💰 Top Coins":
        await show_top_coins(update, context)
    elif text == "👥 Top Referrals":
        await show_top_referrals(update, context)
    elif text == "❓ Help":
        await help_command(update, context)
    elif text == "👑 Admin Panel":
        if is_admin(user_id):
            await admin_panel_command(update, context)
        else:
            await update.message.reply_text("❌ Not admin.", reply_markup=get_main_keyboard())
    elif is_admin(user_id) and text in ["👥 Admin List", "📊 Statistics", "📢 Broadcast", "🎫 Generate Code",
        "➕ Add Coins", "➖ Remove Coins", "🚫 Ban User", "✅ Unban User", "📝 Add Admin", "❌ Remove Admin",
        "📋 Pending Orders", "🌍 Manage Regions", "⚙️ Bot Settings"]:
        if text == "👥 Admin List":
            await admin_list(update, context)
        elif text == "📊 Statistics":
            await admin_stats(update, context)
        elif text == "📢 Broadcast":
            return await broadcast_command(update, context)
        elif text == "🎫 Generate Code":
            return await genpromo_command(update, context)
        elif text == "➕ Add Coins":
            return await addcoins_command(update, context)
        elif text == "➖ Remove Coins":
            return await removecoins_command(update, context)
        elif text == "🚫 Ban User":
            return await ban_command(update, context)
        elif text == "✅ Unban User":
            return await unban_command(update, context)
        elif text == "📝 Add Admin":
            return await addadmin_command(update, context)
        elif text == "❌ Remove Admin":
            return await removeadmin_command(update, context)
        elif text == "📋 Pending Orders":
            await pendingorders_command(update, context)
        elif text == "🌍 Manage Regions":
            await manage_regions(update, context)
        elif text == "⚙️ Bot Settings":
            await bot_settings(update, context)
    else:
        await update.message.reply_text("❓ Unknown command. Use /help", reply_markup=get_main_keyboard())

async def force_join_buttons():

    keyboard = []

    for channel in FORCE_CHANNELS:

        keyboard.append(
            [InlineKeyboardButton(
                f"📢 Join {channel.replace('@', '')}",
                url=f"https://t.me/{channel.replace('@', '')}"
            )]
        )

    keyboard.append(
        [InlineKeyboardButton("✅ I Joined", callback_data="check_join")]
    )

    return InlineKeyboardMarkup(keyboard)

async def check_join_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):

    query = update.callback_query

    await query.answer()

    user_id = query.from_user.id

    joined = True

    for channel in FORCE_CHANNELS:

        try:

            member = await context.bot.get_chat_member(channel, user_id)

            if member.status in ["left", "kicked"]:

                joined = False
                break

        except:

            joined = False
            break

    if joined:

        verified = load_verified_users()

        today = datetime.now().strftime("%Y-%m-%d")

        verified[str(user_id)] = today

        save_verified_users(verified)

        await query.message.delete()

        await context.bot.send_message(
            chat_id=user_id,
            text="✅ Verification Successful!\n\nWelcome to NxN Coin Bot ❤️",
            reply_markup=get_main_keyboard()
        )

    else:

        await query.answer(
            "❌ You haven't joined all required channels yet!",
            show_alert=True
        )
async def force_join_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:

    user_id = str(update.effective_user.id)

    verified = load_verified_users()

    today = datetime.now().strftime("%Y-%m-%d")

    if verified.get(user_id) == today:
        return True

    for channel in FORCE_CHANNELS:

        try:

            member = await context.bot.get_chat_member(channel, int(user_id))

            if member.status in ["left", "kicked"]:

                await update.message.reply_text(
                    "🔐 You must join all required channels first!\n\n"
                    "👇 Join all channels below and click:\n"
                    "✅ I Joined",
                    reply_markup=await force_join_buttons()
                )

                return False

        except:

            await update.message.reply_text(
                "🔐 You must join all required channels first!\n\n"
                "👇 Join all channels below and click:\n"
                "✅ I Joined",
                reply_markup=await force_join_buttons()
            )

            return False

    verified[user_id] = today

    save_verified_users(verified)

    return True

# ==================== ERROR HANDLER ====================

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"ERROR: {context.error}")
    try:
        if update and update.effective_user:
            await context.bot.send_message(update.effective_user.id, "❌ An error occurred.")
    except:
        pass

def reset_verified_auto():
    save_verified_users({})
    logger.info("✅ Daily verification reset done")

# ==================== MAIN ====================

def main():
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .connection_pool_size(300)
        .pool_timeout(120)
        .connect_timeout(30)
        .read_timeout(30)
        .write_timeout(30)
        .concurrent_updates(30)
        .build()
    )

    # ==================== BOT JOB QUEUE SCHEDULER ====================

    application.job_queue.run_daily(
        lambda context: reset_verified_auto(),
        time=datetime.strptime("00:00", "%H:%M").time(),
        name="daily_reset"
    )

    application.job_queue.run_repeating(
        lambda context: check_vip_expiry(),
        interval=21600,
        first=10
    )

    application.job_queue.run_repeating(
        lambda context: context.application.create_task(
            vip_notifications(context.application)
        ),
        interval=21600,
        first=20
    )

    application.job_queue.run_repeating(
        lambda context: context.application.create_task(
            check_referral_penalty(context.application)
        ),
        interval=1800,
        first=30
    )

    application.job_queue.run_repeating(
        lambda context: context.application.create_task(
            auto_unban_check(context.application)
        ),
        interval=300,
        first=40
    )

    application.job_queue.run_repeating(
        lambda context: context.application.create_task(
            auto_like_unban(context.application)
        ),
        interval=300,
        first=50
    )


    # Command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("balance", balance))
    application.add_handler(CommandHandler("earn", earn))
    application.add_handler(CommandHandler("referrals", referrals))
    application.add_handler(CommandHandler("usage", usage))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("leaderboard", leaderboard))
    application.add_handler(CommandHandler("buy", buy))
    application.add_handler(CommandHandler("admin", admin_panel_command))
    application.add_handler(CommandHandler("addcoins", addcoins_command))
    application.add_handler(CommandHandler("removecoins", removecoins_command))
    application.add_handler(CommandHandler("ban", ban_command))
    application.add_handler(CommandHandler("unban", unban_command))
    application.add_handler(CommandHandler("addadmin", addadmin_command))
    application.add_handler(CommandHandler("removeadmin", removeadmin_command))
    application.add_handler(CommandHandler("genpromo", genpromo_command))
    application.add_handler(CommandHandler("verifypayment", verify_payment))
    application.add_handler(CommandHandler("resetjoin", reset_join_command))
    application.add_handler(CommandHandler("setusrlmt", set_user_ref_limit))
    application.add_handler(CommandHandler("vipnxn", give_vip))
    application.add_handler(CommandHandler("checkvip", check_vip))
    application.add_handler(CommandHandler("removevip", remove_vip))
    application.add_handler(CommandHandler("myvip", my_vip))
    application.add_handler(CommandHandler("on", on_cmd))
    application.add_handler(CommandHandler("off", off_cmd))
    application.add_handler(CommandHandler("pendingorders", pendingorders_command))
    application.add_handler(
        CallbackQueryHandler(check_join_callback, pattern="check_join")
    )

    # Callback handlers
    application.add_handler(CallbackQueryHandler(force_join_verify, pattern="force_join_verify"))

    # Conversation handlers
    conv_redeem = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^🎟️ Redeem Promo Code$"), redeem)],
        states={"WAITING_CODE": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_redeem)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_likes = ConversationHandler(

        entry_points=[
            MessageHandler(
                filters.Regex("^❤️ Get Likes$"),
                get_likes
            )
        ],

        states={

            "WAITING_UID": [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    process_uid
                )
            ],

            "WAITING_SERVER": [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    process_server
                )
            ],
        },

        fallbacks=[
            CommandHandler("start", start)
        ],

        allow_reentry=True,
        per_message=False,
    )          
    conv_buy = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^🛒 Buy Coins$"), buy)],
        states={
            "WAITING_PACKAGE": [MessageHandler(filters.TEXT & ~filters.COMMAND, buy_package)],
            "WAITING_PAYMENT_METHOD": [MessageHandler(filters.TEXT & ~filters.COMMAND, payment_method)],
            "WAITING_MERCHANT": [MessageHandler(filters.TEXT & ~filters.COMMAND, select_merchant)],
            "WAITING_PAYMENT_PROOF": [MessageHandler(filters.PHOTO, process_payment_proof)],
        },
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_broadcast = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📢 Broadcast$") & filters.User(user_id=ADMINS), broadcast_command)],
        states={"WAITING_BROADCAST": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_broadcast)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_addcoins = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^➕ Add Coins$") & filters.User(user_id=ADMINS), addcoins_command)],
        states={"WAITING_ADD_COINS": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_addcoins)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_removecoins = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^➖ Remove Coins$") & filters.User(user_id=ADMINS), removecoins_command)],
        states={"WAITING_REMOVE_COINS": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_removecoins)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_ban = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^🚫 Ban User$") & filters.User(user_id=ADMINS), ban_command)],
        states={"WAITING_BAN": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_ban)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_unban = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^✅ Unban User$") & filters.User(user_id=ADMINS), unban_command)],
        states={"WAITING_UNBAN": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_unban)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_addadmin = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📝 Add Admin$") & filters.User(user_id=ADMINS), addadmin_command)],
        states={"WAITING_ADD_ADMIN": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_addadmin)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_removeadmin = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^❌ Remove Admin$") & filters.User(user_id=ADMINS), removeadmin_command)],
        states={"WAITING_REMOVE_ADMIN": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_removeadmin)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_genpromo = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^🎫 Generate Code$") & filters.User(user_id=ADMINS), genpromo_command)],
        states={"WAITING_CODE_GEN": [MessageHandler(filters.TEXT & ~filters.COMMAND, process_genpromo)]},
        fallbacks=[CommandHandler("start", start)],
    )
    
    conv_create_code = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^➕ Create Promo Code$"), create_code_start)],
        states={
            "CREATE_VALUE": [MessageHandler(filters.TEXT & ~filters.COMMAND, create_code_value)],
            "CREATE_MAX": [MessageHandler(filters.TEXT & ~filters.COMMAND, create_code_final)],
        },
        fallbacks=[CommandHandler("start", start)],
    )
    
    application.add_handler(conv_redeem)
    application.add_handler(conv_likes)
    application.add_handler(conv_buy)
    application.add_handler(conv_broadcast)
    application.add_handler(conv_addcoins)
    application.add_handler(conv_removecoins)
    application.add_handler(conv_ban)
    application.add_handler(conv_unban)
    application.add_handler(conv_addadmin)
    application.add_handler(conv_removeadmin)
    application.add_handler(conv_genpromo)
    application.add_handler(conv_create_code)
    
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_error_handler(error_handler)
    
    logger.info("Bot started...")
    application.run_polling(
        drop_pending_updates=True,
        allowed_updates=Update.ALL_TYPES
    )

if __name__ == "__main__":
    main()