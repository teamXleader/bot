const axios = require('axios');

global.triviaGames = global.triviaGames || {};

module.exports = {
  name: 'trivia',
  aliases: ['quiz'],
  category: 'fun',
  description: 'Start trivia game',
  usage: '.trivia',

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;

    if (global.triviaGames[chatId]) {
      return extra.reply('❗ Trivia already running. Answer with .answer <number>');
    }

    try {

      const res = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple');
      const data = res.data.results[0];

      const options = [...data.incorrect_answers, data.correct_answer]
        .sort(() => Math.random() - 0.5);

      global.triviaGames[chatId] = {
        correct: data.correct_answer,
        options
      };

      let text = `🎮 *Trivia Game*\n\n`;
      text += `❓ ${data.question}\n\n`;

      options.forEach((opt, i) => {
        text += `${i + 1}. ${opt}\n`;
      });

      text += `\n*Answer with* .answer <number>`;

      await sock.sendMessage(chatId, { text }, { quoted: msg });

    } catch (err) {
      console.error(err);
      extra.reply('❌ Failed to fetch trivia.');
    }
  }
};