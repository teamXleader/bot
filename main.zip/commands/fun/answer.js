global.triviaGames = global.triviaGames || {};

module.exports = {
  name: 'answer',
  aliases: ['ans'],
  category: 'fun',
  description: 'Answer trivia question',
  usage: '.answer <number>',

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;

    if (!global.triviaGames[chatId]) {
      return extra.reply('❗ No trivia game running.');
    }

    if (!args[0]) {
      return extra.reply('⚠️ Example: .answer 2');
    }

    const choice = parseInt(args[0]);

    const game = global.triviaGames[chatId];

    if (!game.options[choice - 1]) {
      return extra.reply('❌ Invalid option.');
    }

    const selected = game.options[choice - 1];

    if (selected === game.correct) {
      await sock.sendMessage(chatId, {
        text: `✅ Correct!\nAnswer: ${game.correct}`
      }, { quoted: msg });
    } else {
      await sock.sendMessage(chatId, {
        text: `❌ Wrong!\nCorrect answer: ${game.correct}`
      }, { quoted: msg });
    }

    delete global.triviaGames[chatId];
  }
};