/**
 * 8Ball Command - Ask the magic ball
 */

const responses = [
  "Yes, definitely!",
  "No way!",
  "Ask again later.",
  "It is certain.",
  "Very doubtful.",
  "Without a doubt.",
  "My reply is no.",
  "Signs point to yes."
];

module.exports = {
  name: "8ball",
  aliases: ["eightball"],
  category: "fun",
  description: "Ask the magic 8ball a question",
  usage: ".8ball <question>",

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;
    const question = args.join(" ");

    if (!question) {
      return extra.reply("❌ Please ask a question.\nExample: .8ball Will I be rich?");
    }

    const randomResponse = responses[Math.floor(Math.random() * responses.length)];

    await sock.sendMessage(chatId, {
      text: `🎱 *Question:* ${question}\n\nAnswer: *${randomResponse}*`
    }, { quoted: msg });

  }
};