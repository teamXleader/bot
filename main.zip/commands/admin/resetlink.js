/**
 * ResetLink Command - Reset group invite link
 */

module.exports = {
  name: 'resetlink',
  aliases: ['revoke', 'revokelink'],
  category: 'admin',
  description: 'Reset the group invite link',
  usage: '.resetlink',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,

  async execute(sock, msg, args, extra) {
    try {

      const chatId = extra.from;

      // Reset group link
      const newCode = await sock.groupRevokeInvite(chatId);

      await sock.sendMessage(chatId, {
        text: `✅ *Group Link Reset Successfully*\n\n📌 *New Invite Link:*\nhttps://chat.whatsapp.com/${newCode}`
      }, { quoted: msg });

    } catch (error) {

      console.error('ResetLink command error:', error);

      await extra.reply(`❌ Failed to reset group link!\n\nError: ${error.message}`);

    }
  }
};