/**
 * Close Command - Close group (admins only)
 */

module.exports = {
  name: 'close',
  aliases: ['groupclose'],
  category: 'admin',
  description: 'Close the group (only admins can send messages)',
  usage: '.close',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,

  async execute(sock, msg, args, extra) {
    try {

      const chatId = extra.from;

      await sock.groupSettingUpdate(chatId, 'announcement');

      await sock.sendMessage(chatId, {
        text: `🔒 *Group Closed*\n\nOnly admins can send messages now.`
      }, { quoted: msg });

    } catch (error) {

      console.error('Close command error:', error);

      await extra.reply(`❌ Failed to close the group!\n\nError: ${error.message}`);

    }
  }
};