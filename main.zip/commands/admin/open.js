/**
 * Open Command - Open group for everyone
 */

module.exports = {
  name: 'open',
  aliases: ['groupopen'],
  category: 'admin',
  description: 'Open the group (everyone can send messages)',
  usage: '.open',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,

  async execute(sock, msg, args, extra) {
    try {

      const chatId = extra.from;

      await sock.groupSettingUpdate(chatId, 'not_announcement');

      await sock.sendMessage(chatId, {
        text: `🔓 *Group Opened*\n\nAll members can send messages now.`
      }, { quoted: msg });

    } catch (error) {

      console.error('Open command error:', error);

      await extra.reply(`❌ Failed to open the group!\n\nError: ${error.message}`);

    }
  }
};