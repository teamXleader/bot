const fs = require('fs');
const path = require('path');

/* Clear files inside directory */
function clearDirectory(dirPath) {

  if (!fs.existsSync(dirPath)) {
    return { success: false, message: `Directory not found: ${dirPath}`, count: 0 };
  }

  const files = fs.readdirSync(dirPath);
  let deleted = 0;

  for (const file of files) {
    try {
      fs.unlinkSync(path.join(dirPath, file));
      deleted++;
    } catch (err) {
      console.error(`Error deleting ${file}`, err);
    }
  }

  return {
    success: true,
    message: `Cleared ${deleted} files in ${path.basename(dirPath)}`,
    count: deleted
  };
}

/* Clear tmp + temp folders */
async function clearTmpDirectory() {

  const tmpDir = path.join(process.cwd(), 'tmp');
  const tempDir = path.join(process.cwd(), 'temp');

  const results = [
    clearDirectory(tmpDir),
    clearDirectory(tempDir)
  ];

  const total = results.reduce((sum, r) => sum + r.count, 0);

  return {
    success: results.every(r => r.success),
    message: results.map(r => r.message).join(' | '),
    count: total
  };
}

/* Auto cleaner every 6 hours */
function startAutoClear() {

  clearTmpDirectory();

  setInterval(() => {
    clearTmpDirectory().catch(err => console.error('[AutoClear]', err));
  }, 6 * 60 * 60 * 1000);

}

startAutoClear();

module.exports = {
  name: 'cleartmp',
  aliases: ['tmpclear'],
  category: 'owner',
  description: 'Clear tmp and temp directories',
  usage: '.cleartmp',
  ownerOnly: true,

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;

    try {

      if (!msg.key.fromMe) {
        return extra.reply('❌ Only owner can use this command.');
      }

      const result = await clearTmpDirectory();

      if (result.success) {
        await sock.sendMessage(chatId, {
          text: `✅ ${result.message}`
        }, { quoted: msg });
      } else {
        await sock.sendMessage(chatId, {
          text: `❌ ${result.message}`
        }, { quoted: msg });
      }

    } catch (error) {

      console.error('ClearTmp error:', error);

      await extra.reply('❌ Failed to clear temporary files.');

    }

  }
};