/**
 * ClearSession Command - Clear session files except creds.json
 */

const fs = require('fs');
const path = require('path');

const channelInfo = {
  contextInfo: {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363405655773145@newsletter',
      newsletterName: 'Krishna Bot',
      serverMessageId: -1
    }
  }
};

module.exports = {
  name: 'clearsession',
  aliases: ['csession', 'sessclear'],
  category: 'owner',
  description: 'Clear session files to optimize bot performance',
  usage: '.clearsession',
  ownerOnly: true,

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;

    try {

      // Owner check
      if (!msg.key.fromMe) {
        return sock.sendMessage(chatId, {
          text: '❌ This command can only be used by the owner!',
          ...channelInfo
        }, { quoted: msg });
      }

      const sessionDir = path.join(__dirname, '../../session');

      if (!fs.existsSync(sessionDir)) {
        return sock.sendMessage(chatId, {
          text: '❌ Session directory not found!',
          ...channelInfo
        }, { quoted: msg });
      }

      await sock.sendMessage(chatId, {
        text: '🔍 Optimizing session files for better performance...',
        ...channelInfo
      }, { quoted: msg });

      const files = fs.readdirSync(sessionDir);

      let filesCleared = 0;
      let appStateSyncCount = 0;
      let preKeyCount = 0;

      for (const file of files) {

        if (file.startsWith('app-state-sync-')) appStateSyncCount++;
        if (file.startsWith('pre-key-')) preKeyCount++;

        if (file === 'creds.json') continue;

        try {
          fs.unlinkSync(path.join(sessionDir, file));
          filesCleared++;
        } catch (err) {
          console.error(`Failed deleting ${file}`, err);
        }

      }

      const resultText =
        `✅ Session files cleared successfully!\n\n` +
        `📊 Statistics:\n` +
        `• Total files cleared: ${filesCleared}\n` +
        `• App state sync files: ${appStateSyncCount}\n` +
        `• Pre-key files: ${preKeyCount}`;

      await sock.sendMessage(chatId, {
        text: resultText,
        ...channelInfo
      }, { quoted: msg });

    } catch (error) {

      console.error('ClearSession command error:', error);

      await sock.sendMessage(chatId, {
        text: '❌ Failed to clear session files!',
        ...channelInfo
      }, { quoted: msg });

    }

  }
};