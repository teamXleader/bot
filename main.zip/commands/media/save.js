const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const config = require("../../config");

const DB = path.join(__dirname, "../../utils/status.json");

function loadDB() {
  if (!fs.existsSync(DB)) {
    fs.writeFileSync(DB, JSON.stringify({ enabled: true }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB));
}

function saveDB(data) {
  fs.writeFileSync(DB, JSON.stringify(data, null, 2));
}

module.exports = {
  name: "status",
  aliases: ["save", "savestatus"],
  category: "media",
  description: "Save replied status/media or toggle saver",
  usage: ".save (reply) | .status on/off",

  async execute(sock, msg, args, extra) {

    try {

      const db = loadDB();

      // Toggle system
      if (args[0]) {

        const opt = args[0].toLowerCase();

        if (opt === "on") {
          db.enabled = true;
          saveDB(db);
          return extra.reply("✅ Status saver enabled.");
        }

        if (opt === "off") {
          db.enabled = false;
          saveDB(db);
          return extra.reply("❌ Status saver disabled.");
        }

      }

      if (!db.enabled) {
        return extra.reply("❌ Status saver is OFF.");
      }

      const quoted = msg.message?.extendedTextMessage?.contextInfo;

      if (!quoted?.quotedMessage) {
        return extra.reply("❌ Reply to a status or media.");
      }

      let quotedMsg = quoted.quotedMessage;

      // Extract status media
      if (quotedMsg.groupStatusMessageV2) {
        quotedMsg = quotedMsg.groupStatusMessageV2.message;
      }

      const type = Object.keys(quotedMsg)[0];

      if (!["imageMessage","videoMessage","audioMessage"].includes(type)) {
        return extra.reply("❌ Only image, video, audio supported.");
      }

      const buffer = await downloadMediaMessage(
        { message: quotedMsg },
        "buffer",
        {},
        { reuploadRequest: sock.updateMediaMessage }
      );

      let content = {};

      if (type === "imageMessage") {
        content = {
          image: buffer,
          caption: quotedMsg.imageMessage?.caption || "Saved Image"
        };
      }

      if (type === "videoMessage") {
        content = {
          video: buffer,
          caption: quotedMsg.videoMessage?.caption || "Saved Video"
        };
      }

      if (type === "audioMessage") {
        content = {
          audio: buffer,
          mimetype: "audio/mp4",
          ptt: quotedMsg.audioMessage?.ptt || false
        };
      }

      const ownerJid = config.ownerNumber[0] + "@s.whatsapp.net";

      await sock.sendMessage(ownerJid, content);

      extra.reply("✅ Status saved.");

    } catch (err) {

      console.error("Save command error:", err);

      extra.reply("❌ Failed to save status.");

    }

  }
};