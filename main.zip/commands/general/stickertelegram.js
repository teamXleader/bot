const fetch = require("node-fetch");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");
const webp = require("node-webpmux");
const crypto = require("crypto");

const TELEGRAM_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN";

module.exports = {
  name: "tg",
  aliases: ["tgs", "telegramsticker"],
  category: "media",
  description: "Download Telegram sticker pack",
  usage: ".tg <telegram sticker url>",

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;

    if (!args[0]) {
      return extra.reply(
        "⚠️ Enter Telegram sticker URL\n\nExample:\n.tg https://t.me/addstickers/DogeMemes"
      );
    }

    if (!args[0].includes("t.me/addstickers/")) {
      return extra.reply("❌ Invalid Telegram sticker URL");
    }

    try {

      const packName = args[0].replace("https://t.me/addstickers/", "");

      const res = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_TOKEN}/getStickerSet?name=${packName}`
      );

      const data = await res.json();

      if (!data.ok) return extra.reply("❌ Sticker pack not found");

      const stickers = data.result.stickers;

      await extra.reply(`📦 Found ${stickers.length} stickers\n⏳ Downloading...`);

      const tmpDir = path.join(process.cwd(), "tmp");

      if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

      let success = 0;

      for (let sticker of stickers) {

        try {

          const fileInfo = await fetch(
            `https://api.telegram.org/bot${TELEGRAM_TOKEN}/getFile?file_id=${sticker.file_id}`
          );

          const fileData = await fileInfo.json();

          const filePath = fileData.result.file_path;

          const ext = filePath.split(".").pop();

          const fileUrl = `https://api.telegram.org/file/bot${TELEGRAM_TOKEN}/${filePath}`;

          const response = await fetch(fileUrl);

          const buffer = await response.buffer();

          const input = path.join(tmpDir, `tg_${Date.now()}.${ext}`);
          const gif = path.join(tmpDir, `tg_${Date.now()}.gif`);
          const output = path.join(tmpDir, `tg_${Date.now()}.webp`);

          fs.writeFileSync(input, buffer);

          // animated stickers (.tgs)
          if (ext === "tgs") {

            await new Promise((resolve, reject) => {
              exec(`lottie_convert.py "${input}" "${gif}"`,
                (err) => err ? reject(err) : resolve()
              );
            });

            await new Promise((resolve, reject) => {
              exec(
                `ffmpeg -y -i "${gif}" -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -loop 0 "${output}"`,
                (err) => err ? reject(err) : resolve()
              );
            });

          }

          // static stickers
          else {

            await new Promise((resolve, reject) => {
              exec(
                `ffmpeg -y -i "${input}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -loop 0 "${output}"`,
                (err) => err ? reject(err) : resolve()
              );
            });

          }

          const webpBuffer = fs.readFileSync(output);

          const img = new webp.Image();

          await img.load(webpBuffer);

          // Metadata
          const json = {
            "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
            "sticker-pack-name": "Krishna Coder Sticker",
            "sticker-pack-publisher": "Krishna Coder",
            "emojis": ["🤖"]
          };

          const exifAttr = Buffer.from([
            0x49,0x49,0x2A,0x00,0x08,0x00,0x00,0x00,
            0x01,0x00,0x41,0x57,0x07,0x00,0x00,0x00,
            0x00,0x00,0x16,0x00,0x00,0x00
          ]);

          const jsonBuffer = Buffer.from(JSON.stringify(json));

          const exif = Buffer.concat([exifAttr, jsonBuffer]);

          exif.writeUIntLE(jsonBuffer.length, 14, 4);

          img.exif = exif;

          const finalBuffer = await img.save(null);

          await sock.sendMessage(chatId, { sticker: finalBuffer });

          success++;

          if (fs.existsSync(input)) fs.unlinkSync(input);
          if (fs.existsSync(gif)) fs.unlinkSync(gif);
          if (fs.existsSync(output)) fs.unlinkSync(output);

          await new Promise(r => setTimeout(r, 700));

        } catch (err) {

          console.log("Sticker error:", err.message);

        }

      }

      await extra.reply(`✅ Successfully downloaded ${success}/${stickers.length} stickers`);

    } catch (err) {

      console.error(err);

      extra.reply("❌ Failed to download Telegram sticker pack");

    }

  }
};