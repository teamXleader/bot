/**
 * TTS Command - Convert text to speech
 */

const gTTS = require('gtts');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'tts',
  aliases: ['say', 'speak'],
  category: 'media',
  description: 'Convert text to speech',
  usage: '.tts <text>',

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;
    const text = args.join(' ');

    if (!text) {
      return extra.reply('❌ Please provide text.\nExample: .tts hello world');
    }

    try {

      // 🔄 Processing reaction
      await sock.sendMessage(chatId, {
        react: { text: "🔄", key: msg.key }
      });

      const mediaDir = path.join(process.cwd(), 'media');

      // Create media folder if not exists
      if (!fs.existsSync(mediaDir)) {
        fs.mkdirSync(mediaDir, { recursive: true });
      }

      const fileName = `tts-${Date.now()}.mp3`;
      const filePath = path.join(mediaDir, fileName);

      const gtts = new gTTS(text, 'en');

      // Save audio
      await new Promise((resolve, reject) => {
        gtts.save(filePath, err => {
          if (err) reject(err);
          else resolve();
        });
      });

      // Read file
      const audioBuffer = fs.readFileSync(filePath);

      // Send audio
      await sock.sendMessage(chatId, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        ptt: false,
        fileName: 'tts.mp3'
      }, { quoted: msg });

      // ✅ Success reaction
      await sock.sendMessage(chatId, {
        react: { text: "✅", key: msg.key }
      });

      // Delete temp file
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

    } catch (error) {

      console.error('TTS command error:', error);

      await extra.reply('❌ Failed to generate TTS audio.');

      await sock.sendMessage(chatId, {
        react: { text: "❌", key: msg.key }
      });

    }
  }
};