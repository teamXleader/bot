/**
 * Report Bug Command
 */

const config = require('../../config');

module.exports = {
  name: 'reportbug',
  aliases: ['bug', 'report'],
  category: 'general',
  description: 'Report a bug to bot developer',
  usage: '.reportbug <issue description>',

  async execute(sock, msg, args, extra) {
    try {

      const chatId = msg.key.remoteJid;
      const sender = msg.key.participant || msg.key.remoteJid;
      const text = args.join(' ');

      if (!text) {
        return extra.reply(`❌ Please describe the issue.\n\nExample: ${config.prefix}reportbug Play command isn't working`);
      }

      const bugReportMsg = `🐞 *BUG REPORT*

👤 *User:* @${sender.split("@")[0]}
💬 *Issue:* ${text}
🤖 *Bot:* ${config.botName}
`;

      const confirmationMsg = `Hi ${msg.pushName || "there"} 👋

Your bug report has been sent to the developer ✅

Please wait for a reply.

*Reported Issue:*  
${text}
`;

      const owner = config.ownerNumber[0] + "@s.whatsapp.net";

      // Send bug report to owner
      await sock.sendMessage(owner, {
        text: bugReportMsg,
        mentions: [sender]
      });

      // Confirmation to user
      await sock.sendMessage(chatId, {
        text: confirmationMsg,
        mentions: [sender]
      }, { quoted: msg });

    } catch (err) {

      console.error("reportbug command error:", err);

      await extra.reply("❌ Failed to send bug report.");

    }
  }
};