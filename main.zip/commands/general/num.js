const axios = require('axios');

module.exports = {
  name: 'num',
  aliases: ['number', 'numinfo'],
  category: 'general',
  description: 'Fetch information about a phone number',
  usage: '.num <10 digit number>',
  
  async execute(sock, msg, args, extra) {
    try {

      if (!args[0]) {
        return extra.reply('❌ Usage: .num <10 digit number>\nExample: .num 9393993939');
      }

      const number = args[0];

      if (!/^\d{10}$/.test(number)) {
        return extra.reply('❌ Invalid number!\n\nUsage: .num <10 digit number>');
      }

      if (number === "9305027687") {
        return extra.reply("😏 Nice try Krishna!");
      }

      await extra.reply(`⏳ ᴘʀᴏᴄᴇssɪɴɢ 📱 ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ ʀᴇǫᴜᴇsᴛ ғᴏʀ ${number}....`);

      /* ---------------- ONLY API 1 ---------------- */

      try {
        const api1 = `https://kaifu-ind-num-tucq.vercel.app/api/number_info?number=${number}&key=kaifu`;
        const res1 = await axios.get(api1, { timeout: 10000 });

        const results = res1.data?.data;

        if (results && results.length > 0) {

          let replyText = `📱 *𝑵𝒖𝒎𝒃𝒆𝒓 𝑰𝒏𝒇𝒐*\n\n`;

          results.forEach((info, index) => {
            const formattedAddress = info.address
              ? info.address.replace(/!/g, ', ')
              : 'N/A';
            replyText += `➤ 𝑅𝑒𝑠𝑢𝑙𝑡 ${index + 1}\n\n`;
            replyText += `𝐍𝐚𝐦𝐞: ${info.name || 'N/A'}\n`;
            replyText += `𝐅𝐚𝐭𝐡𝐞𝐫 𝐍𝐚𝐦𝐞: ${info.father_name || 'N/A'}\n`;
            replyText += `𝐌𝐨𝐛𝐢𝐥𝐞: ${info.mobile || 'N/A'}\n`;
            replyText += `𝐂𝐢𝐫𝐜𝐥𝐞: ${info.circle || 'N/A'}\n`;
            replyText += `𝐀𝐝𝐝𝐫𝐞𝐬𝐬: ${formattedAddress || 'N/A'}\n`;
            replyText += `𝐄𝐦𝐚𝐢𝐥: ${info.email || 'N/A'}\n`;
            replyText += `𝐀𝐥𝐭 𝐌𝐨𝐛𝐢𝐥𝐞: ${info.alternate_number || 'N/A'}\n`;
            replyText += `𝐈𝐃 𝐍𝐮𝐦𝐛𝐞𝐫: ${info.id || 'N/A'}\n\n`;
          });

          return extra.reply(replyText);
        }

      } catch (e) {
        console.error("API 1 Error:", e.message);
      }

      /* ---------------- NO DATA ---------------- */

      return extra.reply(`❌ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ ᴅᴇᴛᴀɪʟs ɴᴏᴛ ғᴏᴜɴᴅ ғᴏʀ ${number}`);

    } catch (error) {
      console.error(error);
      return extra.reply(`❌ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ ᴅᴇᴛᴀɪʟs ɴᴏᴛ ғᴏᴜɴᴅ ғᴏʀ ${number}`);
    }
  }
};
