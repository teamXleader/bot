/**
 * Blur Command - Blur an image
 */

const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');

module.exports = {
  name: 'blur',
  aliases: ['blurimg'],
  category: 'media',
  description: 'Blur an image',
  usage: '.blur (reply to image)',

  async execute(sock, msg, args, extra) {
    try {

      const chatId = msg.key.remoteJid;
      const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

      let imageBuffer;

      if (quoted && quoted.imageMessage) {

        const quotedMsg = {
          message: {
            imageMessage: quoted.imageMessage
          }
        };

        imageBuffer = await downloadMediaMessage(
          quotedMsg,
          'buffer',
          {},
          {}
        );

      } else if (msg.message?.imageMessage) {

        imageBuffer = await downloadMediaMessage(
          msg,
          'buffer',
          {},
          {}
        );

      } else {
        return extra.reply('❌ Reply to an image or send image with caption .blur');
      }

      // Resize image
      const resizedImage = await sharp(imageBuffer)
        .resize(800, 800, {
          fit: 'inside',
          withoutEnlargement: true
        })
        .jpeg({ quality: 80 })
        .toBuffer();

      // Blur effect
      const blurredImage = await sharp(resizedImage)
        .blur(10)
        .toBuffer();

      await sock.sendMessage(chatId, {
        image: blurredImage,
        caption: '*[ ✔ ] Image Blurred Successfully*'
      }, { quoted: msg });

    } catch (error) {

      console.error('Blur command error:', error);

      await extra.reply('❌ Failed to blur image. Try again.');

    }
  }
};