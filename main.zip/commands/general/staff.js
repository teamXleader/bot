/**
 * Staff Command - Show group admins
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

module.exports = {
  name: 'staff',
  aliases: ['admins', 'adminlist'],
  category: 'group',
  description: 'Show group admins',
  usage: '.staff',
  groupOnly: true,

  async execute(sock, msg, args, extra) {
    try {

      const chatId = extra.from;

      const groupMetadata = await sock.groupMetadata(chatId);

      // Get group picture
      let pp;
      try {
        pp = await sock.profilePictureUrl(chatId, 'image');
      } catch {
        pp = path.resolve(__dirname, '../../utils/bot_image.jpg');
      }

      const participants = groupMetadata.participants || [];
      const groupAdmins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');

      const listAdmin = groupAdmins
        .map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`)
        .join('\n▢ ') || 'No admins found';

      const owner =
        groupMetadata.owner ||
        groupAdmins.find(p => p.admin === 'superadmin')?.id ||
        chatId.split('-')[0] + '@s.whatsapp.net';

      const menuText = `
≡ *GROUP NAME* _${groupMetadata.subject}_

┌─⊷ *ADMINS*
▢ ${listAdmin}
└───────────
`.trim();

      const mentions = [...new Set([...groupAdmins.map(v => v.id), owner])];

      await sock.sendMessage(extra.from, {
        image: { url: pp },
        caption: menuText,
        mentions,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: config.newsletterJid || '120363405655773145@newsletter',
            newsletterName: config.botName,
            serverMessageId: -1
          }
        }
      }, { quoted: msg });

    } catch (error) {

      console.error('Staff command error:', error);

      await extra.reply('❌ Failed to get admin list!');

    }
  }
};