module.exports = {
  name: "dm",
  category: "owner",
  ownerOnly: true,
  description: "Send message to a number or self",
  usage: ".dm <number> <message> [count] OR .dm <message>",

  async execute(sock, msg, args, extra) {
    try {
      if (!args[0]) {
        return extra.reply("Usage: .dm <number> <message> [count] OR .dm <message>");
      }

      let number, text, count;

      // 🔥 Check first arg number hai ya message
      const isNumber = /^[0-9+]+$/.test(args[0]);

      if (isNumber) {
        // 📞 Number case
        number = args[0].replace(/[^0-9]/g, "");

        if (number.length === 10) {
          number = "91" + number;
        }

        const lastArg = parseInt(args[args.length - 1]);
        const hasCount = !isNaN(lastArg);

        text = hasCount
          ? args.slice(1, -1).join(" ")
          : args.slice(1).join(" ");

        count = hasCount ? lastArg : 1;

      } else {
        // 🧑 Self message
        number = (msg.key.participant || msg.key.remoteJid)
          .split("@")[0]
          .split(":")[0];

        text = args.join(" ");
        count = 1;
      }

      const jid = number + "@s.whatsapp.net";

      let success = 0;
      let failed = 0;

      await extra.reply(`🚀 Sending ${count} messages...`);

      for (let i = 0; i < count; i++) {
        try {
          await sock.sendPresenceUpdate("composing", jid);
          await sock.sendMessage(jid, { text });

          success++;

          await new Promise(res => setTimeout(res, 1000));
        } catch (e) {
          console.log("[DM ERROR]:", e);
          failed++;
        }
      }

      await extra.reply(
        `✅ Done!\n\n📤 Sent: ${success}\n❌ Failed: ${failed}`
      );

    } catch (err) {
      console.error("[DM CMD ERROR]:", err);
      extra.reply("❌ Error sending messages.");
    }
  }
};