/**
 * Trim Command - Trim audio or video
 */

const fs = require("fs");
const path = require("path");
const os = require("os");
const ffmpeg = require("fluent-ffmpeg");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

function formatDuration(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}m ${s}s`;
}

module.exports = {
  name: "trim",
  aliases: ["cut"],
  category: "media",
  description: "Trim audio or video",
  usage: ".trim <start> <end>",

  async execute(sock, msg, args, extra) {

    const chatId = extra.from;

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (!quoted?.videoMessage && !quoted?.audioMessage) {
      return extra.reply("❌ Reply to a *video or audio* with `.trim`");
    }

    try {

      const type = quoted.videoMessage ? "video" : "audio";

      const stream = await downloadContentFromMessage(
        quoted[type + "Message"],
        type
      );

      let buffer = Buffer.from([]);

      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      const inputFile = path.join(os.tmpdir(), `input_${Date.now()}.${type === "video" ? "mp4" : "mp3"}`);
      const outputFile = path.join(os.tmpdir(), `output_${Date.now()}.${type === "video" ? "mp4" : "mp3"}`);

      fs.writeFileSync(inputFile, buffer);

      // If no args → show duration
      if (!args[0] || !args[1]) {

        return new Promise((resolve, reject) => {

          ffmpeg.ffprobe(inputFile, async (err, metadata) => {

            if (err) {
              await extra.reply("⚠️ Failed to read media duration.");
              return reject(err);
            }

            const duration = metadata.format.duration;

            await sock.sendMessage(chatId, {
              text: `🎬 Media length: *${formatDuration(duration)}*

Use:
.trim start end

Example:
.trim 0 30
.trim 30 60`
            }, { quoted: msg });

            resolve();

          });

        });

      }

      const start = parseInt(args[0]);
      const end = parseInt(args[1]);

      if (isNaN(start) || isNaN(end) || start >= end) {
        return extra.reply("❌ Invalid format. Use `.trim start end` (seconds)");
      }

      await sock.sendMessage(chatId, {
        react: { text: "⏳", key: msg.key }
      });

      return new Promise((resolve, reject) => {

        ffmpeg(inputFile)
          .setStartTime(start)
          .setDuration(end - start)
          .output(outputFile)

          .on("end", async () => {

            const data = fs.readFileSync(outputFile);

            if (type === "video") {
              await sock.sendMessage(chatId, {
                video: data,
                mimetype: "video/mp4"
              }, { quoted: msg });
            } else {
              await sock.sendMessage(chatId, {
                audio: data,
                mimetype: "audio/mpeg"
              }, { quoted: msg });
            }

            await sock.sendMessage(chatId, {
              react: { text: "✅", key: msg.key }
            });

            fs.unlinkSync(inputFile);
            fs.unlinkSync(outputFile);

            resolve();

          })

          .on("error", async (err) => {

            console.error("Trim error:", err);

            await sock.sendMessage(chatId, {
              react: { text: "❌", key: msg.key }
            });

            await extra.reply("❌ Failed to trim media.");

            reject(err);

          })

          .run();

      });

    } catch (err) {

      console.error("trim command error:", err);

      extra.reply("❌ Error processing media.");

    }

  }
};