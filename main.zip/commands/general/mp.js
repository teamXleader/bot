const axios = require('axios');

module.exports = {
  name: 'mpinfo',
  aliases: ['madhya', 'mp'],
  category: 'general',
  description: 'Fetch information about a Madhya Pradesh phone number',
  usage: '.mp <10 digit number>',

  async execute(sock, msg, args, extra) {
    try {

      // ❌ No number
      if (!args[0]) {
        return extra.reply(
          '❌ Usage: .mp <10 digit number>\nExample: .mp 9876543210'
        );
      }

      const number = args[0];

      // ❌ Invalid number
      if (!/^\d{10}$/.test(number)) {
        return extra.reply(
          '❌ Invalid number!\n\nUsage: .mp <10 digit number>'
        );
      }

      // ⏳ Processing
      await extra.reply('⏳ *𝑷𝒓𝒐𝒄𝒆𝒔𝒔𝒊𝒏𝒈...*');

      // 🔗 API CALL (FIXED)
      const res = await axios.get(
        `http://143.110.247.59:5051/api/search?mobile=${number}`
      );

      const data = res.data.data; // ✅ IMPORTANT FIX

      if (!data || data.length === 0) {
        return extra.reply(
          `❌  ᴍᴀᴅʜʏᴀ ᴘʀᴀᴅᴇsʜ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ ᴅᴇᴛᴀɪʟs ɴᴏᴛ ғᴏᴜɴᴅ ғᴏʀ ${number}`
        );
      }

      // 🔄 Remove duplicates
      const uniqueResults = [];
      const seen = new Set();

      data.forEach(info => {
        if (!seen.has(info.member_id)) {
          seen.add(info.member_id);
          uniqueResults.push(info);
        }
      });

      // 📝 Header
      let replyText = `📱 *𝑴𝒂𝒅𝒉𝒚𝒂 𝑷𝒓𝒂𝒅𝒆𝒔𝒉 𝑵𝒖𝒎𝒃𝒆𝒓 𝑰𝒏𝒇𝒐*\n\n`;

      // 🔁 Loop
      for (let i = 0; i < uniqueResults.length; i++) {
        const info = uniqueResults[i];

        const maskedMobile = info.mobile
          ? info.mobile.replace(/(\d{4})\d{4}(\d{2})/, '$1****$2')
          : 'N/A';

        replyText += `━━━━━━━❰ 𝑹𝒆𝒔𝒖𝒍𝒕 ${i + 1} ❱━━━━━━━\n\n`;

        replyText += `𝐍𝐚𝐦𝐞: ${info.full_name || 'N/A'}\n`;
        replyText += `𝐇𝐢𝐧𝐝𝐢 𝐍𝐚𝐦𝐞: ${info.hindi_name || 'N/A'}\n`;
        replyText += `𝐆𝐞𝐧𝐝𝐞𝐫: ${info.gender || 'N/A'}\n`;
        replyText += `𝐃𝐎𝐁: ${info.dob || 'N/A'}\n`;
        replyText += `𝐌𝐨𝐛𝐢𝐥𝐞: ${maskedMobile}\n`;
        replyText += `𝐂𝐚𝐭𝐞𝐠𝐨𝐫𝐲: ${info.category || 'N/A'}\n`;
        replyText += `𝐃𝐢𝐬𝐭𝐫𝐢𝐜𝐭: ${info.district || 'N/A'}\n`;
        replyText += `𝐀𝐝𝐝𝐫𝐞𝐬𝐬: ${info.address || 'N/A'}\n`;
        replyText += `𝐅𝐚𝐦𝐢𝐥𝐲 𝐈𝐃: ${info.family_id || 'N/A'}\n`;
        replyText += `𝐌𝐞𝐦𝐛𝐞𝐫 𝐈𝐃: ${info.member_id || 'N/A'}\n\n`;
      }

      // 📩 Send text
      await extra.reply(replyText);

      // 🖼️ Images
      for (const info of uniqueResults) {
        if (info.photo_url) {
          try {
            const img = await axios.get(info.photo_url, {
              responseType: 'stream'
            });

            await sock.sendMessage(msg.key.remoteJid, {
              image: img.data,
              caption: `📸 ${info.full_name || 'User'}`
            });

          } catch (err) {
            console.log("Image error:", err.message);
          }
        }
      }

    } catch (err) {
      console.error("API Error:", err.message);

      return extra.reply(
        `❌  ᴍᴀᴅʜʏᴀ ᴘʀᴀᴅᴇsʜ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ ᴅᴇᴛᴀɪʟs ɴᴏᴛ ғᴏᴜɴᴅ ғᴏʀ ${args[0]}`
      );
    }
  }
};