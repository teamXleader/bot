const axios = require('axios');

module.exports = {
  name: 'aadhar',
  aliases: ['aadh', 'aadharinfo'],
  category: 'general',
  description: 'Fetch information about a Aadhar number',
  usage: '.aadhar <12 digit number>',
  
  async execute(sock, msg, args, extra) {
    try {

      if (!args[0]) {
        return extra.reply('❌ Usage: .aadhar <12 digit number>\nExample: .aadhar XXXXXXXX2731');
      }

      const number = args[0];

      if (!/^\d{12}$/.test(number)) {
        return extra.reply('❌ Invalid number!\n\nUsage: . aadhar <12 digit number>');
      }

      if (number === "9305027687") {
        return extra.reply("😏 Nice try Krishna!");
      }

      await extra.reply(`⏳ ᴘʀᴏᴄᴇssɪɴɢ 📱 ᴀᴀᴅʜᴀᴀʀ ɴᴜᴍʙᴇʀ ʀᴇǫᴜᴇsᴛ ғᴏʀ ${number}....`);

      /* ---------------- ONLY API 1 ---------------- */

      try {
        const api1 = `http://185.216.176.215:5051/krishna/aadhar/${number}`;
        const res1 = await axios.get(api1, { timeout: 10000 });

        const results = res1.data?.data;

        if (results && results.length > 0) {

          let replyText = `📱 *𝑨𝒂𝒅𝒉𝒂𝒓 𝑵𝒖𝒎𝒃𝒆𝒓 𝑰𝒏𝒇𝒐*\n\n`;

          results.forEach((info, index) => {
            replyText += `𝐍𝐚𝐦𝐞: ${info.name || 'N/A'}\n`;
            replyText += `𝐅𝐚𝐭𝐡𝐞𝐫 𝐍𝐚𝐦𝐞: ${info.fname || 'N/A'}\n`;
            replyText += `𝐌𝐨𝐛𝐢𝐥𝐞: ${info.mobile || 'N/A'}\n`;
            replyText += `𝐀𝐝𝐝𝐫𝐞𝐬𝐬: ${info.address || 'N/A'}\n`;
            replyText += `𝐄𝐦𝐚𝐢𝐥: ${info.email || 'N/A'}\n`;
            replyText += `𝐀𝐥𝐭 𝐌𝐨𝐛𝐢𝐥𝐞: ${info.alt || 'N/A'}\n`;
            replyText += `𝐀𝐚𝐝𝐡𝐚𝐫 𝐍𝐮𝐦𝐛𝐞𝐫: ${info.id || 'N/A'}\n\n`;
          });

          return extra.reply(replyText);
        }

      } catch (e) {
        console.error("API  Error:", e.message);
      }

      /* ---------------- NO DATA ---------------- */

      return extra.reply(`❌ ᴀᴀᴅʜᴀᴀʀ ɴᴜᴍʙᴇʀ ᴅᴇᴛᴀɪʟs ɴᴏᴛ ғᴏᴜɴᴅ ғᴏʀ ${number}`);

    } catch (error) {
      console.error(error);
      return extra.reply(`❌ ᴀᴀᴅʜᴀᴀʀ ɴᴜᴍʙᴇʀ ᴅᴇᴛᴀɪʟs ɴᴏᴛ ғᴏᴜɴᴅ ғᴏʀ ${number}`);
    }
  }
};